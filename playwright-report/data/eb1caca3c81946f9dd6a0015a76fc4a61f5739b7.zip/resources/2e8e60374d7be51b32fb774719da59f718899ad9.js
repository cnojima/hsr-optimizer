/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/components/HeaderText.js":
/*!**************************************!*\
  !*** ./src/components/HeaderText.js ***!
  \**************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HeaderText: () => (/* binding */ HeaderText)
/* harmony export */ });
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/typography/index.js");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");



const {
  Text
} = antd__WEBPACK_IMPORTED_MODULE_0__["default"];
const HeaderText = (0,styled_components__WEBPACK_IMPORTED_MODULE_1__["default"])(Text)`
  text-decoration: underline;
  text-decoration-color: #6d97ffb3;
  text-underline-offset: 2px
`;

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/components/TooltipImage.js":
/*!****************************************!*\
  !*** ./src/components/TooltipImage.js ***!
  \****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TooltipImage: () => (/* binding */ TooltipImage)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/popover/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lib_assets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/assets */ "./src/lib/assets.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/curisu/dev/hsr-optimizer/src/components/TooltipImage.js";





const TooltipImage = props => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_3__["default"], {
  content: props.type.content,
  title: props.type.title,
  overlayStyle: {
    width: 500
  },
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
    src: _lib_assets__WEBPACK_IMPORTED_MODULE_1__.Assets.getQuestion(),
    style: {
      width: 16,
      opacity: 0.6
    }
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 5
  }, undefined)
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 7,
  columnNumber: 3
}, undefined);
_c = TooltipImage;
TooltipImage.propTypes = {
  type: (prop_types__WEBPACK_IMPORTED_MODULE_4___default().object)
};
var _c;
__webpack_require__.$Refresh$.register(_c, "TooltipImage");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/components/optimizerTab/FormConditionalInputs.js":
/*!**************************************************************!*\
  !*** ./src/components/optimizerTab/FormConditionalInputs.js ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormSlider: () => (/* binding */ FormSlider),
/* harmony export */   FormSwitch: () => (/* binding */ FormSwitch)
/* harmony export */ });
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/typography/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/flex/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/form/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/switch/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/input-number/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/slider/index.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/icons/CheckOutlined.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/icons/CloseOutlined.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/curisu/dev/hsr-optimizer/src/components/optimizerTab/FormConditionalInputs.js",
  _s = __webpack_require__.$Refresh$.signature();






let justify = 'flex-start';
let align = 'center';
let inputWidth = 75;
let numberWidth = 65;
let sliderWidth = 145;
const Text = (0,styled_components__WEBPACK_IMPORTED_MODULE_2__["default"])((0,antd__WEBPACK_IMPORTED_MODULE_3__["default"]))`
  white-space: pre-line;
`;
_c = Text;
function precisionRound(number, precision = 8) {
  let factor = Math.pow(10, precision);
  return Math.round(number * factor) / factor;
}
function FormSwitch(props) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_4__["default"], {
    justify: justify,
    align: align,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      style: {
        minWidth: inputWidth,
        display: 'block'
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_5__["default"].Item, {
        name: [conditionalType(props), props.name],
        valuePropName: "checked",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_6__["default"], {
          checkedChildren: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 30
          }, this),
          unCheckedChildren: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_ant_design_icons__WEBPACK_IMPORTED_MODULE_8__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 32
          }, this),
          disabled: props.disabled,
          defaultChecked: !props.disabled
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Text, {
      children: props.text
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, this);
}
_c2 = FormSwitch;
FormSwitch.propTypes = {
  disabled: (prop_types__WEBPACK_IMPORTED_MODULE_9___default().bool),
  text: (prop_types__WEBPACK_IMPORTED_MODULE_9___default().string),
  name: (prop_types__WEBPACK_IMPORTED_MODULE_9___default().string)
};
function FormSlider(props) {
  _s();
  const [inputValue, setInputValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
  const onChange = newValue => {
    setInputValue(newValue);
  };
  let multiplier = props.percent ? 100 : 1;
  let step = props.percent ? 0.01 : 1;
  let symbol = props.percent ? '%' : '';
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_4__["default"], {
    vertical: true,
    gap: 5,
    style: {
      marginBottom: 0
    },
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_4__["default"], {
      justify: justify,
      align: align,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        style: {
          minWidth: inputWidth,
          display: 'block'
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_5__["default"].Item, {
          name: [conditionalType(props), props.name],
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_10__["default"], {
            min: props.min,
            max: props.max,
            controls: false,
            size: "small",
            style: {
              width: numberWidth
            },
            parser: value => value == null || value == '' ? 0 : precisionRound(value / multiplier),
            formatter: value => `${precisionRound(value * multiplier)}`,
            addonAfter: symbol,
            onChange: onChange,
            disabled: props.disabled
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Text, {
        children: props.text
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_4__["default"], {
      align: "center",
      justify: "flex-start",
      gap: 10,
      style: {
        height: 14
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_5__["default"].Item, {
        name: [conditionalType(props), props.name],
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_11__["default"], {
          min: props.min,
          max: props.max,
          step: step,
          value: typeof inputValue === 'number' ? inputValue : 0,
          style: {
            minWidth: sliderWidth,
            marginTop: 0,
            marginBottom: 0,
            marginLeft: 1
          },
          tooltip: {
            formatter: value => `${precisionRound(value * multiplier)}${symbol}`
          },
          onChange: onChange,
          disabled: props.disabled
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Text, {
        style: {
          minWidth: 20,
          marginBottom: 2,
          textAlign: 'center'
        },
        children: `${precisionRound(props.max * multiplier)}${symbol}`
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 97,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 55,
    columnNumber: 5
  }, this);
}
_s(FormSlider, "1YhZVcooKZU1mKwuS+wJmQpCIJE=");
_c3 = FormSlider;
FormSlider.propTypes = {
  disabled: (prop_types__WEBPACK_IMPORTED_MODULE_9___default().bool),
  min: (prop_types__WEBPACK_IMPORTED_MODULE_9___default().number),
  max: (prop_types__WEBPACK_IMPORTED_MODULE_9___default().number),
  text: (prop_types__WEBPACK_IMPORTED_MODULE_9___default().string),
  name: (prop_types__WEBPACK_IMPORTED_MODULE_9___default().string),
  percent: (prop_types__WEBPACK_IMPORTED_MODULE_9___default().bool)
};
function conditionalType(props) {
  if (props.lc) {
    return 'lightConeConditionals';
  }
  return 'characterConditionals';
}
var _c, _c2, _c3;
__webpack_require__.$Refresh$.register(_c, "Text");
__webpack_require__.$Refresh$.register(_c2, "FormSwitch");
__webpack_require__.$Refresh$.register(_c3, "FormSlider");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/lib/assets.js":
/*!***************************!*\
  !*** ./src/lib/assets.js ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Assets: () => (/* binding */ Assets)
/* harmony export */ });
/* harmony import */ var _constants_ts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants.ts */ "./src/lib/constants.ts");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");



// let baseUrl = process.env.PUBLIC_URL // Local testing;
let baseUrl = 'https://d28ecrnsw8u0fj.cloudfront.net';
let pathFromClassMapping;
let iconFromStatMapping;
const Assets = {
  getStatIcon: (stat, percented) => {
    if (!iconFromStatMapping) {
      iconFromStatMapping = {
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.HP]: 'IconMaxHP.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.ATK]: 'IconAttack.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.DEF]: 'IconDefence.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.HP_P]: 'IconMaxHP.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.ATK_P]: 'IconAttack.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.DEF_P]: 'IconDefence.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.SPD]: 'IconSpeed.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.SPD_P]: 'IconSpeed.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.CR]: 'IconCriticalChance.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.CD]: 'IconCriticalDamage.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.EHR]: 'IconStatusProbability.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.RES]: 'IconStatusResistance.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.BE]: 'IconBreakUp.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.ERR]: 'IconEnergyRecovery.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.OHB]: 'IconHealRatio.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.Physical_DMG]: 'IconPhysicalAddedRatio.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.Fire_DMG]: 'IconFireAddedRatio.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.Ice_DMG]: 'IconIceAddedRatio.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.Lightning_DMG]: 'IconThunderAddedRatio.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.Wind_DMG]: 'IconWindAddedRatio.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.Quantum_DMG]: 'IconQuantumAddedRatio.png',
        [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.Imaginary_DMG]: 'IconImaginaryAddedRatio.png'
      };
    }
    if (stat == 'CV') return baseUrl + `/assets/misc/cv.png`;
    if (stat == _constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.HP_P && percented) return baseUrl + `/assets/misc/IconMaxHPPercent.png`;
    if (stat == _constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.ATK_P && percented) return baseUrl + `/assets/misc/IconAttackPercent.png`;
    if (stat == _constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.DEF_P && percented) return baseUrl + `/assets/misc/IconDefencePercent.png`;
    if (!stat || !iconFromStatMapping[stat]) return '';
    return baseUrl + `/assets/icon/property/` + iconFromStatMapping[stat];
  },
  getSampleSave: () => {
    return baseUrl + `/sample-save.json`;
  },
  getCharacterPortrait: characterId => {
    if (!characterId) return '';
    return baseUrl + `/assets/image/character_portrait_resized/resized${characterId}.png`;
  },
  getCharacterPortraitById: id => {
    if (!id) {
      console.warn('No id found');
      return '';
    }
    return baseUrl + `/assets/image/character_portrait_resized/resized${id}.png`;
  },
  getCharacterAvatarById: id => {
    if (!id) return '';
    return baseUrl + `/assets/icon/avatar/${id}.png`;
  },
  getCharacterIconById: id => {
    if (!id) return '';
    return baseUrl + `/assets/icon/character/${id}.png`;
  },
  getCharacterPreview: character => {
    if (!character) return '';
    return baseUrl + `/assets/${character.preview}`;
  },
  getCharacterPreviewById: id => {
    if (!id) return '';
    return baseUrl + `/assets/image/character_preview/${id}.png`;
  },
  getLightConePortrait: lightCone => {
    if (!lightCone) return '';
    return baseUrl + `/assets/image/light_cone_portrait/${lightCone.id}.png`;
  },
  getPath: path => {
    if (!path) return '';
    return baseUrl + `/assets/icon/path/${path}.png`;
  },
  getPathFromClass: c => {
    if (!pathFromClassMapping) {
      pathFromClassMapping = {
        'Warrior': 'Destruction',
        'Warlock': 'Nihility',
        'Knight': 'Preservation',
        'Priest': 'Abundance',
        'Rogue': 'Hunt',
        'Shaman': 'Harmony',
        'Mage': 'Erudition'
      };
    }
    if (!c || !pathFromClassMapping[c]) return '';
    return baseUrl + `/assets/icon/path/${pathFromClassMapping[c]}.png`;
  },
  getElement: element => {
    if (!element) return '';
    if (element == 'Thunder') element = 'Lightning';
    return baseUrl + `/assets/icon/element/${element}.png`;
  },
  getBlank: () => {
    return baseUrl + '/assets/misc/blank.png';
  },
  getQuestion: () => {
    return baseUrl + '/assets/misc/tooltip.png';
  },
  getLogo: () => {
    return baseUrl + '/assets/misc/logo.png';
  },
  getDiscord: () => {
    return baseUrl + '/assets/misc/badgediscord.png';
  },
  getStar: () => {
    return baseUrl + '/assets/icon/deco/StarBig.png';
  },
  getGuideImage: name => {
    return baseUrl + '/assets/guide/' + name + '.png';
  },
  getInventory: () => {
    return baseUrl + '/assets/icon/sign/ShopMaterialsIcon.png';
  },
  getStarBw: () => {
    return baseUrl + '/assets/icon/sign/QuestMainIcon.png';
  },
  getMisc: filename => {
    return baseUrl + '/assets/misc/' + filename;
  },
  getPart: part => {
    let mapping = {
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.Head]: 'head',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.Hands]: 'hands',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.Body]: 'body',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.Feet]: 'feet',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.PlanarSphere]: 'planarSphere',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.LinkRope]: 'linkRope'
    };
    return baseUrl + `/assets/misc/${mapping[part]}.png`;
  },
  getSetImage: (set, part) => {
    if (!part) {
      part = 'base';
    }
    const setToId = {
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.PasserbyOfWanderingCloud]: '101',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.MusketeerOfWildWheat]: '102',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.KnightOfPurityPalace]: '103',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.HunterOfGlacialForest]: '104',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.ChampionOfStreetwiseBoxing]: '105',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.GuardOfWutheringSnow]: '106',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.FiresmithOfLavaForging]: '107',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.GeniusOfBrilliantStars]: '108',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.BandOfSizzlingThunder]: '109',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.EagleOfTwilightLine]: '110',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.ThiefOfShootingMeteor]: '111',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.WastelanderOfBanditryDesert]: '112',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.LongevousDisciple]: '113',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.MessengerTraversingHackerspace]: '114',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.TheAshblazingGrandDuke]: '115',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.PrisonerInDeepConfinement]: '116',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.SpaceSealingStation]: '301',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.FleetOfTheAgeless]: '302',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.PanCosmicCommercialEnterprise]: '303',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.BelobogOfTheArchitects]: '304',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.CelestialDifferentiator]: '305',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.InertSalsotto]: '306',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.TaliaKingdomOfBanditry]: '307',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.SprightlyVonwacq]: '308',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.RutilantArena]: '309',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.BrokenKeel]: '310',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.FirmamentFrontlineGlamoth]: '311',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.PenaconyLandOfTheDreams]: '312'
    };
    const partToId = {
      base: '',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.Head]: '_0',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.Hands]: '_1',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.Body]: '_2',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.Feet]: '_3',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.PlanarSphere]: '_0',
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Parts.LinkRope]: '_1'
    };
    return baseUrl + `/assets/icon/relic/${setToId[set]}${partToId[part]}.png`;
  }
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/lib/bufferPacker.js":
/*!*********************************!*\
  !*** ./src/lib/bufferPacker.js ***!
  \*********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BufferPacker: () => (/* binding */ BufferPacker)
/* harmony export */ });
/* harmony import */ var _constants_ts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants.ts */ "./src/lib/constants.ts");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");


const SIZE = 35;

// When adding new rows, use:
// let i = 0
// offset + i++

const BufferPacker = {
  extractCharacter: (arr, offset) => {
    // Float32Array
    offset = offset * SIZE;
    return {
      id: arr[offset],
      // 0
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.HP]: arr[offset + 1],
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.ATK]: arr[offset + 2],
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.DEF]: arr[offset + 3],
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.SPD]: arr[offset + 4],
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.CD]: arr[offset + 5],
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.CR]: arr[offset + 6],
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.EHR]: arr[offset + 7],
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.RES]: arr[offset + 8],
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.BE]: arr[offset + 9],
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.ERR]: arr[offset + 10],
      // 10
      [_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats.OHB]: arr[offset + 11],
      ED: arr[offset + 12],
      CV: arr[offset + 13],
      WEIGHT: arr[offset + 14],
      EHP: arr[offset + 15],
      BASIC: arr[offset + 16],
      SKILL: arr[offset + 17],
      ULT: arr[offset + 18],
      FUA: arr[offset + 19],
      DOT: arr[offset + 20],
      // 20
      xHP: arr[offset + 21],
      xATK: arr[offset + 22],
      xDEF: arr[offset + 23],
      xSPD: arr[offset + 24],
      xCR: arr[offset + 25],
      xCD: arr[offset + 26],
      xEHR: arr[offset + 27],
      xRES: arr[offset + 28],
      xBE: arr[offset + 29],
      xERR: arr[offset + 30],
      // 30
      xOHB: arr[offset + 31],
      xELEMENTAL_DMG: arr[offset + 32],
      relicSetIndex: arr[offset + 33],
      ornamentSetIndex: arr[offset + 34]
    };
  },
  extractArrayToResults: (arr, length, results) => {
    for (let i = 0; i < length; i++) {
      if (arr[i * SIZE + 1]) {
        results.push(BufferPacker.extractCharacter(arr, i));
      }
    }
  },
  packCharacter: (arr, offset, character) => {
    offset = offset * SIZE;

    // When adding new rows, use:
    arr[offset] = character.id; // 0
    arr[offset + 1] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.HP];
    arr[offset + 2] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.ATK];
    arr[offset + 3] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.DEF];
    arr[offset + 4] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.SPD];
    arr[offset + 5] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.CD];
    arr[offset + 6] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.CR];
    arr[offset + 7] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.EHR];
    arr[offset + 8] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.RES];
    arr[offset + 9] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.BE];
    arr[offset + 10] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.ERR]; // 10
    arr[offset + 11] = character[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.OHB];
    arr[offset + 12] = character.ELEMENTAL_DMG;
    arr[offset + 13] = character.CV;
    arr[offset + 14] = character.WEIGHT;
    arr[offset + 15] = character.EHP;
    arr[offset + 16] = character.x.BASIC_DMG;
    arr[offset + 17] = character.x.SKILL_DMG;
    arr[offset + 18] = character.x.ULT_DMG;
    arr[offset + 19] = character.x.FUA_DMG;
    arr[offset + 20] = character.x.DOT_DMG; // 20
    arr[offset + 21] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.HP];
    arr[offset + 22] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.ATK];
    arr[offset + 23] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.DEF];
    arr[offset + 24] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.SPD];
    arr[offset + 25] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.CR];
    arr[offset + 26] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.CD];
    arr[offset + 27] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.EHR];
    arr[offset + 28] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.RES];
    arr[offset + 29] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.BE];
    arr[offset + 30] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.ERR]; // 30
    arr[offset + 31] = character.x[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Stats.OHB];
    arr[offset + 32] = character.x.ELEMENTAL_DMG;
    arr[offset + 33] = character.relicSetIndex;
    arr[offset + 34] = character.ornamentSetIndex;
  },
  cleanFloatBuffer: buffer => {
    new Float64Array(buffer).fill(0);
  },
  createFloatBuffer: length => {
    return new Float64Array(length * SIZE).buffer;
  }
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/lib/characterConditionals.js":
/*!******************************************!*\
  !*** ./src/lib/characterConditionals.js ***!
  \******************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CharacterConditionals: () => (/* binding */ CharacterConditionals)
/* harmony export */ });
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/flex/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/config-provider/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_HeaderText__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/HeaderText */ "./src/components/HeaderText.js");
/* harmony import */ var _constants_ts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants.ts */ "./src/lib/constants.ts");
/* harmony import */ var _components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/optimizerTab/FormConditionalInputs */ "./src/components/optimizerTab/FormConditionalInputs.js");
/* harmony import */ var _components_TooltipImage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/TooltipImage */ "./src/components/TooltipImage.js");
/* harmony import */ var _hint__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./hint */ "./src/lib/hint.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/curisu/dev/hsr-optimizer/src/lib/characterConditionals.js";








let Stats = _constants_ts__WEBPACK_IMPORTED_MODULE_2__.Constants.Stats;
let precisionRound = (number, precision = 8) => {
  let factor = Math.pow(10, precision);
  return Math.round(number * factor) / factor;
};
const ASHBLAZING_ATK_STACK = 0.06;
// Remove the ashblazing set atk bonus only when calc-ing fua attacks
function calculateAshblazingSet(c, request, hitMulti) {
  let enabled = p4(c.sets.TheAshblazingGrandDuke);
  let valueTheAshblazingGrandDuke = request.setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_2__.Constants.Sets.TheAshblazingGrandDuke][1];
  let ashblazingAtk = 0.06 * valueTheAshblazingGrandDuke * enabled * c.baseAtk * enabled;
  let ashblazingMulti = hitMulti * enabled * c.baseAtk;
  return {
    ashblazingMulti,
    ashblazingAtk
  };
}
const characterOptionMapping = {
  1212: jingliu,
  1302: argenti,
  1008: arlan,
  1009: asta,
  1211: bailu,
  1205: blade,
  1101: bronya,
  1107: clara,
  1002: danheng,
  1208: fuxuan,
  1104: gepard,
  1210: guinaifen,
  1215: hanya,
  1013: herta,
  1003: himeko,
  1109: hook,
  1217: huohuo,
  1213: imbibitorlunae,
  // Simplified stacking logic, revisit
  1204: jingyuan,
  1005: kafka,
  1111: luka,
  1203: luocha,
  1110: lynx,
  1001: march7th,
  1105: natasha,
  1106: pela,
  1201: qingque,
  1108: sampo,
  1102: seele,
  1103: serval,
  1006: silverwolf,
  1206: sushang,
  1202: tingyun,
  1112: topaz,
  8001: physicaltrailblazer,
  8002: physicaltrailblazer,
  8003: firetrailblazer,
  8004: firetrailblazer,
  1004: welt,
  1209: yanqing,
  1207: yukong,
  1303: ruanmei,
  1305: drratio,
  1214: xueyi,
  1306: sparkle,
  1307: blackswan,
  1312: misha
};

// TODO profile & convert to array for performance?
const baseComputedStatsObject = {
  [Stats.HP_P]: 0,
  [Stats.ATK_P]: 0,
  [Stats.DEF_P]: 0,
  [Stats.SPD_P]: 0,
  [Stats.HP]: 0,
  [Stats.ATK]: 0,
  [Stats.DEF]: 0,
  [Stats.SPD]: 0,
  [Stats.CD]: 0,
  [Stats.CR]: 0,
  [Stats.EHR]: 0,
  [Stats.RES]: 0,
  [Stats.BE]: 0,
  [Stats.ERR]: 0,
  [Stats.OHB]: 0,
  ELEMENTAL_DMG: 0,
  DEF_SHRED: 0,
  DMG_TAKEN_MULTI: 0,
  ALL_DMG_MULTI: 0,
  RES_PEN: 0,
  DMG_RED_MULTI: 1,
  BASIC_CR_BOOST: 0,
  SKILL_CR_BOOST: 0,
  ULT_CR_BOOST: 0,
  FUA_CR_BOOST: 0,
  BASIC_CD_BOOST: 0,
  SKILL_CD_BOOST: 0,
  ULT_CD_BOOST: 0,
  FUA_CD_BOOST: 0,
  BASIC_SCALING: 0,
  SKILL_SCALING: 0,
  ULT_SCALING: 0,
  FUA_SCALING: 0,
  DOT_SCALING: 0,
  BASIC_BOOST: 0,
  SKILL_BOOST: 0,
  ULT_BOOST: 0,
  FUA_BOOST: 0,
  DOT_BOOST: 0,
  BASIC_VULNERABILITY: 0,
  SKILL_VULNERABILITY: 0,
  ULT_VULNERABILITY: 0,
  FUA_VULNERABILITY: 0,
  DOT_VULNERABILITY: 0,
  BASIC_DMG: 0,
  SKILL_DMG: 0,
  ULT_DMG: 0,
  FUA_DMG: 0,
  DOT_DMG: 0,
  BASIC_DEF_PEN: 0,
  SKILL_DEF_PEN: 0,
  ULT_DEF_PEN: 0,
  FUA_DEF_PEN: 0,
  DOT_DEF_PEN: 0,
  BASIC_RES_PEN: 0,
  SKILL_RES_PEN: 0,
  ULT_RES_PEN: 0,
  FUA_RES_PEN: 0,
  DOT_RES_PEN: 0
};
function xueyi(e) {
  let ultBoostMax = ult(e, 0.60, 0.648);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.40, 1.54);
  let ultScaling = ult(e, 2.50, 2.70);
  let fuaScaling = talent(e, 0.90, 0.99);
  let hitMultiByFuaHits = {
    0: 0,
    1: ASHBLAZING_ATK_STACK * (1 * 1 / 1),
    // 0.06
    2: ASHBLAZING_ATK_STACK * (1 * 1 / 2 + 2 * 1 / 2),
    // 0.09
    3: ASHBLAZING_ATK_STACK * (1 * 1 / 3 + 2 * 1 / 3 + 3 * 1 / 3) // 0.12
  };
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyToughness50",
        text: "Enemy toughness >= 50%"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 170,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "toughnessReductionDmgBoost",
        text: "Ult toughness based dmg boost",
        min: 0,
        max: ultBoostMax,
        percent: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 171,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "fuaHits",
        text: "Fua hits",
        min: 0,
        max: 3
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 172,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e4BeBuff",
        text: "E4 break effect buff",
        disabled: e < 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 173,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 169,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyToughness50: true,
      toughnessReductionDmgBoost: ultBoostMax,
      fuaHits: 3,
      e4BeBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.BE] += e >= 4 && r.e4BeBuff ? 0.40 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.FUA_SCALING += fuaScaling * r.fuaHits;

      // Boost
      x.ULT_BOOST += r.enemyToughness50 ? 0.10 : 0;
      x.ULT_BOOST += r.toughnessReductionDmgBoost;
      x.FUA_BOOST += e >= 1 ? 0.40 : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x.ELEMENTAL_DMG += Math.min(2.40, x[Stats.BE]);
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      let hitMulti = hitMultiByFuaHits[r.fuaHits];
      let {
        ashblazingMulti,
        ashblazingAtk
      } = calculateAshblazingSet(c, request, hitMulti);
      x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
    }
  };
}
function drratio(e) {
  let debuffStacksMax = 5;
  let summationStacksMax = e >= 1 ? 10 : 6;
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.50, 1.65);
  let ultScaling = ult(e, 2.40, 2.592);
  let fuaScaling = talent(e, 2.70, 2.97);
  function e2FuaRatio(procs, fua = true) {
    return fua ? fuaScaling / (fuaScaling + 0.20 * procs) // for fua dmg
    : 0.20 / (fuaScaling + 0.20 * procs); // for each e2 proc
  }
  let baseHitMulti = ASHBLAZING_ATK_STACK * (1 * 1 / 1);
  let fuaMultiByDebuffs = {
    0: ASHBLAZING_ATK_STACK * (1 * 1 / 1),
    // 0
    1: ASHBLAZING_ATK_STACK * (1 * e2FuaRatio(1, true) + 2 * e2FuaRatio(1, false)),
    // 2
    2: ASHBLAZING_ATK_STACK * (1 * e2FuaRatio(2, true) + 5 * e2FuaRatio(2, false)),
    // 2 + 3
    3: ASHBLAZING_ATK_STACK * (1 * e2FuaRatio(3, true) + 9 * e2FuaRatio(3, false)),
    // 2 + 3 + 4
    4: ASHBLAZING_ATK_STACK * (1 * e2FuaRatio(4, true) + 14 * e2FuaRatio(4, false)) // 2 + 3 + 4 + 5
  };
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "summationStacks",
        text: "Summation stacks",
        min: 0,
        max: summationStacksMax
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 246,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "enemyDebuffStacks",
        text: "Enemy debuffs",
        min: 0,
        max: debuffStacksMax
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 247,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 245,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyDebuffStacks: debuffStacksMax,
      summationStacks: summationStacksMax
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.CR] += r.summationStacks * 0.025;
      x[Stats.CD] += r.summationStacks * 0.05;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.FUA_SCALING += fuaScaling;

      // Boost
      x.ELEMENTAL_DMG += r.enemyDebuffStacks >= 3 ? Math.min(0.50, r.enemyDebuffStacks * 0.10) : 0;
      x.FUA_BOOST += e >= 6 ? 0.50 : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      if (e >= 2) {
        let hitMulti = fuaMultiByDebuffs[Math.min(4, r.enemyDebuffStacks)];
        let {
          ashblazingMulti,
          ashblazingAtk
        } = calculateAshblazingSet(c, request, hitMulti);
        x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
      } else {
        let {
          ashblazingMulti,
          ashblazingAtk
        } = calculateAshblazingSet(c, request, baseHitMulti);
        x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
      }
    }
  };
}
function ruanmei(e) {
  let fieldResPenValue = ult(e, 0.25, 0.27);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 0, 0);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultFieldActive",
        text: "Ult field active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 303,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e4BeBuff",
        text: "E4 break effect buff",
        disabled: e < 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 304,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 302,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultFieldActive: true,
      e4BeBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.BE] += 0.20;
      x[Stats.BE] += e >= 4 && r.e4BeBuff ? 1.00 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.RES_PEN += r.ultFieldActive ? fieldResPenValue : 0;
      x.DEF_SHRED += e >= 1 && r.ultFieldActive ? 0.20 : 0;
      x[Stats.ATK_P] += e >= 2 && request.enemyWeaknessBroken ? 0.40 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      let beOver = precisionRound((x[Stats.BE] * 100 - 120) / 10);
      x.ELEMENTAL_DMG += Math.floor(Math.max(0, beOver)) * 0.06;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function yukong(e) {
  let skillAtkBuffValue = skill(e, 0.80, 0.88);
  let ultCdBuffValue = skill(e, 0.65, 0.702);
  let ultCrBuffValue = skill(e, 0.28, 0.294);
  let talentAtkScaling = talent(e, 0.80, 0.88);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 3.80, 4.104);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "roaringBowstrings",
        text: "Roaring bowstrings"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 357,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultBuff",
        text: "Ult buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 358,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "initialSpeedBuff",
        text: "Initial speed buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 359,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 356,
      columnNumber: 7
    }, this),
    defaults: () => ({
      roaringBowstringsActive: true,
      ultBuff: true,
      initialSpeedBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.ATK_P] += r.roaringBowstrings ? skillAtkBuffValue : 0;
      x[Stats.CR] += r.ultBuff && r.roaringBowstrings ? ultCrBuffValue : 0;
      x[Stats.CD] += r.ultBuff && r.roaringBowstrings ? ultCdBuffValue : 0;
      x[Stats.SPD_P] += r.initialSpeedBuff ? 0.10 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.BASIC_SCALING += talentAtkScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.ELEMENTAL_DMG += 0.12;
      x.ELEMENTAL_DMG += e >= 4 && r.roaringBowstrings ? 0.30 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function yanqing(e) {
  let ultCdBuffValue = ult(e, 0.50, 0.54);
  let talentCdBuffValue = ult(e, 0.30, 0.33);
  let talentCrBuffValue = ult(e, 0.20, 0.21);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.20, 2.42);
  let ultScaling = ult(e, 3.50, 3.78);
  let fuaScaling = talent(e, 0.50, 0.55);
  let hitMulti = ASHBLAZING_ATK_STACK * (1 * 1 / 1);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultBuffActive",
        text: "Ult buff active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 414,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "soulsteelBuffActive",
        text: "Soulsteel buff active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 415,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "critSpdBuff",
        text: "Crit spd buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 416,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e1TargetFrozen",
        text: "E1 target frozen",
        disabled: e < 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 417,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e4CurrentHp80",
        text: "E4 self HP >= 80%",
        disabled: e < 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 418,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 413,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultBuffActive: true,
      soulsteelBuffActive: true,
      critSpdBuff: true,
      e1TargetFrozen: true,
      e4CurrentHp80: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.CR] += r.ultBuffActive ? 0.60 : 0;
      x[Stats.CD] += r.ultBuffActive && r.soulsteelBuffActive ? ultCdBuffValue : 0;
      x[Stats.CR] += r.soulsteelBuffActive ? talentCrBuffValue : 0;
      x[Stats.CD] += r.soulsteelBuffActive ? talentCdBuffValue : 0;
      x[Stats.RES] += r.soulsteelBuffActive ? 0.20 : 0;
      x[Stats.SPD_P] += r.critSpdBuff ? 0.10 : 0;
      x[Stats.ERR] += e >= 2 && r.soulsteelBuffActive ? 0.10 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.FUA_SCALING += fuaScaling;
      x.BASIC_SCALING += request.enemyElementalWeak ? 0.30 : 0;
      x.SKILL_SCALING += request.enemyElementalWeak ? 0.30 : 0;
      x.ULT_SCALING += request.enemyElementalWeak ? 0.30 : 0;
      x.FUA_SCALING += request.enemyElementalWeak ? 0.30 : 0;
      x.BASIC_SCALING += e >= 1 && r.e1TargetFrozen ? 0.60 : 0;
      x.SKILL_SCALING += e >= 1 && r.e1TargetFrozen ? 0.60 : 0;
      x.ULT_SCALING += e >= 1 && r.e1TargetFrozen ? 0.60 : 0;
      x.FUA_SCALING += e >= 1 && r.e1TargetFrozen ? 0.60 : 0;

      // Boost
      x.RES_PEN += e >= 4 && r.e4CurrentHp80 ? 0.12 : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      let {
        ashblazingMulti,
        ashblazingAtk
      } = calculateAshblazingSet(c, request, hitMulti);
      x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
    }
  };
}
function welt(e) {
  let skillExtraHitsMax = e >= 6 ? 3 : 2;
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 0.72, 0.792);
  let ultScaling = ult(e, 1.50, 1.62);
  let talentScaling = talent(e, 0.60, 0.66);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyDmgTakenDebuff",
        text: "Enemy dmg taken debuff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 486,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemySlowed",
        text: "Enemy slowed"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 487,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "skillExtraHits",
        text: "Skill extra hits",
        min: 0,
        max: skillExtraHitsMax
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 488,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e1EnhancedState",
        text: "E1 enhanced state",
        disabled: e < 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 489,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 485,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemySlowed: true,
      enemyDmgTakenDebuff: true,
      skillExtraHits: skillExtraHitsMax,
      e1EnhancedState: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.BASIC_SCALING += r.enemySlowed ? talentScaling : 0;
      x.SKILL_SCALING += r.enemySlowed ? talentScaling : 0;
      x.ULT_SCALING += r.enemySlowed ? talentScaling : 0;
      x.BASIC_SCALING += e >= 1 && r.e1EnhancedState ? 0.50 * basicScaling : 0;
      x.SKILL_SCALING += e >= 1 && r.e1EnhancedState ? 0.80 * skillScaling : 0;
      x.SKILL_SCALING += r.skillExtraHits * skillScaling;

      // Boost
      x.ELEMENTAL_DMG += request.enemyWeaknessBroken ? 0.20 : 0;
      x.DMG_TAKEN_MULTI += r.enemyDmgTakenDebuff ? 0.12 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      // x.FUA_DMG += 0
    }
  };
}
function firetrailblazer(e) {
  let skillDamageReductionValue = skill(e, 0.50, 0.52);
  let basicAtkScaling = basic(e, 1.00, 1.10);
  let basicDefScaling = e >= 1 ? 0.25 : 0;
  let basicEnhancedAtkScaling = basic(e, 1.35, 1.463);
  let basicEnhancedDefScaling = e >= 1 ? 0.50 : 0;
  let skillScaling = skill(e, 0, 0);
  let ultAtkScaling = ult(e, 1.00, 1.10);
  let ultDefScaling = ult(e, 1.50, 1.65);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enhancedBasic",
        text: "Enhanced basic"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 549,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillActive",
        text: "Skill active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 550,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "shieldActive",
        text: "Shield active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 551,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e6DefStacks",
        text: "E6 def stacks",
        min: 0,
        max: 3,
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 552,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 548,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enhancedBasic: true,
      skillActive: true,
      shieldActive: true,
      e6DefStacks: 3
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.DEF_P] += e >= 6 ? r.e6DefStacks * 0.10 : 0;
      x[Stats.ATK_P] += r.shieldActive ? 0.15 : 0;

      // Scaling
      x.SKILL_SCALING += skillScaling;

      // Boost
      x.DMG_RED_MULTI *= r.skillActive ? 1 - skillDamageReductionValue : 1;
      x.DMG_RED_MULTI *= r.skillActive ? 1 - 0.15 : 1;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      if (r.enhancedBasic) {
        x.BASIC_DMG += basicEnhancedAtkScaling * x[Stats.ATK];
        x.BASIC_DMG += basicEnhancedDefScaling * x[Stats.DEF];
      } else {
        x.BASIC_DMG += basicAtkScaling * x[Stats.ATK];
        x.BASIC_DMG += basicDefScaling * x[Stats.DEF];
      }
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += ultAtkScaling * x[Stats.ATK];
      x.ULT_DMG += ultDefScaling * x[Stats.DEF];
    }
  };
}
function physicaltrailblazer(e) {
  let talentAtkScalingValue = talent(e, 0.20, 0.22);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.25, 1.375);
  let ultScaling = ult(e, 4.5, 4.80);
  let ultEnhancedScaling = ult(e, 2.70, 2.88);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enhancedUlt",
        text: "Aoe ult"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 608,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentStacks",
        text: "Talent stacks",
        min: 0,
        max: 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 609,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 607,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enhancedUlt: true,
      talentStacks: 2
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.ATK_P] += r.talentStacks * talentAtkScalingValue;
      x[Stats.DEF_P] += r.talentStacks * 0.10;
      x[Stats.CR] += request.enemyWeaknessBroken ? 0.25 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += r.enhancedUlt ? ultEnhancedScaling : ultScaling;

      // Boost
      x.SKILL_BOOST += 0.25;
      x.ULT_BOOST += r.enhancedUlt ? 0.25 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function topaz(e) {
  let proofOfDebtFuaVulnerability = skill(e, 0.50, 0.55);
  let enhancedStateFuaScalingBoost = ult(e, 1.50, 1.65);
  let enhancedStateFuaCdBoost = ult(e, 0.25, 0.275);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.50, 1.65);
  let fuaScaling = talent(e, 1.50, 1.65);

  // 0.06
  let basicHitCountMulti = ASHBLAZING_ATK_STACK * (1 * 1 / 1);

  // 0.18
  let fuaHitCountMulti = ASHBLAZING_ATK_STACK * (1 * 1 / 7 + 2 * 1 / 7 + 3 * 1 / 7 + 4 * 1 / 7 + 5 * 1 / 7 + 6 * 1 / 7 + 7 * 1 / 7);

  // 0.252
  let fuaEnhancedHitCountMulti = ASHBLAZING_ATK_STACK * (1 * 1 / 10 + 2 * 1 / 10 + 3 * 1 / 10 + 4 * 1 / 10 + 5 * 1 / 10 + 6 * 1 / 10 + 7 * 1 / 10 + 8 * 3 / 10);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyProofOfDebtDebuff",
        text: "Target proof of debt debuff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 670,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "numbyEnhancedState",
        text: "Numby enhanced state"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 671,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e1DebtorStacks",
        text: "E1 debtor stacks",
        min: 0,
        max: 2,
        disabled: e < 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 672,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 669,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyProofOfDebtDebuff: true,
      numbyEnhancedState: true,
      e1DebtorStacks: 2
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.SKILL_SCALING += r.numbyEnhancedState ? enhancedStateFuaScalingBoost : 0;
      x.FUA_SCALING += fuaScaling;
      x.FUA_SCALING += r.numbyEnhancedState ? enhancedStateFuaScalingBoost : 0;

      // Boost
      x.FUA_VULNERABILITY += r.enemyProofOfDebtDebuff ? proofOfDebtFuaVulnerability : 0;
      x.ELEMENTAL_DMG += request.enemyElementalWeak ? 0.15 : 0;
      x.FUA_CD_BOOST += e >= 1 ? 0.25 * r.e1DebtorStacks : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      let hitMulti = r.numbyEnhancedState ? fuaEnhancedHitCountMulti : fuaHitCountMulti;
      let ashblazingFuaData = calculateAshblazingSet(c, request, hitMulti);
      let ashblazingBasicData = calculateAshblazingSet(c, request, basicHitCountMulti);
      x.BASIC_DMG += x.BASIC_SCALING * (x[Stats.ATK] - ashblazingBasicData.ashblazingAtk + ashblazingBasicData.ashblazingMulti);
      x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingFuaData.ashblazingAtk + ashblazingFuaData.ashblazingMulti);
      x.SKILL_DMG = x.FUA_DMG;

      // Copy fua boosts to skill/basic
      // BOOSTS get added, while vulnerability / def pen gets replaced (?)
      x.SKILL_BOOST += x.FUA_BOOST;
      x.SKILL_CD_BOOST += x.FUA_CD_BOOST;
      x.SKILL_CR_BOOST += x.FUA_CR_BOOST;
      x.SKILL_VULNERABILITY = x.FUA_VULNERABILITY;
      x.SKILL_DEF_PEN = x.FUA_DEF_PEN;
      x.SKILL_RES_PEN = x.FUA_RES_PEN;
      x.BASIC_BOOST += x.FUA_BOOST;
      x.BASIC_CD_BOOST += x.FUA_CD_BOOST;
      x.BASIC_CR_BOOST += x.FUA_CR_BOOST;
      x.BASIC_VULNERABILITY = x.FUA_VULNERABILITY;
      x.BASIC_DEF_PEN = x.FUA_DEF_PEN;
      x.BASIC_RES_PEN = x.FUA_RES_PEN;

      // Her ult buff only applies to the skill/fua not basic
      x.FUA_CD_BOOST += r.numbyEnhancedState ? enhancedStateFuaCdBoost : 0;
      x.SKILL_CD_BOOST += r.numbyEnhancedState ? enhancedStateFuaCdBoost : 0;

      // Her e6 only applies to skill/fua not basic
      x.SKILL_RES_PEN += e >= 6 ? 0.10 : 0;
      x.FUA_RES_PEN += e >= 6 ? 0.10 : 0;
    }
  };
}
function tingyun(e) {
  let skillAtkBoostMax = skill(e, 0.25, 0.27);
  let ultDmgBoost = ult(e, 0.50, 0.56);
  // let skillAtkBoostScaling = skill(e, 0.50, 0.55) + ((e >= 4) ? 0.20 : 0)
  // let talentScaling = talent(e, 0.60, 0.66) + ((e >= 4) ? 0.20 : 0)

  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 0, 0);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "benedictionBuff",
        text: "Benediction buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 753,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillSpdBuff",
        text: "Skill spd buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 754,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultSpdBuff",
        text: "Ult spd buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 755,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultDmgBuff",
        text: "Ult dmg buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 756,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 752,
      columnNumber: 7
    }, this),
    defaults: () => ({
      benedictionBuff: false,
      skillSpdBuff: false,
      ultSpdBuff: false,
      ultDmgBuff: false
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.SPD_P] += e >= 1 && r.ultSpdBuff ? 0.20 : 0;
      x[Stats.SPD_P] += r.skillSpdBuff ? 0.20 : 0;
      x[Stats.ATK_P] += r.benedictionBuff ? skillAtkBoostMax : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.BASIC_BOOST += 0.40;
      x.ELEMENTAL_DMG += r.ultDmgBuff ? ultDmgBoost : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function sushang(e) {
  let talentSpdBuffValue = talent(e, 0.20, 0.21);
  let ultBuffedAtk = ult(e, 0.30, 0.324);
  let talentSpdBuffStacksMax = e >= 6 ? 2 : 1;
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.10, 2.31);
  let skillExtraHitScaling = skill(e, 1.00, 1.10);
  let ultScaling = ult(e, 3.20, 3.456);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultBuffedState",
        text: "Ult buffed state"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 808,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "skillExtraHits",
        text: "Skill extra hits",
        min: 0,
        max: 3
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 809,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "skillTriggerStacks",
        text: "Skill trigger stacks",
        min: 0,
        max: 10
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 810,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentSpdBuffStacks",
        text: "Talent spd buff stacks",
        min: 0,
        max: talentSpdBuffStacksMax
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 811,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2DmgReductionBuff",
        text: "E2 dmg reduction",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 812,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 807,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultBuffedState: true,
      e2DmgReductionBuff: true,
      skillExtraHits: 3,
      skillTriggerStacks: 10,
      talentSpdBuffStacks: talentSpdBuffStacksMax
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.BE] += e >= 4 ? 0.40 : 0;
      x[Stats.ATK_P] += r.ultBuffedState ? ultBuffedAtk : 0;
      x[Stats.SPD_P] += r.talentSpdBuffStacks * talentSpdBuffValue;

      // Scaling
      // Trace only affects stance damage not skill damage - boost this based on proportion of stance : total skill dmg
      let originalSkillScaling = skillScaling;
      let stanceSkillScaling = 0;
      stanceSkillScaling += r.skillExtraHits >= 1 ? skillExtraHitScaling : 0;
      stanceSkillScaling += r.ultBuffedState && r.skillExtraHits >= 2 ? skillExtraHitScaling * 0.5 : 0;
      stanceSkillScaling += r.ultBuffedState && r.skillExtraHits >= 3 ? skillExtraHitScaling * 0.5 : 0;
      let stanceScalingProportion = stanceSkillScaling / (stanceSkillScaling + originalSkillScaling);
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += originalSkillScaling;
      x.SKILL_SCALING += stanceSkillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.SKILL_BOOST += r.skillTriggerStacks * 0.025 * stanceScalingProportion;
      x.DMG_RED_MULTI *= e >= 2 && r.e2DmgReductionBuff ? 1 - 0.20 : 1;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      // x.FUA_DMG += 0
    }
  };
}
function silverwolf(e) {
  let skillResShredValue = skill(e, 0.10, 0.105);
  let skillDefShredBufValue = skill(e, 0.08, 0.088);
  let ultDefShredValue = ult(e, 0.45, 0.468);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.96, 2.156);
  let ultScaling = ult(e, 3.80, 4.104);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillResShredDebuff",
        text: "Skill res shred"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 874,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillDefShredDebuff",
        text: "Skill def shred"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 875,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultDefShredDebuff",
        text: "Ult def shred"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 876,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "targetDebuffs",
        text: "Target debuffs",
        min: 0,
        max: 5
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 877,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 873,
      columnNumber: 7
    }, this),
    defaults: () => ({
      skillResShredDebuff: true,
      skillDefShredDebuff: true,
      ultDefShredDebuff: true,
      targetDebuffs: 5
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.ULT_SCALING += e >= 4 ? r.targetDebuffs * 0.20 : 0;

      // Boost
      x.RES_PEN += r.skillResShredDebuff ? skillResShredValue : 0;
      x.RES_PEN += r.skillResShredDebuff && r.targetDebuffs >= 3 ? 0.03 : 0;
      x.DEF_SHRED += r.skillDefShredDebuff ? skillDefShredBufValue : 0;
      x.DEF_SHRED += r.ultDefShredDebuff ? ultDefShredValue : 0;
      x.ELEMENTAL_DMG += e >= 6 ? r.targetDebuffs * 0.20 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      // x.FUA_DMG += 0
    }
  };
}
function serval(e) {
  let talentExtraDmgScaling = talent(e, 0.72, 0.792);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.40, 1.54);
  let ultScaling = ult(e, 1.80, 1.944);
  let dotScaling = skill(e, 1.04, 1.144);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetShocked",
        text: "Target shocked"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 929,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyDefeatedBuff",
        text: "Enemy killed buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 930,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 928,
      columnNumber: 7
    }, this),
    defaults: () => ({
      targetShocked: true,
      enemyDefeatedBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.ATK_P] += r.enemyDefeatedBuff ? 0.20 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.DOT_SCALING += dotScaling;
      x.BASIC_SCALING += r.targetShocked ? talentExtraDmgScaling : 0;
      x.SKILL_SCALING += r.targetShocked ? talentExtraDmgScaling : 0;
      x.ULT_SCALING += r.targetShocked ? talentExtraDmgScaling : 0;

      // Boost
      x.ELEMENTAL_DMG += e >= 6 && r.targetShocked ? 0.30 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.DOT_DMG += x.DOT_SCALING * x[Stats.ATK];
    }
  };
}
function seele(e) {
  let buffedStateDmgBuff = talent(e, 0.80, 0.88);
  let speedBoostStacksMax = e >= 2 ? 2 : 1;
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.20, 2.42);
  let ultScaling = ult(e, 4.25, 4.59);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "buffedState",
        text: "Buffed state"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 981,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "speedBoostStacks",
        text: "Speed boost stacks",
        min: 0,
        max: speedBoostStacksMax
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 982,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e6UltTargetDebuff",
        text: "E6 ult debuff",
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 983,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 980,
      columnNumber: 7
    }, this),
    defaults: () => ({
      buffedState: true,
      speedBoostStacks: speedBoostStacksMax,
      e6UltTargetDebuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.CR] += e >= 1 && request.enemyHpPercent <= 0.80 ? 0.15 : 0;
      x[Stats.SPD_P] += 0.25 * r.speedBoostStacks;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.ELEMENTAL_DMG += r.buffedState ? buffedStateDmgBuff : 0;
      x.RES_PEN += r.buffedState ? 0.20 : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.BASIC_DMG += e >= 6 && r.e6UltTargetDebuff ? 0.15 * x.ULT_DMG : 0;
      x.SKILL_DMG += e >= 6 && r.e6UltTargetDebuff ? 0.15 * x.ULT_DMG : 0;
      x.ULT_DMG += e >= 6 && r.e6UltTargetDebuff ? 0.15 * x.ULT_DMG : 0;
    }
  };
}
function sampo(e) {
  let dotVulnerabilityValue = ult(e, 0.30, 0.32);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 0.56, 0.616);
  let ultScaling = ult(e, 1.60, 1.728);
  let dotScaling = talent(e, 0.52, 0.572);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetDotTakenDebuff",
        text: "Ult dot taken debuff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1036,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "skillExtraHits",
        text: "Skill extra hits",
        min: 0,
        max: 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1037,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetWindShear",
        text: "Target has wind shear"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1038,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1035,
      columnNumber: 7
    }, this),
    defaults: () => ({
      targetDotTakenDebuff: true,
      skillExtraHits: 4,
      targetWindShear: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.SKILL_SCALING += r.skillExtraHits * skillScaling;
      x.ULT_SCALING += ultScaling;
      x.DOT_SCALING += dotScaling;
      x.DOT_SCALING += e >= 6 ? 0.15 : 0;

      // Boost
      x.DOT_VULNERABILITY += r.targetDotTakenDebuff ? dotVulnerabilityValue : 0;
      x.DMG_RED_MULTI *= r.targetWindShear ? 1 - 0.15 : 1;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.DOT_DMG += x.DOT_SCALING * x[Stats.ATK];
    }
  };
}
function qingque(e) {
  let skillStackDmg = skill(e, 0.38, 0.408);
  let talentAtkBuff = talent(e, 0.72, 0.792);
  let basicScaling = basic(e, 1.00, 1.10);
  let basicEnhancedScaling = basic(e, 2.40, 2.64);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 2.00, 2.16);
  let hitMultiByTargetsBlast = {
    1: ASHBLAZING_ATK_STACK * (1 * 1 / 1),
    // 0.06
    3: ASHBLAZING_ATK_STACK * (2 * 1 / 1),
    // 0.12
    5: ASHBLAZING_ATK_STACK * (2 * 1 / 1) // 0.12
  };
  let hitMultiSingle = ASHBLAZING_ATK_STACK * (1 * 1 / 1);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "basicEnhanced",
        text: "Basic enhanced"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1097,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "basicEnhancedSpdBuff",
        text: "Basic enhanced spd buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1098,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "skillDmgIncreaseStacks",
        text: "Skill dmg stacks",
        min: 0,
        max: 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1099,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1096,
      columnNumber: 7
    }, this),
    defaults: () => ({
      basicEnhanced: true,
      basicEnhancedSpdBuff: true,
      skillDmgIncreaseStacks: 4
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.ATK_P] += r.basicEnhanced ? talentAtkBuff : 0;
      x[Stats.SPD_P] += r.basicEnhancedSpdBuff ? 0.10 : 0;

      // Scaling
      x.BASIC_SCALING += r.basicEnhanced ? basicEnhancedScaling : basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.FUA_SCALING += e >= 4 ? x.BASIC_SCALING : 0;

      // Boost
      x.ELEMENTAL_DMG += r.skillDmgIncreaseStacks * skillStackDmg;
      x.ULT_BOOST += e >= 1 ? 0.10 : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      if (r.basicEnhanced) {
        let hitMulti = hitMultiByTargetsBlast[request.enemyCount];
        let {
          ashblazingMulti,
          ashblazingAtk
        } = calculateAshblazingSet(c, request, hitMulti);
        x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
      } else {
        let {
          ashblazingMulti,
          ashblazingAtk
        } = calculateAshblazingSet(c, request, hitMultiSingle);
        x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
      }
    }
  };
}
function pela(e) {
  let ultDefPenValue = ult(e, 0.40, 0.42);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.10, 2.31);
  let ultScaling = ult(e, 1.00, 1.08);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyDebuffed",
        text: "Enemy debuffed"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1157,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillRemovedBuff",
        text: "Skill removed buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1158,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultDefPenDebuff",
        text: "Ult def pen debuff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1159,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e4SkillResShred",
        text: "E4 skill res shred",
        disabled: e < 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1160,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1156,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyDebuffed: true,
      skillRemovedBuff: true,
      ultDefPenDebuff: true,
      e4SkillResShred: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.EHR] += 0.10;
      x[Stats.SPD_P] += e >= 2 && r.skillRemovedBuff ? 0.10 : 0;
      x[Stats.SPD_P] += e >= 2 && r.skillRemovedBuff ? 0.10 : 0;
      x[Stats.SPD_P] += e >= 2 && r.skillRemovedBuff ? 0.10 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.BASIC_BOOST += r.skillRemovedBuff ? 0.20 : 0;
      x.SKILL_BOOST += r.skillRemovedBuff ? 0.20 : 0;
      x.ULT_BOOST += r.skillRemovedBuff ? 0.20 : 0;
      x.RES_PEN += e >= 4 && r.e4SkillResShred ? 0.12 : 0;
      x.DEF_SHRED += r.ultDefPenDebuff ? ultDefPenValue : 0;
      x.ELEMENTAL_DMG += r.enemyDebuffed ? 0.20 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.BASIC_DMG += e >= 6 ? 0.40 * x[Stats.ATK] : 0;
      x.SKILL_DMG += e >= 6 ? 0.40 * x[Stats.ATK] : 0;
      x.ULT_DMG += e >= 6 ? 0.40 * x[Stats.ATK] : 0;
    }
  };
}
function natasha(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 0, 0);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1217,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: () => {
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost

      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.BASIC_DMG += e >= 6 ? 0.40 * x[Stats.HP] : 0;
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function march7th(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 1.50, 1.62);
  let fuaScaling = talent(e, 1.00, 1.10);
  let hitMulti = ASHBLAZING_ATK_STACK * (1 * 1 / 1);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1257,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: () => {
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.FUA_SCALING += fuaScaling;

      // Boost

      return x;
    },
    calculateBaseMultis: (c, request) => {
      let x = c.x;
      let {
        ashblazingMulti,
        ashblazingAtk
      } = calculateAshblazingSet(c, request, hitMulti);
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
      x.FUA_DMG += e >= 4 ? 0.30 * x[Stats.DEF] : 0;
    }
  };
}
function lynx(e) {
  let skillHpPercentBuff = skill(e, 0.075, 0.08);
  let skillHpFlatBuff = skill(e, 200, 223);
  let basicScaling = basic(e, 0.50, 0.55);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 0, 0);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillBuff",
        text: "Skill buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1302,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1301,
      columnNumber: 7
    }, this),
    defaults: () => ({
      skillBuff: true,
      e4TalentAtkBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.HP_P] += r.skillBuff ? skillHpPercentBuff : 0;
      x[Stats.HP] += r.skillBuff ? skillHpFlatBuff : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost

      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x[Stats.HP] += e >= 6 && r.skillBuff ? 0.06 * x[Stats.HP] : 0;
      x[Stats.ATK] += e >= 4 && r.skillBuff ? 0.03 * x[Stats.HP] : 0;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.HP];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      // x.FUA_DMG += 0
    }
  };
}
function luocha(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 2.00, 2.16);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "fieldActive",
        text: "Field active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1349,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e6ResReduction",
        text: "E6 res reduction",
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1350,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1348,
      columnNumber: 7
    }, this),
    defaults: () => ({
      fieldActive: true,
      e6ResReduction: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.ATK_P] += r >= 1 && r.fieldActive ? 0.20 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.RES_PEN += e >= 6 && r.e6ResReduction ? 0.20 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      // x.FUA_DMG += 0
    }
  };
}
function luka(e) {
  let basicEnhancedHitValue = basic(e, 0.20, 0.22);
  let targetUltDebuffDmgTakenValue = ult(e, 0.20, 0.216);
  let basicScaling = basic(e, 1.00, 1.10);
  let basicEnhancedScaling = basic(e, 0.20 * 3 + 0.80, 0.22 * 3 + 0.88);
  let skillScaling = skill(e, 1.20, 1.32);
  let ultScaling = ult(e, 3.30, 3.564);
  let dotScaling = skill(e, 3.38, 3.718);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "basicEnhanced",
        text: "Basic enhanced"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1398,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetUltDebuffed",
        text: "Target ult debuffed"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1399,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "basicEnhancedExtraHits",
        text: "Basic extra hits",
        min: 0,
        max: 3
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1400,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e1TargetBleeding",
        text: "E1 target bleeding",
        disabled: e < 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1401,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e4TalentStacks",
        text: "E4 talent stacks",
        min: 0,
        max: 4,
        disabled: e < 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1402,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1397,
      columnNumber: 7
    }, this),
    defaults: () => ({
      basicEnhanced: true,
      targetUltDebuffed: true,
      e1TargetBleeding: true,
      basicEnhancedExtraHits: 3,
      e4TalentStacks: 4
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.ATK_P] += e >= 4 ? r.e4TalentStacks * 0.05 : 0;

      // Scaling
      x.BASIC_SCALING += r.basicEnhanced ? basicEnhancedScaling : basicScaling;
      x.BASIC_SCALING += (r.basicEnhanced && r.basicEnhancedExtraHits) * basicEnhancedHitValue;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.DOT_SCALING += dotScaling;

      // Boost
      x.DMG_TAKEN_MULTI += r.targetUltDebuffed ? targetUltDebuffDmgTakenValue : 0;
      x.ELEMENTAL_DMG += e >= 1 && r.e1TargetBleeding ? 0.15 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.DOT_DMG += x.DOT_SCALING * x[Stats.ATK];
      // x.FUA_DMG += 0
    }
  };
}
function kafka(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.60, 1.76);
  let ultScaling = ult(e, 0.80, 0.864);
  let fuaScaling = talent(e, 1.40, 1.596);
  let dotScaling = ult(e, 2.90, 3.183);
  let hitMulti = ASHBLAZING_ATK_STACK * (1 * 0.15 + 2 * 0.15 + 3 * 0.15 + 4 * 0.15 + 5 * 0.15 + 6 * 0.25);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e1DotDmgReceivedDebuff",
        text: "E1 dot dmg debuff",
        disabled: e < 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1458,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1457,
      columnNumber: 7
    }, this),
    defaults: () => ({
      e1DotDmgReceivedDebuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.FUA_SCALING += fuaScaling;
      x.DOT_SCALING += dotScaling;

      // Boost
      x.DOT_VULNERABILITY += e >= 1 && r.e1DotDmgReceivedDebuff ? 0.30 : 0;
      x.DOT_BOOST += e >= 2 ? 0.25 : 0;
      x.DOT_SCALING += e >= 6 ? 1.56 : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let x = c.x;
      let {
        ashblazingMulti,
        ashblazingAtk
      } = calculateAshblazingSet(c, request, hitMulti);
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
      x.DOT_DMG += x.DOT_SCALING * x[Stats.ATK];
    }
  };
}
function jingyuan(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.00, 1.10);
  let ultScaling = ult(e, 2.00, 2.16);
  let fuaScaling = talent(e, 0.66, 0.726);
  let hitMulti = 0;
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillCritBuff",
        text: "Skill cr buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1509,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentHitsPerAction",
        text: "Talent stacks",
        min: 3,
        max: 10
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1510,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentAttacks",
        text: "Talent hit on target",
        min: 0,
        max: 10
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1511,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2DmgBuff",
        text: "E2 dmg buff",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1512,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e6FuaVulnerabilityStacks",
        text: "E6 vulnerable stacks (applies to all hits)",
        min: 0,
        max: 3,
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1513,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1508,
      columnNumber: 7
    }, this),
    defaults: () => ({
      skillCritBuff: true,
      talentHitsPerAction: 10,
      talentAttacks: 10,
      e2DmgBuff: true,
      e6FuaVulnerabilityStacks: 3
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);
      r.talentHitsPerAction = Math.max(r.talentHitsPerAction, r.talentAttacks);

      // Stats
      x[Stats.CR] += r.skillCritBuff ? 0.10 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.FUA_SCALING += fuaScaling;

      // Boost
      x.FUA_CD_BOOST += r.talentHitsPerAction >= 6 ? 0.25 : 0;
      x.BASIC_BOOST += e >= 2 && r.e2DmgBuff ? 0.20 : 0;
      x.SKILL_BOOST += e >= 2 && r.e2DmgBuff ? 0.20 : 0;
      x.ULT_BOOST += e >= 2 && r.e2DmgBuff ? 0.20 : 0;
      x.FUA_VULNERABILITY += e >= 6 ? r.e6FuaVulnerabilityStacks * 0.12 : 0;

      // Lightning lord calcs
      let stacks = r.talentHitsPerAction;
      let hits = r.talentAttacks;
      let stacksPerMiss = request.enemyCount >= 3 ? 2 : 0;
      let stacksPerHit = request.enemyCount >= 3 ? 3 : 1;
      let stacksPreHit = request.enemyCount >= 3 ? 2 : 1;

      // Calc stacks on miss
      let ashblazingStacks = stacksPerMiss * (stacks - hits);

      // Calc stacks on hit
      ashblazingStacks += stacksPreHit;
      let atkBoostSum = 0;
      for (let i = 0; i < hits; i++) {
        atkBoostSum += Math.min(8, ashblazingStacks) * (1 / hits);
        ashblazingStacks += stacksPerHit;
      }
      hitMulti = atkBoostSum * 0.06;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      let {
        ashblazingMulti,
        ashblazingAtk
      } = calculateAshblazingSet(c, request, hitMulti);
      x.FUA_DMG += x.FUA_SCALING * r.talentAttacks * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
    }
  };
}
function imbibitorlunae(e) {
  let righteousHeartStackMax = e >= 1 ? 10 : 6;
  let outroarStackCdValue = skill(e, 0.12, 0.132);
  let righteousHeartDmgValue = talent(e, 0.10, 0.11);
  let basicScaling = basic(e, 1.00, 1.10);
  let basicEnhanced1Scaling = basic(e, 2.60, 2.86);
  let basicEnhanced2Scaling = basic(e, 3.80, 4.18);
  let basicEnhanced3Scaling = basic(e, 5.00, 5.50);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 3.00, 3.24);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "basicEnhancements",
        text: "Basic enhancements",
        min: 0,
        max: 3
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1597,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "skillOutroarStacks",
        text: "Outroar stacks (applied to all hits)",
        min: 0,
        max: 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1598,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentRighteousHeartStacks",
        text: "Righteous Heart stacks (applied to all hits)",
        min: 0,
        max: righteousHeartStackMax
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1599,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e6ResPenStacks",
        text: "E6 RES pen stacks",
        min: 0,
        max: 3,
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1600,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1596,
      columnNumber: 7
    }, this),
    defaults: () => ({
      basicEnhancements: 3,
      skillOutroarStacks: 4,
      talentRighteousHeartStacks: righteousHeartStackMax,
      e6ResPenStacks: 3
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.CD] += request.enemyElementalWeak ? 0.24 : 0;
      x[Stats.CD] += r.skillOutroarStacks * outroarStackCdValue;

      // Scaling
      x.BASIC_SCALING += {
        0: basicScaling,
        1: basicEnhanced1Scaling,
        2: basicEnhanced2Scaling,
        3: basicEnhanced3Scaling
      }[r.basicEnhancements];
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.ELEMENTAL_DMG += r.talentRighteousHeartStacks * righteousHeartDmgValue;
      x.BASIC_RES_PEN += e >= 6 && r.basicEnhancements == 3 ? 0.20 * r.e6ResPenStacks : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function huohuo(e) {
  let ultBuffValue = ult(e, 0.40, 0.432);
  let basicScaling = basic(e, 0.50, 0.55);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultBuff",
        text: "Ult buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1649,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillBuff",
        text: "Skill buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1650,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e6DmgBuff",
        text: "E6 dmg buff",
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1651,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1648,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultBuff: true,
      skillBuff: true,
      e6DmgBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.SPD_P] += e >= 1 && r.skillBuff ? 0.12 : 0;
      x[Stats.ATK_P] += r.ultBuff ? ultBuffValue : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;

      // Boost
      x.ELEMENTAL_DMG += e >= 6 && r.skillBuff ? 0.50 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.HP];
    }
  };
}
function hook(e) {
  let targetBurnedExtraScaling = talent(e, 1.00, 1.10);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.40, 2.64);
  let skillEnhancedScaling = skill(e, 2.80, 3.08);
  let ultScaling = ult(e, 4.00, 4.32);
  let dotScaling = skill(e, 0.65, 0.715);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enhancedSkill",
        text: "Enhanced skill"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1695,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetBurned",
        text: "Target burned"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1696,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1694,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enhancedSkill: true,
      targetBurned: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += r.enhancedSkill ? skillEnhancedScaling : skillScaling;
      x.ULT_SCALING += ultScaling;
      x.BASIC_SCALING += r.targetBurned ? targetBurnedExtraScaling : 0;
      x.SKILL_SCALING += r.targetBurned ? targetBurnedExtraScaling : 0;
      x.ULT_SCALING += r.targetBurned ? targetBurnedExtraScaling : 0;
      x.DOT_SCALING += dotScaling;

      // Boost
      x.SKILL_BOOST += e >= 1 && r.enhancedSkill ? 0.20 : 0;
      x.ELEMENTAL_DMG += e >= 6 && r.targetBurned ? 0.20 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.DOT_DMG += x.DOT_SCALING * x[Stats.ATK];
    }
  };
}
function himeko(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.00, 2.20);
  let ultScaling = ult(e, 2.30, 2.484);
  let fuaScaling = talent(e, 1.40, 1.54);
  let dotScaling = 0.30;
  let hitMultiByTargets = {
    1: ASHBLAZING_ATK_STACK * (1 * 0.20 + 2 * 0.20 + 3 * 0.20 + 4 * 0.40),
    // 0.168
    3: ASHBLAZING_ATK_STACK * (2 * 0.20 + 5 * 0.20 + 8 * 0.20 + 8 * 0.40),
    // 0.372
    5: ASHBLAZING_ATK_STACK * (3 * 0.20 + 8 * 0.20 + 8 * 0.20 + 8 * 0.40) // 0.42
  };
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetBurned",
        text: "Target burned"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1750,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "selfCurrentHp80Percent",
        text: "Self HP >= 80%"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1751,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e1TalentSpdBuff",
        text: "E1 spd buff",
        disabled: e < 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1752,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e6UltExtraHits",
        text: "E6 ult extra hits",
        min: 0,
        max: 2,
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1753,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1749,
      columnNumber: 7
    }, this),
    defaults: () => ({
      targetBurned: true,
      selfCurrentHp80Percent: true,
      e1TalentSpdBuff: true,
      e6UltExtraHits: 2
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.CR] += r.selfCurrentHp80Percent ? 0.15 : 0;
      x[Stats.SPD_P] += e >= 1 && r.e1TalentSpdBuff ? 0.20 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.ULT_SCALING += e >= 6 ? r.e6UltExtraHits * ultScaling * 0.40 : 0;
      x.FUA_SCALING += fuaScaling;
      x.DOT_SCALING += dotScaling;

      // Boost
      x.SKILL_BOOST += r.targetBurned ? 0.20 : 0;
      x.ELEMENTAL_DMG += e >= 2 && request.enemyHpPercent <= 0.50 ? 0.15 : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.DOT_DMG += x.DOT_SCALING * x[Stats.ATK];
      let hitMulti = hitMultiByTargets[request.enemyCount];
      let {
        ashblazingMulti,
        ashblazingAtk
      } = calculateAshblazingSet(c, request, hitMulti);
      x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
    }
  };
}
function herta(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.00, 1.10);
  let ultScaling = ult(e, 2.00, 2.16);
  let fuaScaling = talent(e, 0.40, 0.43);
  let hitMultiByTargets = {
    1: ASHBLAZING_ATK_STACK * (1 * 1 / 1),
    3: ASHBLAZING_ATK_STACK * (2 * 1 / 1),
    5: ASHBLAZING_ATK_STACK * (3 * 1 / 1)
  };
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "techniqueBuff",
        text: "Technique buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1814,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetFrozen",
        text: "Target frozen"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1815,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e2TalentCritStacks",
        text: "E2 talent crit stacks",
        min: 0,
        max: 5,
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1816,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e6UltAtkBuff",
        text: "E6 ult atk buff",
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1817,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1813,
      columnNumber: 7
    }, this),
    defaults: () => ({
      techniqueBuff: true,
      targetFrozen: true,
      e2TalentCritStacks: 5,
      e6UltAtkBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.ATK_P] += r.techniqueBuff ? 0.40 : 0;
      x[Stats.CR] += e >= 2 ? r.e2TalentCritStacks * 0.03 : 0;
      x[Stats.ATK_P] += e >= 6 && r.e6UltAtkBuff ? 0.25 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.BASIC_SCALING += e >= 1 && request.enemyHpPercent <= 0.50 ? 0.40 : 0;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.FUA_SCALING += fuaScaling;
      x.SKILL_BOOST += request.enemyHpPercent >= 0.50 ? 0.45 : 0;

      // Boost
      x.ULT_BOOST += r.targetFrozen ? 0.20 : 0;
      x.FUA_BOOST += e >= 4 ? 0.10 : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      let hitMulti = hitMultiByTargets[request.enemyCount];
      let {
        ashblazingMulti,
        ashblazingAtk
      } = calculateAshblazingSet(c, request, hitMulti);
      x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
    }
  };
}
function hanya(e) {
  let ultSpdBuffValue = ult(e, 0.20, 0.21);
  let ultAtkBuffValue = ult(e, 0.60, 0.648);
  let talentDmgBoostValue = talent(e, 0.30, 0.33);
  talentDmgBoostValue += e >= 6 ? 0.10 : 0;
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.40, 2.64);
  let ultScaling = ult(e, 0, 0);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultBuff",
        text: "Ult buff active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1878,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetBurdenActive",
        text: "Target burden active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1879,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "burdenAtkBuff",
        text: "Burden atk buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1880,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2SkillSpdBuff",
        text: "E2 skill spd buff",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1881,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1877,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultBuff: true,
      targetBurdenActive: true,
      burdenAtkBuff: true,
      skillSpdBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x[Stats.ATK_P] += r.ultBuff ? ultAtkBuffValue : 0;
      x[Stats.ATK_P] += r.burdenAtkBuff ? 0.10 : 0;
      x[Stats.SPD_P] += e >= 2 && r.e2SkillSpdBuff ? 0.20 : 0;

      // Boost
      x.ALL_DMG_MULTI = r.targetBurdenActive ? talentDmgBoostValue : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x[Stats.SPD] += r.ultBuff ? ultSpdBuffValue * x[Stats.SPD] : 0;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function guinaifen(e) {
  let talentDebuffDmgIncreaseValue = talent(e, 0.07, 0.076);
  let talentDebuffMax = e >= 6 ? 4 : 3;
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.20, 1.32);
  let ultScaling = ult(e, 1.20, 1.296);
  let dotScaling = skill(e, 2.182, 2.40);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentDebuffStacks",
        text: "Talent debuff stacks",
        min: 0,
        max: talentDebuffMax
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1935,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyBurned",
        text: "Enemy burned"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1936,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2BurnMultiBoost",
        text: "E2 burn multi boost",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1937,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 1934,
      columnNumber: 7
    }, this),
    defaults: () => ({
      talentDebuffStacks: talentDebuffMax,
      enemyBurned: true,
      e2BurnMultiBoost: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.DOT_SCALING += dotScaling;
      x.DOT_SCALING += e >= 2 && r.e2BurnMultiBoost ? 0.40 : 0;

      // Boost
      x.ELEMENTAL_DMG += r.enemyBurned ? 0.20 : 0;
      x.DMG_TAKEN_MULTI += r.talentDebuffStacks * talentDebuffDmgIncreaseValue;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.DOT_DMG += x.DOT_SCALING * x[Stats.ATK];
    }
  };
}
function gepard(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.00, 2.20);
  let ultScaling = ult(e, 0, 0);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1983,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: () => {
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.RES] += 0.20;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost

      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x[Stats.ATK] += 0.35 * x[Stats.DEF];
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
    }
  };
}
function fuxuan(e) {
  let skillCrBuffValue = skill(e, 0.12, 0.132);
  let skillHpBuffValue = skill(e, 0.06, 0.066);
  let talentDmgReductionValue = talent(e, 0.18, 0.196);
  let basicScaling = basic(e, 0.50, 0.55);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 1.00, 1.08);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillActive",
        text: "Skill active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2026,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e6TeamHpLostPercent",
        text: "E6 team hp lost",
        min: 0,
        max: 1.2,
        percent: true,
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2027,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2025,
      columnNumber: 7
    }, this),
    defaults: () => ({
      skillActive: true,
      e6TeamHpLostPercent: 1.2
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.CD] += e >= 1 ? 0.30 : 0;
      x[Stats.CR] += r.skillActive ? skillCrBuffValue : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.DMG_RED_MULTI *= 1 - talentDmgReductionValue;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x[Stats.HP] += r.skillActive ? skillHpBuffValue * x[Stats.HP] : 0;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.HP];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.HP];
      x.ULT_DMG += e >= 6 ? 2.00 * r.e6TeamHpLostPercent * x[Stats.HP] : 0;
    }
  };
}
function danheng(e) {
  let extraPenValue = talent(e, 0.36, 0.396);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.60, 2.86);
  let ultScaling = ult(e, 4.00, 4.32);
  let ultExtraScaling = ult(e, 1.20, 1.296);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "talentPenBuff",
        text: "Talent pen buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2075,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemySlowed",
        text: "Enemy slowed"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2076,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2074,
      columnNumber: 7
    }, this),
    defaults: () => ({
      talentPenBuff: true,
      enemySlowed: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.CR] += e >= 1 && request.enemyHpPercent >= 0.50 ? 0.12 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.ULT_SCALING += r.enemySlowed ? ultExtraScaling : 0;

      // Boost
      x.BASIC_BOOST += r.enemySlowed ? 0.40 : 0;
      x.RES_PEN += r.talentPenBuff ? extraPenValue : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function clara(e) {
  let ultDmgReductionValue = ult(e, 0.25, 0.27);
  let ultFuaExtraScaling = ult(e, 1.60, 1.728);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.20, 1.32);
  let fuaScaling = talent(e, 1.60, 1.76);
  let hitMultiByTargetsBlast = {
    1: ASHBLAZING_ATK_STACK * (1 * 1 / 1),
    3: ASHBLAZING_ATK_STACK * (2 * 1 / 1),
    5: ASHBLAZING_ATK_STACK * (2 * 1 / 1) // Clara is 1 hit blast when enhanced
  };
  let hitMultiSingle = ASHBLAZING_ATK_STACK * (1 * 1 / 1);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultBuff",
        text: "Ult buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2131,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "talentEnemyMarked",
        text: "Enemy marked"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2132,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2UltAtkBuff",
        text: "E2 ult ATK buff",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2133,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e4DmgReductionBuff",
        text: "E4 dmg reduction buff",
        disabled: e < 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2134,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2130,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultBuff: true,
      talentEnemyMarked: true,
      e2UltAtkBuff: true,
      e4DmgReductionBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.ATK_P] += e >= 2 && r.e2UltAtkBuff ? 0.30 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      // x.SKILL_SCALING += r.talentEnemyMarked ?
      x.FUA_SCALING += fuaScaling;
      x.FUA_SCALING += r.ultBuff ? ultFuaExtraScaling : 0;

      // Boost
      x.DMG_RED_MULTI *= 1 - 0.10;
      x.DMG_RED_MULTI *= r.ultBuff ? 1 - ultDmgReductionValue : 1;
      x.DMG_RED_MULTI *= e >= 4 && r.e4DmgReductionBuff ? 1 - 0.30 : 1;
      x.FUA_BOOST += 0.30;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];

      // Calc ashblazing: ult buff -> blast, unbuffed -> single
      if (r.ultBuff) {
        let {
          ashblazingMulti,
          ashblazingAtk
        } = calculateAshblazingSet(c, request, hitMultiByTargetsBlast[request.enemyCount]);
        x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
      } else {
        let {
          ashblazingMulti,
          ashblazingAtk
        } = calculateAshblazingSet(c, request, hitMultiSingle);
        x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
      }
    }
  };
}
function bronya(e) {
  let skillDmgBoostValue = skill(e, 0.66, 0.726);
  let ultAtkBoostValue = ult(e, 0.55, 0.594);
  let ultCdBoostValue = ult(e, 0.16, 0.168);
  let ultCdBoostBaseValue = ult(e, 0.20, 0.216);
  let basicScaling = basic(e, 1.0, 1.1);
  let fuaScaling = basicScaling * 0.80;
  let hitMulti = ASHBLAZING_ATK_STACK * (1 * 1 / 1);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "techniqueBuff",
        text: "Technique buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2198,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "battleStartDefBuff",
        text: "Battle start DEF buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2199,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillBuff",
        text: "Skill buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2200,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultBuff",
        text: "Ult buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2201,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2SkillSpdBuff",
        text: "E2 skill SPD buff",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2202,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2197,
      columnNumber: 7
    }, this),
    defaults: () => ({
      techniqueBuff: true,
      battleStartDefBuff: true,
      skillBuff: true,
      ultBuff: true,
      e2SkillSpdBuff: false
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.DEF_P] += r.battleStartDefBuff ? 0.20 : 0;
      x[Stats.SPD_P] += r.e2SkillSpdBuff ? 0.30 : 0;
      x[Stats.ATK_P] += r.techniqueBuff ? 0.15 : 0;
      x[Stats.ATK_P] += r.ultBuff ? ultAtkBoostValue : 0;
      x.BASIC_CR_BOOST += 1.00;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.FUA_SCALING += e >= 4 ? fuaScaling : 0;

      // Boost
      x.ELEMENTAL_DMG += 0.10;
      x.ELEMENTAL_DMG += r.skillBuff ? skillDmgBoostValue : 0;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;

      // Order matters?
      x[Stats.CD] += r.ultBuff ? ultCdBoostValue * x[Stats.CD] : 0;
      x[Stats.CD] += r.ultBuff ? ultCdBoostBaseValue : 0;
      let {
        ashblazingMulti,
        ashblazingAtk
      } = calculateAshblazingSet(c, request, hitMulti);
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.FUA_DMG += x.FUA_SCALING * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
    }
  };
}
function blade(e) {
  let enhancedStateDmgBoost = skill(e, 0.40, 0.456);
  let hpPercentLostTotalMax = 0.90;
  let basicScaling = basic(e, 1.0, 1.1);
  let basicEnhancedAtkScaling = skill(e, 0.40, 0.44);
  let basicEnhancedHpScaling = skill(e, 1.00, 1.10);
  let ultAtkScaling = ult(e, 0.40, 0.432);
  let ultHpScaling = ult(e, 1.00, 1.08);
  let ultLostHpScaling = ult(e, 1.00, 1.08);
  let fuaAtkScaling = talent(e, 0.44, 0.484);
  let fuaHpScaling = talent(e, 1.10, 1.21);
  let hitMultiByTargets = {
    1: ASHBLAZING_ATK_STACK * (1 * 0.33 + 2 * 0.33 + 3 * 0.34),
    3: ASHBLAZING_ATK_STACK * (2 * 0.33 + 5 * 0.33 + 8 * 0.34),
    5: ASHBLAZING_ATK_STACK * (3 * 0.33 + 8 * 0.33 + 8 * 0.34)
  };
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enhancedStateActive",
        text: "Enhanced state"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2271,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "hpPercentLostTotal",
        text: "HP% lost total",
        min: 0,
        max: hpPercentLostTotalMax,
        percent: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2272,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e4MaxHpIncreaseStacks",
        text: "E4 max HP stacks",
        min: 0,
        max: 2,
        disabled: e < 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2273,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2270,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enhancedStateActive: true,
      hpPercentLostTotal: hpPercentLostTotalMax,
      e4MaxHpIncreaseStacks: 2
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.CR] += e >= 2 && r.enhancedStateActive ? 0.15 : 0;
      x[Stats.HP_P] += e >= 4 ? r.e4MaxHpIncreaseStacks * 0.20 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      // Rest of the scalings are calculated dynamically

      // Boost
      x.ELEMENTAL_DMG += r.enhancedStateActive ? enhancedStateDmgBoost : 0;
      x.FUA_BOOST += 0.20;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      if (r.enhancedStateActive) {
        x.BASIC_DMG += basicEnhancedAtkScaling * x[Stats.ATK];
        x.BASIC_DMG += basicEnhancedHpScaling * x[Stats.HP];
      } else {
        x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      }
      x.ULT_DMG += ultAtkScaling * x[Stats.ATK];
      x.ULT_DMG += ultHpScaling * x[Stats.HP];
      x.ULT_DMG += ultLostHpScaling * r.hpPercentLostTotal * x[Stats.HP];
      x.ULT_DMG += e >= 1 && request.enemyCount == 1 ? 1.50 * r.hpPercentLostTotal * x[Stats.HP] : 0;
      let hitMulti = hitMultiByTargets[request.enemyCount];
      let {
        ashblazingMulti,
        ashblazingAtk
      } = calculateAshblazingSet(c, request, hitMulti);
      x.FUA_DMG += fuaAtkScaling * (x[Stats.ATK] - ashblazingAtk + ashblazingMulti);
      x.FUA_DMG += fuaHpScaling * x[Stats.HP];
      x.FUA_DMG += e >= 6 ? 0.50 * x[Stats.HP] : 0;
    }
  };
}
function bailu(e) {
  let basicScaling = basic(e, 1.0, 1.1);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 0, 0);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "healingMaxHpBuff",
        text: "Healing max HP buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2333,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "talentDmgReductionBuff",
        text: "Talent dmg reduced"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2334,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2UltHealingBuff",
        text: "E2 ult heal buff",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2335,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "e4SkillHealingDmgBuffStacks",
        text: "E4 dmg buff stacks",
        min: 0,
        max: 3,
        disabled: e < 4
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2336,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2332,
      columnNumber: 7
    }, this),
    defaults: () => ({
      healingMaxHpBuff: true,
      talentDmgReductionBuff: true,
      e2UltHealingBuff: true,
      e4SkillHealingDmgBuffStacks: 0
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.HP_P] += r.healingMaxHpBuff ? 0.10 : 0;
      x[Stats.OHB] += e >= 2 && r.e2UltHealingBuff ? 0.15 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.DMG_RED_MULTI *= r.talentDmgReductionBuff ? 1 - 0.10 : 1;
      x.ALL_DMG_MULTI += e >= 4 ? r.e4SkillHealingDmgBuffStacks * 0.10 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += 0;
      x.ULT_DMG += 0;
      x.FUA_DMG += 0;
    }
  };
}
function asta(e) {
  let ultSpdBuffValue = ult(e, 50, 52.8);
  let talentStacksAtkBuff = talent(e, 0.14, 0.154);
  let talentStacksDefBuff = 0.06;
  let skillExtraDmgHitsMax = e >= 1 ? 5 : 4;
  let basicScaling = basic(e, 1.0, 1.1);
  let skillScaling = skill(e, 0.50, 0.55);
  let ultScaling = ult(e, 0, 0);
  let dotScaling = basic(e, 0.50, 0.55);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "skillExtraDmgHits",
        text: "Skill extra hits",
        min: 0,
        max: skillExtraDmgHitsMax
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2389,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentBuffStacks",
        text: "Talent ATK buff stacks",
        min: 0,
        max: 5
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2390,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultSpdBuff",
        text: "Ult SPD buff active"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2391,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2388,
      columnNumber: 7
    }, this),
    defaults: () => ({
      talentBuffStacks: 5,
      skillExtraDmgHits: skillExtraDmgHitsMax,
      ultSpdBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x[Stats.ATK_P] += r.talentBuffStacks * talentStacksAtkBuff;
      x[Stats.DEF_P] += r.talentBuffStacks * talentStacksDefBuff;
      x[Stats.ERR] += e >= 4 && r.talentBuffStacks >= 2 ? 0.15 : 0;
      x[Stats.SPD] += r.ultSpdBuff ? ultSpdBuffValue : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.DOT_SCALING += dotScaling;

      // Boost
      x.ELEMENTAL_DMG += 0.18;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += 0;
      x.DOT_DMG += x.DOT_SCALING * x[Stats.ATK];
    }
  };
}
function arlan(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.40, 2.64);
  let ultScaling = ult(e, 3.20, 3.456);
  let talentMissingHpDmgBoostMax = talent(e, 0.72, 0.792);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "selfCurrentHpPercent",
        text: "Self current HP%",
        min: 0.01,
        max: 1.0,
        percent: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2441,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 2440,
      columnNumber: 7
    }, this),
    defaults: () => ({
      selfCurrentHpPercent: 1.00
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Stats
      x.ELEMENTAL_DMG += Math.min(talentMissingHpDmgBoostMax, 1 - r.selfCurrentHpPercent);

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;

      // Boost
      x.SKILL_BOOST += e >= 1 && r.selfCurrentHpPercent <= 0.50 ? 0.10 : 0;
      x.ULT_BOOST += e >= 6 && r.selfCurrentHpPercent <= 0.50 ? 0.20 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.FUA_DMG += 0;
    }
  };
}
function argenti(e) {
  let talentMaxStacks = e >= 4 ? 12 : 10;
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 1.20, 1.32);
  let ultScaling = ult(e, 1.60, 1.728);
  let ultEnhancedScaling = ult(e, 2.80, 3.024);
  let ultEnhancedExtraHitScaling = ult(e, 0.95, 1.026);
  let talentCrStackValue = talent(e, 0.025, 0.028);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultEnhanced",
        text: "Enhanced ult"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2489,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentStacks",
        text: "Talent stacks",
        min: 0,
        max: talentMaxStacks
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2490,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "ultEnhancedExtraHits",
        text: "Ult extra hits",
        min: 0,
        max: 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2491,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2UltAtkBuff",
        text: "E2 ult ATK buff",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2492,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2488,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultEnhanced: true,
      talentStacks: talentMaxStacks,
      ultEnhancedExtraHits: 6,
      e2UltAtkBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Skills
      x[Stats.CR] += r.talentStacks * talentCrStackValue;

      // Traces

      // Eidolons
      x[Stats.CD] += e >= 1 ? r.talentStacks * 0.04 : 0;
      x[Stats.ATK_P] += e >= 2 && r.e2UltAtkBuff ? 0.40 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += r.ultEnhanced ? ultEnhancedScaling : ultScaling;
      x.ULT_SCALING += r.ultEnhancedExtraHits * ultEnhancedExtraHitScaling;

      // BOOST
      x.ULT_BOOST += request.enemyHpPercent <= 0.5 ? 0.15 : 0;
      x.ULT_DEF_PEN += e >= 6 ? 0.30 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.FUA_DMG += 0;
    }
  };
}
function jingliu(e) {
  let talentCrBuff = talent(e, 0.50, 0.52);
  let talentHpDrainAtkBuffMax = talent(e, 1.80, 1.98);
  talentHpDrainAtkBuffMax += e >= 4 ? 0.30 : 0;
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.00, 2.20);
  let skillEnhancedScaling = skill(e, 2.50, 2.75);
  let ultScaling = ult(e, 3.00, 3.24);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "talentEnhancedState",
        text: "Enhanced state"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2550,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentHpDrainAtkBuff",
        text: "HP drain ATK buff",
        min: 0,
        max: talentHpDrainAtkBuffMax,
        percent: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2551,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e1CdBuff",
        text: "E1 ult active",
        disabled: e < 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2552,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2SkillDmgBuff",
        text: "E2 skill buff",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2553,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2549,
      columnNumber: 7
    }, this),
    defaults: () => ({
      talentEnhancedState: true,
      talentHpDrainAtkBuff: talentHpDrainAtkBuffMax,
      e1CdBuff: true,
      e2SkillDmgBuff: true
    }),
    precomputeEffects: request => {
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);

      // Skills
      x[Stats.CR] += r.talentEnhancedState ? talentCrBuff : 0;
      x[Stats.ATK_P] += r.talentEnhancedState ? r.talentHpDrainAtkBuff : 0;

      // Traces
      x[Stats.RES] += r.talentEnhancedState ? 0.35 : 0;
      x.ULT_BOOST += r.talentEnhancedState ? 0.20 : 0;

      // Eidolons
      x[Stats.CD] += e >= 1 && r.e1CdBuff ? 0.24 : 0;
      x[Stats.CD] += e >= 6 && r.talentEnhancedState ? 0.50 : 0;

      // Scaling
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += r.talentEnhancedState ? skillEnhancedScaling : skillScaling;
      x.SKILL_SCALING += e >= 1 && r.talentEnhancedState && request.enemyCount == 1 ? 1 : 0;
      x.ULT_SCALING += ultScaling;
      x.ULT_SCALING += e >= 1 && request.enemyCount == 1 ? 1 : 0;
      x.FUA_SCALING += 0;

      // BOOST
      x.SKILL_BOOST += e >= 2 && r.talentEnhancedState && r.e2SkillDmgBuff ? 0.80 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.FUA_DMG += 0;
    }
  };
}
function blackswan(e) {
  let arcanaStackMultiplier = talent(e, 0.12, 0.132);
  let stack3ArcanaBlastDmg = talent(e, 1.80, 1.98);
  let epiphanyDmgTakenBoost = ult(e, 0.25, 0.27);
  let defShredValue = skill(e, 0.208, 0.22);
  let basicScaling = basic(e, 0.60, 0.66);
  let skillScaling = skill(e, 0.90, 0.99);
  let ultScaling = ult(e, 1.20, 1.30);
  let dotScaling = talent(e, 2.40, 2.64);
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "epiphanyDebuff",
        text: "Epiphany debuff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2620,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "defDecreaseDebuff",
        text: "Def decrease debuff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2621,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "arcanaStacks",
        text: "Arcana stacks",
        min: 0,
        max: 50
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2622,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e1ResReduction",
        text: "E1 RES reduction",
        disabled: e < 1
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2623,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2619,
      columnNumber: 7
    }, this),
    defaults: () => ({
      epiphanyDebuff: true,
      defDecreaseDebuff: true,
      arcanaStacks: 7,
      e1ResReduction: true
    }),
    precomputeEffects: request => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      x.DOT_SCALING += dotScaling + arcanaStackMultiplier * r.arcanaStacks;
      x.DOT_SCALING += r.arcanaStacks >= 3 ? stack3ArcanaBlastDmg : 0;
      x.DOT_DEF_PEN += r.arcanaStacks >= 7 ? 0.20 : 0;
      x.DEF_SHRED += r.defDecreaseDebuff ? defShredValue : 0;
      x.DOT_VULNERABILITY += r.epiphanyDebuff ? epiphanyDmgTakenBoost : 0;
      x.RES_PEN += e >= 1 && r.e1ResReduction ? 0.25 : 0;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.ELEMENTAL_DMG += Math.min(0.72, 0.60 * x[Stats.EHR]);
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
      x.DOT_DMG += x.DOT_SCALING * x[Stats.ATK];
    }
  };
}
function sparkle(e) {
  let skillCdBuffScaling = skill(e, 0.24, 0.264);
  let skillCdBuffBase = skill(e, 0.45, 0.486);
  let cipherTalentStackBoost = ult(e, 0.10, 0.108);
  let talentBaseStackBoost = ult(e, 0.06, 0.066);
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 0, 0);
  let ultScaling = ult(e, 0, 0);
  let atkBoostByQuantumAllies = {
    0: 0,
    1: 0.05,
    2: 0.15,
    3: 0.30
  };
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillCdBuff",
        text: "Skill CD buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2684,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "cipherBuff",
        text: "Cipher buff"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2685,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "talentStacks",
        text: "Talent DMG stacks",
        min: 0,
        max: 3
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2686,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "quantumAllies",
        text: "Quantum allies",
        min: 0,
        max: 3
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2687,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2683,
      columnNumber: 7
    }, this),
    defaults: () => ({
      skillCdBuff: true,
      cipherBuff: true,
      talentStacks: 3,
      quantumAllies: 3
    }),
    precomputeEffects: request => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);
      x[Stats.ATK_P] += 0.15 + (atkBoostByQuantumAllies[r.quantumAllies] || 0);
      x[Stats.ATK_P] += e >= 1 && r.cipherBuff ? 0.40 : 0;
      x.ELEMENTAL_DMG += r.cipherBuff ? r.talentStacks * (talentBaseStackBoost + cipherTalentStackBoost) : r.talentStacks * talentBaseStackBoost;
      x.DEF_SHRED += e >= 2 ? 0.08 * r.talentStacks : 0;
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultScaling;
      return x;
    },
    calculateBaseMultis: (c, request) => {
      let r = request.characterConditionals;
      let x = c.x;
      x[Stats.CD] += r.skillCdBuff ? skillCdBuffBase + skillCdBuffScaling * x[Stats.CD] : 0;
      x[Stats.CD] += e >= 6 && r.skillCdBuff ? 0.30 * x[Stats.CD] : 0;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function misha(e) {
  let basicScaling = basic(e, 1.00, 1.10);
  let skillScaling = skill(e, 2.00, 2.20);
  let ultStackScaling = ult(e, 0.60, 0.65);
  ultStackScaling += e >= 4 ? 0.06 : 0;
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 10,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "ultHitsOnTarget",
        text: "Ult hits on target",
        min: 1,
        max: 10
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2736,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyFrozen",
        text: "Enemy frozen"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2737,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e2DefReduction",
        text: "E2 def reduction",
        disabled: e < 2
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2738,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "e6UltDmgBoost",
        text: "E6 ult dmg boost",
        disabled: e < 6
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 2739,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2735,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultHitsOnTarget: 10,
      enemyFrozen: true,
      e2DefReduction: true,
      e6UltDmgBoost: true
    }),
    precomputeEffects: request => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      let r = request.characterConditionals;
      let x = Object.assign({}, baseComputedStatsObject);
      x[Stats.CD] += r.enemyFrozen ? 0.30 : 0;
      x.DEF_SHRED += e >= 2 && r.e2DefReduction ? 0.16 : 0;
      x.ELEMENTAL_DMG += e >= 6 && r.e6UltDmgBoost ? 0.30 : 0;
      x.BASIC_SCALING += basicScaling;
      x.SKILL_SCALING += skillScaling;
      x.ULT_SCALING += ultStackScaling * r.ultHitsOnTarget;
      return x;
    },
    calculateBaseMultis: c => {
      let x = c.x;
      x.BASIC_DMG += x.BASIC_SCALING * x[Stats.ATK];
      x.SKILL_DMG += x.SKILL_SCALING * x[Stats.ATK];
      x.ULT_DMG += x.ULT_SCALING * x[Stats.ATK];
    }
  };
}
function skill(e, value1, value2) {
  return e >= 3 ? value2 : value1;
}
let talent = skill;
function ult(e, value1, value2) {
  return e >= 5 ? value2 : value1;
}
let basic = ult;
function p4(set) {
  return set >> 2;
}
const CharacterConditionals = {
  get: request => {
    let characterFn = characterOptionMapping[request.characterId];
    return characterFn(request.characterEidolon);
  },
  getDisplayForCharacter: (id, eidolon) => {
    // console.log('getDisplayForCharacter', id)
    if (!id || !characterOptionMapping[id]) {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
        justify: "space-between",
        align: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_HeaderText__WEBPACK_IMPORTED_MODULE_1__.HeaderText, {
          children: "Character passives"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 2799,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_TooltipImage__WEBPACK_IMPORTED_MODULE_4__.TooltipImage, {
          type: _hint__WEBPACK_IMPORTED_MODULE_5__.Hint.characterPassives()
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 2800,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 2798,
        columnNumber: 9
      }, undefined);
    }
    let characterFn = characterOptionMapping[id];
    let display = characterFn(eidolon).display();
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_8__["default"], {
      theme: {
        token: {
          opacityLoading: 0.15
        }
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
        vertical: true,
        gap: 5,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
          justify: "space-between",
          align: "center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_HeaderText__WEBPACK_IMPORTED_MODULE_1__.HeaderText, {
            children: "Character passives"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 2818,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_TooltipImage__WEBPACK_IMPORTED_MODULE_4__.TooltipImage, {
            type: _hint__WEBPACK_IMPORTED_MODULE_5__.Hint.characterPassives()
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 2819,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 2817,
          columnNumber: 11
        }, undefined), display]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 2816,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 2809,
      columnNumber: 7
    }, undefined);
  }
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/lib/constants.ts":
/*!******************************!*\
  !*** ./src/lib/constants.ts ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Constants: () => (/* binding */ Constants),
/* harmony export */   MainStats: () => (/* binding */ MainStats),
/* harmony export */   MainStatsValues: () => (/* binding */ MainStatsValues),
/* harmony export */   Parts: () => (/* binding */ Parts),
/* harmony export */   PartsMainStats: () => (/* binding */ PartsMainStats),
/* harmony export */   PartsToReadable: () => (/* binding */ PartsToReadable),
/* harmony export */   Sets: () => (/* binding */ Sets),
/* harmony export */   SetsOrnaments: () => (/* binding */ SetsOrnaments),
/* harmony export */   SetsOrnamentsNames: () => (/* binding */ SetsOrnamentsNames),
/* harmony export */   SetsRelics: () => (/* binding */ SetsRelics),
/* harmony export */   SetsRelicsNames: () => (/* binding */ SetsRelicsNames),
/* harmony export */   Stats: () => (/* binding */ Stats),
/* harmony export */   StatsToIndex: () => (/* binding */ StatsToIndex),
/* harmony export */   StatsToReadable: () => (/* binding */ StatsToReadable),
/* harmony export */   SubStats: () => (/* binding */ SubStats),
/* harmony export */   eidolonOptions: () => (/* binding */ eidolonOptions),
/* harmony export */   enemyCountOptions: () => (/* binding */ enemyCountOptions),
/* harmony export */   enemyHpPercentOptions: () => (/* binding */ enemyHpPercentOptions),
/* harmony export */   enemyLevelOptions: () => (/* binding */ enemyLevelOptions),
/* harmony export */   enemyResistanceOptions: () => (/* binding */ enemyResistanceOptions),
/* harmony export */   levelOptions: () => (/* binding */ levelOptions),
/* harmony export */   superimpositionOptions: () => (/* binding */ superimpositionOptions)
/* harmony export */ });
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

const Stats = {
  ATK_P: 'ATK%',
  ATK: 'ATK',
  BE: 'Break Effect',
  CD: 'CRIT DMG',
  CR: 'CRIT Rate',
  DEF_P: 'DEF%',
  DEF: 'DEF',
  EHR: 'Effect Hit Rate',
  ERR: 'Energy Regeneration Rate',
  Fire_DMG: 'Fire DMG Boost',
  HP_P: 'HP%',
  HP: 'HP',
  Ice_DMG: 'Ice DMG Boost',
  Imaginary_DMG: 'Imaginary DMG Boost',
  Lightning_DMG: 'Lightning DMG Boost',
  OHB: 'Outgoing Healing Boost',
  Physical_DMG: 'Physical DMG Boost',
  Quantum_DMG: 'Quantum DMG Boost',
  RES: 'Effect RES',
  SPD_P: 'SPD%',
  SPD: 'SPD',
  Wind_DMG: 'Wind DMG Boost'
};
const MainStats = [Stats.HP_P, Stats.ATK_P, Stats.DEF_P, Stats.HP, Stats.ATK, Stats.SPD, Stats.CR, Stats.CD, Stats.EHR, Stats.BE, Stats.ERR, Stats.OHB, Stats.Physical_DMG, Stats.Fire_DMG, Stats.Ice_DMG, Stats.Lightning_DMG, Stats.Wind_DMG, Stats.Quantum_DMG, Stats.Imaginary_DMG];
const MainStatsValues = {
  [Stats.HP_P]: {
    '5': {
      'base': 6.912,
      'increment': 2.4192
    },
    '4': {
      'base': 5.5296,
      'increment': 1.9354
    },
    '3': {
      'base': 4.1472,
      'increment': 1.4515
    },
    '2': {
      'base': 2.7648,
      'increment': 0.9677
    }
  },
  [Stats.ATK_P]: {
    '5': {
      'base': 6.912,
      'increment': 2.4192
    },
    '4': {
      'base': 5.5296,
      'increment': 1.9354
    },
    '3': {
      'base': 4.1472,
      'increment': 1.4515
    },
    '2': {
      'base': 2.7648,
      'increment': 0.9677
    }
  },
  [Stats.DEF_P]: {
    '5': {
      'base': 8.64,
      'increment': 3.024
    },
    '4': {
      'base': 6.912,
      'increment': 2.4192
    },
    '3': {
      'base': 5.184,
      'increment': 1.8144
    },
    '2': {
      'base': 3.456,
      'increment': 1.2096
    }
  },
  [Stats.HP]: {
    '5': {
      'base': 112.896,
      'increment': 39.5136
    },
    '4': {
      'base': 90.3168,
      'increment': 31.61088
    },
    '3': {
      'base': 67.7376,
      'increment': 23.70816
    },
    '2': {
      'base': 45.1584,
      'increment': 15.80544
    }
  },
  [Stats.ATK]: {
    '5': {
      'base': 56.448,
      'increment': 19.7568
    },
    '4': {
      'base': 45.1584,
      'increment': 15.80544
    },
    '3': {
      'base': 33.8688,
      'increment': 11.85408
    },
    '2': {
      'base': 22.5792,
      'increment': 7.90272
    }
  },
  [Stats.SPD]: {
    '5': {
      'base': 4.032,
      'increment': 1.4
    },
    '4': {
      'base': 3.226,
      'increment': 1.1
    },
    '3': {
      'base': 2.419,
      'increment': 1.0
    },
    '2': {
      'base': 1.613,
      'increment': 1.0
    }
  },
  [Stats.CR]: {
    '5': {
      'base': 5.184,
      'increment': 1.8144
    },
    '4': {
      'base': 4.1472,
      'increment': 1.4515
    },
    '3': {
      'base': 3.1104,
      'increment': 1.0886
    },
    '2': {
      'base': 2.0736,
      'increment': 0.7258
    }
  },
  [Stats.CD]: {
    '5': {
      'base': 10.368,
      'increment': 3.6288
    },
    '4': {
      'base': 8.2944,
      'increment': 2.9030
    },
    '3': {
      'base': 6.2208,
      'increment': 2.1773
    },
    '2': {
      'base': 4.1472,
      'increment': 1.4515
    }
  },
  [Stats.EHR]: {
    '5': {
      'base': 6.912,
      'increment': 2.4192
    },
    '4': {
      'base': 5.5296,
      'increment': 1.9354
    },
    '3': {
      'base': 4.1472,
      'increment': 1.4515
    },
    '2': {
      'base': 2.7648,
      'increment': 0.9677
    }
  },
  [Stats.BE]: {
    '5': {
      'base': 10.3680,
      'increment': 3.6288
    },
    '4': {
      'base': 8.2944,
      'increment': 2.9030
    },
    '3': {
      'base': 6.2208,
      'increment': 2.1773
    },
    '2': {
      'base': 4.1472,
      'increment': 1.4515
    }
  },
  [Stats.ERR]: {
    '5': {
      'base': 3.1104,
      'increment': 1.0886
    },
    '4': {
      'base': 2.4883,
      'increment': 0.8709
    },
    '3': {
      'base': 1.8662,
      'increment': 0.6532
    },
    '2': {
      'base': 1.2442,
      'increment': 0.4355
    }
  },
  [Stats.OHB]: {
    '5': {
      'base': 5.5296,
      'increment': 1.9354
    },
    '4': {
      'base': 4.4237,
      'increment': 1.5483
    },
    '3': {
      'base': 3.3178,
      'increment': 1.1612
    },
    '2': {
      'base': 2.2118,
      'increment': 0.7741
    }
  },
  [Stats.Physical_DMG]: {
    '5': {
      'base': 6.2208,
      'increment': 2.1773
    },
    '4': {
      'base': 4.9766,
      'increment': 1.7418
    },
    '3': {
      'base': 3.7325,
      'increment': 1.3064
    },
    '2': {
      'base': 2.4883,
      'increment': 0.8709
    }
  },
  [Stats.Fire_DMG]: {
    '5': {
      'base': 6.2208,
      'increment': 2.1773
    },
    '4': {
      'base': 4.9766,
      'increment': 1.7418
    },
    '3': {
      'base': 3.7325,
      'increment': 1.3064
    },
    '2': {
      'base': 2.4883,
      'increment': 0.8709
    }
  },
  [Stats.Ice_DMG]: {
    '5': {
      'base': 6.2208,
      'increment': 2.1773
    },
    '4': {
      'base': 4.9766,
      'increment': 1.7418
    },
    '3': {
      'base': 3.7325,
      'increment': 1.3064
    },
    '2': {
      'base': 2.4883,
      'increment': 0.8709
    }
  },
  [Stats.Lightning_DMG]: {
    '5': {
      'base': 6.2208,
      'increment': 2.1773
    },
    '4': {
      'base': 4.9766,
      'increment': 1.7418
    },
    '3': {
      'base': 3.7325,
      'increment': 1.3064
    },
    '2': {
      'base': 2.4883,
      'increment': 0.8709
    }
  },
  [Stats.Wind_DMG]: {
    '5': {
      'base': 6.2208,
      'increment': 2.1773
    },
    '4': {
      'base': 4.9766,
      'increment': 1.7418
    },
    '3': {
      'base': 3.7325,
      'increment': 1.3064
    },
    '2': {
      'base': 2.4883,
      'increment': 0.8709
    }
  },
  [Stats.Quantum_DMG]: {
    '5': {
      'base': 6.2208,
      'increment': 2.1773
    },
    '4': {
      'base': 4.9766,
      'increment': 1.7418
    },
    '3': {
      'base': 3.7325,
      'increment': 1.3064
    },
    '2': {
      'base': 2.4883,
      'increment': 0.8709
    }
  },
  [Stats.Imaginary_DMG]: {
    '5': {
      'base': 6.2208,
      'increment': 2.1773
    },
    '4': {
      'base': 4.9766,
      'increment': 1.7418
    },
    '3': {
      'base': 3.7325,
      'increment': 1.3064
    },
    '2': {
      'base': 2.4883,
      'increment': 0.8709
    }
  }
};
const SubStats = [Stats.ATK_P, Stats.ATK, Stats.BE, Stats.CD, Stats.CR, Stats.DEF_P, Stats.DEF, Stats.EHR, Stats.HP_P, Stats.HP, Stats.RES, Stats.SPD];
const StatsToReadable = {
  [Stats.HP_P]: 'HP %',
  [Stats.ATK_P]: 'ATK %',
  [Stats.DEF_P]: 'DEF %',
  [Stats.SPD_P]: 'SPD %',
  [Stats.HP]: 'HP',
  [Stats.ATK]: 'ATK',
  [Stats.DEF]: 'DEF',
  [Stats.SPD]: 'SPD',
  [Stats.CR]: 'CRIT Rate',
  [Stats.CD]: 'CRIT DMG',
  [Stats.EHR]: 'Effect Hit Rate',
  [Stats.RES]: 'Effect RES',
  [Stats.BE]: 'Break Effect',
  [Stats.ERR]: 'Energy Regen',
  [Stats.OHB]: 'Healing Boost',
  [Stats.Physical_DMG]: 'Physical DMG',
  [Stats.Fire_DMG]: 'Fire DMG',
  [Stats.Ice_DMG]: 'Ice DMG',
  [Stats.Lightning_DMG]: 'Lightning DMG',
  [Stats.Wind_DMG]: 'Wind DMG',
  [Stats.Quantum_DMG]: 'Quantum DMG',
  [Stats.Imaginary_DMG]: 'Imaginary DMG'
};
const StatsToIndex = {};
let i = 0;
Object.values(Stats).map(x => StatsToIndex[x] = i++);
const Parts = {
  Head: 'Head',
  Hands: 'Hands',
  Body: 'Body',
  Feet: 'Feet',
  PlanarSphere: 'PlanarSphere',
  LinkRope: 'LinkRope'
};
const PartsToReadable = {
  [Parts.Head]: 'Head',
  [Parts.Hands]: 'Hands',
  [Parts.Body]: 'Body',
  [Parts.Feet]: 'Feet',
  [Parts.PlanarSphere]: 'Sphere',
  [Parts.LinkRope]: 'Rope'
};
const PartsMainStats = {
  [Parts.Head]: [Stats.HP],
  [Parts.Hands]: [Stats.ATK],
  [Parts.Body]: [Stats.HP_P, Stats.ATK_P, Stats.DEF_P, Stats.CR, Stats.CD, Stats.OHB, Stats.EHR],
  [Parts.Feet]: [Stats.HP_P, Stats.ATK_P, Stats.DEF_P, Stats.SPD],
  [Parts.PlanarSphere]: [Stats.HP_P, Stats.ATK_P, Stats.DEF_P, Stats.Physical_DMG, Stats.Fire_DMG, Stats.Ice_DMG, Stats.Lightning_DMG, Stats.Wind_DMG, Stats.Quantum_DMG, Stats.Imaginary_DMG],
  [Parts.LinkRope]: [Stats.HP_P, Stats.ATK_P, Stats.DEF_P, Stats.BE, Stats.ERR]
};
const SetsRelics = {
  'PasserbyOfWanderingCloud': 'Passerby of Wandering Cloud',
  'MusketeerOfWildWheat': 'Musketeer of Wild Wheat',
  'KnightOfPurityPalace': 'Knight of Purity Palace',
  'HunterOfGlacialForest': 'Hunter of Glacial Forest',
  'ChampionOfStreetwiseBoxing': 'Champion of Streetwise Boxing',
  'GuardOfWutheringSnow': 'Guard of Wuthering Snow',
  'FiresmithOfLavaForging': 'Firesmith of Lava-Forging',
  'GeniusOfBrilliantStars': 'Genius of Brilliant Stars',
  'BandOfSizzlingThunder': 'Band of Sizzling Thunder',
  'EagleOfTwilightLine': 'Eagle of Twilight Line',
  'ThiefOfShootingMeteor': 'Thief of Shooting Meteor',
  'WastelanderOfBanditryDesert': 'Wastelander of Banditry Desert',
  'LongevousDisciple': 'Longevous Disciple',
  'MessengerTraversingHackerspace': 'Messenger Traversing Hackerspace',
  'TheAshblazingGrandDuke': 'The Ashblazing Grand Duke',
  'PrisonerInDeepConfinement': 'Prisoner in Deep Confinement'
};
const SetsOrnaments = {
  'SpaceSealingStation': 'Space Sealing Station',
  'FleetOfTheAgeless': 'Fleet of the Ageless',
  'PanCosmicCommercialEnterprise': 'Pan-Cosmic Commercial Enterprise',
  'BelobogOfTheArchitects': 'Belobog of the Architects',
  'CelestialDifferentiator': 'Celestial Differentiator',
  'InertSalsotto': 'Inert Salsotto',
  'TaliaKingdomOfBanditry': 'Talia: Kingdom of Banditry',
  'SprightlyVonwacq': 'Sprightly Vonwacq',
  'RutilantArena': 'Rutilant Arena',
  'BrokenKeel': 'Broken Keel',
  'FirmamentFrontlineGlamoth': 'Firmament Frontline: Glamoth',
  'PenaconyLandOfTheDreams': 'Penacony, Land of the Dreams'
};
const Sets = {
  ...SetsRelics,
  ...SetsOrnaments
};
const SetsRelicsNames = Object.values(SetsRelics);
_c = SetsRelicsNames;
const SetsOrnamentsNames = Object.values(SetsOrnaments);
_c2 = SetsOrnamentsNames;
const OrnamentSetToIndex = {};
for (let i = 0; i < SetsOrnamentsNames.length; i++) {
  OrnamentSetToIndex[SetsOrnamentsNames[i]] = i;
}
const RelicSetToIndex = {};
for (let i = 0; i < SetsRelicsNames.length; i++) {
  RelicSetToIndex[SetsRelicsNames[i]] = i;
}
const Constants = {
  Sets,
  Parts,
  Stats,
  MainStats,
  MainStatsValues,
  SubStats,
  StatsToIndex,
  SetsOrnaments,
  SetsRelics,
  SetsRelicsNames,
  SetsOrnamentsNames,
  StatsToReadable,
  PartsToReadable,
  PartsMainStats,
  RelicSetToIndex,
  OrnamentSetToIndex,
  // StatMaxes,
  MAX_INT: 2147483647
};
const levelOptions = (() => {
  const levelStats = [];
  for (let i = 80; i >= 1; i--) {
    levelStats.push({
      value: i,
      label: `Lv. ${i}`
    });
  }
  return levelStats;
})();
const enemyLevelOptions = (() => {
  const levelStats = [];
  for (let i = 95; i >= 1; i--) {
    levelStats.push({
      value: i,
      label: `Lv. ${i}`
    });
  }
  return levelStats;
})();
const enemyCountOptions = (() => {
  const levelStats = [];
  for (let i = 1; i <= 5; i += 2) {
    levelStats.push({
      value: i,
      label: `${i} target${i > 1 ? 's' : ''}`
    });
  }
  return levelStats;
})();
const enemyResistanceOptions = (() => {
  const levelStats = [];
  for (let i = 20; i <= 60; i += 20) {
    levelStats.push({
      value: i / 100,
      label: `${i}% RES`
    });
  }
  return levelStats;
})();
const enemyHpPercentOptions = (() => {
  const levelStats = [];
  for (let i = 100; i >= 1; i--) {
    levelStats.push({
      value: i / 100,
      label: `${i}% HP`
    });
  }
  return levelStats;
})();
const superimpositionOptions = (() => {
  return [{
    value: 1,
    label: 'S1'
  }, {
    value: 2,
    label: 'S2'
  }, {
    value: 3,
    label: 'S3'
  }, {
    value: 4,
    label: 'S4'
  }, {
    value: 5,
    label: 'S5'
  }];
})();
const eidolonOptions = (() => {
  return [{
    value: 0,
    label: 'E0'
  }, {
    value: 1,
    label: 'E1'
  }, {
    value: 2,
    label: 'E2'
  }, {
    value: 3,
    label: 'E3'
  }, {
    value: 4,
    label: 'E4'
  }, {
    value: 5,
    label: 'E5'
  }, {
    value: 6,
    label: 'E6'
  }];
})();
var _c, _c2;
__webpack_require__.$Refresh$.register(_c, "SetsRelicsNames");
__webpack_require__.$Refresh$.register(_c2, "SetsOrnamentsNames");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/lib/hint.js":
/*!*************************!*\
  !*** ./src/lib/hint.js ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Hint: () => (/* binding */ Hint)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/flex/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/curisu/dev/hsr-optimizer/src/lib/hint.js";



const Hint = {
  ratingFilters: () => {
    return {
      title: 'Rating filters',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "CV - Crit Value, measuring the value of crit stats on the build. Calculated using CD + CR * 2"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 10,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Weight - Sum of substat weights of all 6 relics, from the Substat weight filter"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 11,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Ehp - Effective HP, measuring how tanky a max level character is. Calculated using HP & DEF & damage reduction passives"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Basic / Skill / Ult / Fua (Follow-up attack) / Dot (Damage over time) - Skill damage calculations, based on the environmental factors in character passives / light cone passives / enemy options."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 9
      }, undefined)
    };
  },
  combatBuffs: () => {
    return {
      title: 'Combat buffs',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Additional team buffs to apply to the calculations. Note that buffs from character / light cone self-buffs and passives and traces are already included in calculations."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)
    };
  },
  statFilters: () => {
    return {
      title: 'Stat filters',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Min / Max filters for character stats, inclusive. The optimizer will only show results within these ranges "
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Stat abbreviations are ATK / HP / DEF / SPD / Crit Rate / Crit Damage / Effect Hit Rate / Effect RES / Break Effect"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "NOTE: Ingame speed decimals are truncated so you may see speed values ingame higher than shown here. This is because the OCR importer can't detect the hidden decimals."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, undefined)
    };
  },
  mainStats: () => {
    return {
      title: 'Main stats',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Select main stats to use for optimization search. Multiple values can be selected for more options"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 48,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 9
      }, undefined)
    };
  },
  sets: () => {
    return {
      title: 'Sets',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Select the relic and ornament sets to filter results by. Multiple sets can be selected for more options"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Set effects will be accounted for in calculations, use the Conditional set effects menu to customize which effects are active."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, undefined)
    };
  },
  character: () => {
    return {
      title: 'Character',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Select the character and level / eidolon"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Levels will affect base stats used in the calculation. Eidolon effects are applied under the Character passives panel."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 9
      }, undefined)
    };
  },
  characterPassives: () => {
    return {
      title: 'Character passives',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Select the conditional effects to apply to the character."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Effects that rely on combat stats or environment state will be applied by default, so only the options that require user input are listed here."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 85,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 9
      }, undefined)
    };
  },
  lightConePassives: () => {
    return {
      title: 'Light cone passives',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Select the conditional effects to apply to the light cone."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 96,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Effects that rely on combat stats or environment state will be applied by default, so only the options that require user input are listed here."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 95,
        columnNumber: 9
      }, undefined)
    };
  },
  lightCone: () => {
    return {
      title: 'Light cone',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Select the light cone and level / superimposition"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 108,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Levels will affect base stats used in the calculation. Superimposition and passive effects are applied under the Light cone passives panel."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 109,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 107,
        columnNumber: 9
      }, undefined)
    };
  },
  actions: () => {
    return {
      title: 'Actions',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Start - Begin optimization search with the selected filters"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 120,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Filter - Re-apply the search filters to existing results. Use this to narrow filters without restarting a search"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 121,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Cancel - Cancel an in progress search and display results"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 122,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Reset - Clear all filters"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 123,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 119,
        columnNumber: 9
      }, undefined)
    };
  },
  optimizerOptions: () => {
    return {
      title: 'Optimizer options',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("strong", {
            children: "Character rank filter"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 134,
            columnNumber: 14
          }, undefined), " - Rank characters by dragging them on the character page, and when enabled, characters may only take relics from lower ranked characters"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 134,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("strong", {
            children: "Maxed main stat"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 135,
            columnNumber: 14
          }, undefined), " - Assume the main stat for relics are maxed"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 135,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("strong", {
            children: "Keep current relics"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 136,
            columnNumber: 14
          }, undefined), " - The character must use its currently equipped items, and the optimizer will try to fill in empty slots"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 136,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("strong", {
            children: "Use equipped"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 137,
            columnNumber: 14
          }, undefined), " - If OFF, Optimizer will NOT consider relics currently equipped by a character"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 137,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("strong", {
            children: "Enhance / grade"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 138,
            columnNumber: 14
          }, undefined), " - Select the minimum enhance to search for and minimum stars for relics to include"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 138,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("strong", {
            children: "Stat display"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 139,
            columnNumber: 14
          }, undefined), " - Select which format of stats to apply to filters and display in the table. Base stats are the values you would see in the ingame character menu. Combat stats take into account all the buffs and passives applied to the character in combat as they perform an attack."]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 139,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 133,
        columnNumber: 9
      }, undefined)
    };
  },
  relics: () => {
    return {
      title: 'Relics',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Weight - The relic's current weight as defined by the scoring algorithm + 64.8 weight for an appropriate main stat"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 150,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Avg case - The relic's potential weight if rolls went into the average weight of the relic's substats"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 151,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Best case - The relic's maximum potential weight if all future rolls went into the character's desired stats"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 152,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 149,
        columnNumber: 9
      }, undefined)
    };
  },
  optimizationDetails: () => {
    return {
      title: 'Optimization details',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Shows how many relics are being used in the optimization search, after all filters are applied"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 163,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Perms - Number of permutations that need to be searched. Narrow your filters to reduce permutations & search time"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 164,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Searched - Number of permutations already searched"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 165,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Results - Number of displayed results that satisfy the stat filters"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 166,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 162,
        columnNumber: 9
      }, undefined)
    };
  },
  enemyOptions: () => {
    return {
      title: 'Enemy options',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Level - Enemy level, affects enemy DEF calculations"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 177,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Targets - Number of targets in the battle. The target enemy is always assumed to be in the center, and damage calculations are only for the main target."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 178,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "RES - Enemy elemental RES. RES is set to 0 when the enemy's elemental weakness is enabled."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 179,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "HP% - Enemy current health %, affects certain characters with damage increases or additional effects based on enemy HP."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 180,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Elemental weakness - Whether the enemy is weak to the character's type. Enabling this sets enemy elemental RES % to 0."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 181,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Weakness broken - Whether the enemy's toughness bar is broken. Affects damage calculations and certain character passives."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 182,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 176,
        columnNumber: 9
      }, undefined)
    };
  },
  substatWeightFilter: () => {
    return {
      title: 'Substat weight filter',
      content: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_2__["default"], {
        vertical: true,
        gap: 10,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "This filter is used to reduce the number of permutations the optimizer has to process."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 193,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "It works by first scoring each relic per slot by the weights defined, then sorting the relics in each slot by their score."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 194,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Then, the filter only uses the Top X% of the scored relics in the optimization search. The number of filtered relics are visible in the Permutations display on the sidebar."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 195,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
          children: "Note that setting the Top X% too low may result in some builds not being displayed, if the filter ends up excludes a key relic. Use this filter with caution, but on large searches it makes a large impact on reducing search time."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 196,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 192,
        columnNumber: 9
      }, undefined)
    };
  }
};

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/lib/lightConeConditionals.js":
/*!******************************************!*\
  !*** ./src/lib/lightConeConditionals.js ***!
  \******************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LightConeConditionals: () => (/* binding */ LightConeConditionals)
/* harmony export */ });
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/flex/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/typography/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_HeaderText__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/HeaderText */ "./src/components/HeaderText.js");
/* harmony import */ var _constants_ts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants.ts */ "./src/lib/constants.ts");
/* harmony import */ var _components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/optimizerTab/FormConditionalInputs */ "./src/components/optimizerTab/FormConditionalInputs.js");
/* harmony import */ var _components_TooltipImage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/TooltipImage */ "./src/components/TooltipImage.js");
/* harmony import */ var _hint__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./hint */ "./src/lib/hint.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/curisu/dev/hsr-optimizer/src/lib/lightConeConditionals.js";
/* eslint-disable no-unused-vars  */









let Stats = _constants_ts__WEBPACK_IMPORTED_MODULE_2__.Constants.Stats;
let defaultGap = 5;
const lightConeOptionMapping = {
  20000: Arrows,
  20001: Cornucopia,
  20002: CollapsingSky,
  20003: Amber,
  20004: Void,
  20005: Chorus,
  20006: DataBank,
  20007: DartingArrow,
  20008: FineFruit,
  20009: ShatteredHome,
  20010: Defense,
  20011: Loop,
  20012: MeshingCogs,
  20013: Passkey,
  20014: Adversarial,
  20015: Multiplication,
  20016: MutualDemise,
  20017: Pioneering,
  20018: HiddenShadow,
  20019: Mediation,
  20020: Sagacity,
  21000: PostOpConversation,
  21001: GoodNightAndSleepWell,
  21002: DayOneOfMyNewLife,
  21003: OnlySilenceRemains,
  21004: MemoriesOfThePast,
  21005: TheMolesWelcomeYou,
  21006: TheBirthOfTheSelf,
  21007: SharedFeeling,
  21008: EyesOfThePrey,
  21009: LandausChoice,
  21010: Swordplay,
  21011: PlanetaryRendezvous,
  21012: ASecretVow,
  21013: MakeTheWorldClamor,
  21014: PerfectTiming,
  // Does the ohb apply after passives?
  21015: ResolutionShinesAsPearlsOfSweat,
  21016: TrendOfTheUniversalMarket,
  // Revisit dot
  21017: SubscribeForMore,
  21018: DanceDanceDance,
  21019: UnderTheBlueSky,
  21020: GeniusesRepose,
  21021: QuidProQuo,
  21022: Fermata,
  21023: WeAreWildfire,
  21024: RiverFlowsInSpring,
  21025: PastAndFuture,
  21026: WoofWalkTime,
  21027: TheSeriousnessOfBreakfast,
  21028: WarmthShortensColdNights,
  21029: WeWillMeetAgain,
  // Does this get affected by crit / dmg boosts?
  21030: ThisIsMe,
  // Def scaling dmg not implemented
  21031: ReturnToDarkness,
  21032: CarveTheMoonWeaveTheClouds,
  21033: NowhereToRun,
  21034: TodayIsAnotherPeacefulDay,
  22000: BeforeTheTutorialMissionStarts,
  22001: HeyOverHere,
  23000: NightOnTheMilkyWay,
  23001: InTheNight,
  23002: SomethingIrreplaceable,
  23003: ButTheBattleIsntOver,
  23004: InTheNameOfTheWorld,
  // Skill atk buff not implemented
  23005: MomentOfVictory,
  23006: PatienceIsAllYouNeed,
  // Revisit dot
  23007: IncessantRain,
  23008: EchoesOfTheCoffin,
  23009: TheUnreachableSide,
  23010: BeforeDawn,
  23011: SheAlreadyShutHerEyes,
  23012: SleepLikeTheDead,
  23013: TimeWaitsForNoOne,
  23014: IShallBeMyOwnSword,
  23015: BrighterThanTheSun,
  23016: WorrisomeBlissful,
  23017: NightOfFright,
  23018: AnInstantBeforeAGaze,
  23019: PastSelfInMirror,
  23020: BaptismOfPureThought,
  24000: OnTheFallOfAnAeon,
  24001: CruisingInTheStellarSea,
  24002: TextureOfMemories,
  24003: SolitaryHealing,
  23021: EarthlyEscapade,
  23022: ReforgedRemembrance
};
function BaptismOfPureThought(s) {
  let sValuesCd = [0.08, 0.09, 0.10, 0.11, 0.12];
  let sValuesDmg = [0.36, 0.42, 0.48, 0.54, 0.60];
  let sValuesFuaPen = [0.24, 0.28, 0.32, 0.36, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "debuffCdStacks",
        text: "Debuff cd stacks",
        min: 0,
        max: 3,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "postUltBuff",
        text: "Disputation ult cd / fua def pen buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 112,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 110,
      columnNumber: 7
    }, this),
    defaults: () => ({
      debuffCdStacks: 3,
      postUltBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CD] += r.debuffCdStacks * sValuesCd[s];
      x.ELEMENTAL_DMG += r.postUltBuff ? sValuesDmg[s] : 0;
      x.FUA_DEF_PEN += r.postUltBuff ? sValuesFuaPen[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c = BaptismOfPureThought;
function PastSelfInMirror(s) {
  const sValues = [0.24, 0.28, 0.32, 0.36, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "postUltDmgBuff",
        text: "Post ult dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 137,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 136,
      columnNumber: 7
    }, this),
    defaults: () => ({
      postUltDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.postUltDmgBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c2 = PastSelfInMirror;
function SolitaryHealing(s) {
  const sValues = [0.24, 0.30, 0.36, 0.42, 0.48];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "postUltDotDmgBuff",
        text: "Post ult dot dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 159,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 158,
      columnNumber: 7
    }, this),
    defaults: () => ({
      postUltDotDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.DOT_BOOST += r.postUltDotDmgBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c3 = SolitaryHealing;
function TextureOfMemories(s) {
  const sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "activeShieldDmgDecrease",
        text: "Active shield dmg decrease",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 181,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 180,
      columnNumber: 7
    }, this),
    defaults: () => ({
      activeShieldDmgDecrease: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.DMG_RED_MULTI += r.activeShieldDmgDecrease ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c4 = TextureOfMemories;
function CruisingInTheStellarSea(s) {
  let sValuesCr = [0.08, 0.10, 0.12, 0.14, 0.16];
  let sValuesAtk = [0.20, 0.25, 0.30, 0.35, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyHp50CrBoost",
        text: "Enemy HP <= 50% cr boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 204,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyDefeatedAtkBuff",
        text: "Enemy defeated atk buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 205,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 203,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyHp50CrBoost: true,
      enemyDefeatedAtkBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CR] += r.enemyHp50CrBoost && request.enemyHpPercent <= 0.50 ? sValuesCr[s] : 0;
      x[Stats.ATK_P] += r.enemyDefeatedAtkBuff ? sValuesAtk[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c5 = CruisingInTheStellarSea;
function OnTheFallOfAnAeon(s) {
  let sValuesAtkStacks = [0.08, 0.10, 0.12, 0.14, 0.16];
  let sValuesDmgBuff = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "atkBoostStacks",
        text: "Atk boost stacks",
        min: 0,
        max: 4,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 230,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "weaknessBreakDmgBuff",
        text: "Weakness break dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 231,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 229,
      columnNumber: 7
    }, this),
    defaults: () => ({
      atkBoostStacks: 4,
      weaknessBreakDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.atkBoostStacks * sValuesAtkStacks[s];
      x.ELEMENTAL_DMG += r.weaknessBreakDmgBuff ? sValuesDmgBuff[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c6 = OnTheFallOfAnAeon;
function AnInstantBeforeAGaze(s) {
  const sValues = [0.0036, 0.0042, 0.0048, 0.0054, 0.006];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "maxEnergyUltDmgStacks",
        text: "Max energy",
        min: 0,
        max: 180,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 255,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 254,
      columnNumber: 7
    }, this),
    defaults: () => ({
      maxEnergyUltDmgStacks: 180
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ULT_BOOST += r.maxEnergyUltDmgStacks * sValues[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c7 = AnInstantBeforeAGaze;
function NightOfFright(s) {
  const sValues = [0.024, 0.028, 0.032, 0.036, 0.04];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "atkBuffStacks",
        text: "Atk buff stacks",
        min: 0,
        max: 5,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 277,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 276,
      columnNumber: 7
    }, this),
    defaults: () => ({
      atkBuffStacks: 5
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.atkBuffStacks * sValues[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c8 = NightOfFright;
function WorrisomeBlissful(s) {
  let sValuesFuaDmg = [0.30, 0.35, 0.40, 0.45, 0.50];
  let sValuesCd = [0.12, 0.14, 0.16, 0.18, 0.20];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "fuaDmgBoost",
        text: "Fua dmg boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 300,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "targetTameStacks",
        text: "Target tame stacks",
        min: 0,
        max: 2,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 301,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 299,
      columnNumber: 7
    }, this),
    defaults: () => ({
      fuaDmgBoost: true,
      targetTameStacks: 2
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CD] += r.targetTameStacks * sValuesCd[s];
      x.FUA_BOOST += r.fuaDmgBoost ? sValuesFuaDmg[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c9 = WorrisomeBlissful;
function BrighterThanTheSun(s) {
  let sValuesAtk = [0.18, 0.21, 0.24, 0.27, 0.30];
  let sValuesErr = [0.06, 0.07, 0.08, 0.09, 0.10];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "dragonsCallStacks",
        text: "Dragon's call stacks",
        min: 0,
        max: 2,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 326,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 325,
      columnNumber: 7
    }, this),
    defaults: () => ({
      dragonsCallStacks: 2
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.dragonsCallStacks * sValuesAtk[s];
      x[Stats.ERR] += r.dragonsCallStacks * sValuesErr[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c10 = BrighterThanTheSun;
function IShallBeMyOwnSword(s) {
  let sValuesStackDmg = [0.14, 0.165, 0.19, 0.215, 0.24];
  let sValuesDefPen = [0.12, 0.14, 0.16, 0.18, 0.20];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "eclipseStacks",
        text: "Eclipse stacks",
        min: 0,
        max: 3,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 350,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "maxStackDefPen",
        text: "Max stack def pen",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 351,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 349,
      columnNumber: 7
    }, this),
    defaults: () => ({
      eclipseStacks: 3,
      maxStackDefPen: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.eclipseStacks * sValuesStackDmg[s];
      x.DEF_SHRED += r.maxStackDefPen && r.eclipseStacks == 3 ? sValuesDefPen[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c11 = IShallBeMyOwnSword;
function TimeWaitsForNoOne( /* s */
) {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "healingBasedDmgProc",
        text: "Healing based dmg proc (not implemented)",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 375,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 374,
      columnNumber: 7
    }, this),
    defaults: () => ({
      healingBasedDmgProc: false
    }),
    precomputeEffects: ( /* x, request */
    ) => {
      // let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c12 = TimeWaitsForNoOne;
function SleepLikeTheDead(s) {
  const sValues = [0.36, 0.42, 0.48, 0.54, 0.60];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "missedCritCrBuff",
        text: "Missed crit cr buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 395,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 394,
      columnNumber: 7
    }, this),
    defaults: () => ({
      missedCritCrBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CR] += r.missedCritCrBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c13 = SleepLikeTheDead;
function SheAlreadyShutHerEyes(s) {
  const sValues = [0.09, 0.105, 0.12, 0.135, 0.15];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "hpLostDmgBuff",
        text: "Hp lost dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 417,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 416,
      columnNumber: 7
    }, this),
    defaults: () => ({
      hpLostDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.hpLostDmgBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c14 = SheAlreadyShutHerEyes;
function BeforeDawn(s) {
  let sValuesSkillUltDmg = [0.18, 0.21, 0.24, 0.27, 0.30];
  let sValuesFuaDmg = [0.48, 0.56, 0.64, 0.72, 0.80];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillUltDmgBoost",
        text: "Skill/ult dmg boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 440,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "fuaDmgBoost",
        text: "Fua dmg boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 441,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 439,
      columnNumber: 7
    }, this),
    defaults: () => ({
      skillUltDmgBoost: true,
      fuaDmgBoost: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.SKILL_BOOST += r.skillUltDmgBoost ? sValuesSkillUltDmg[s] : 0;
      x.ULT_BOOST += r.skillUltDmgBoost ? sValuesSkillUltDmg[s] : 0;
      x.FUA_BOOST += r.fuaDmgBoost ? sValuesFuaDmg[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c15 = BeforeDawn;
function TheUnreachableSide(s) {
  const sValues = [0.24, 0.28, 0.32, 0.36, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "dmgBuff",
        text: "Hp consumed or attacked dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 466,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 465,
      columnNumber: 7
    }, this),
    defaults: () => ({
      dmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.dmgBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c16 = TheUnreachableSide;
function EchoesOfTheCoffin(s) {
  const sValues = [12, 14, 16, 18, 20];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "postUltSpdBuff",
        text: "Post ult spd buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 488,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 487,
      columnNumber: 7
    }, this),
    defaults: () => ({
      postUltSpdBuff: false
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.SPD] += r.postUltSpdBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c17 = EchoesOfTheCoffin;
function IncessantRain(s) {
  let sValuesCr = [0.12, 0.14, 0.16, 0.18, 0.20];
  let sValuesDmg = [0.12, 0.14, 0.16, 0.18, 0.20];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemy3DebuffsCrBoost",
        text: "Enemy <= 3 debuffs cr boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 511,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetCodeDebuff",
        text: "Target code debuff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 512,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 510,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemy3DebuffsCrBoost: true,
      targetCodeDebuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CR] += r.enemy3DebuffsCrBoost ? sValuesCr[s] : 0;
      x.ELEMENTAL_DMG += r.targetCodeDebuff ? sValuesDmg[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c18 = IncessantRain;
function PatienceIsAllYouNeed(s) {
  let sValuesDmg = [0.24, 0.28, 0.32, 0.36, 0.40];
  let sValuesSpd = [0.048, 0.056, 0.064, 0.072, 0.08];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "dmgBoost",
        text: "Dmg boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 538,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "spdStacks",
        text: "Spd stacks",
        min: 0,
        max: 3,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 539,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "dotEffect",
        text: "Dot effect (not implemented)",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 540,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 537,
      columnNumber: 7
    }, this),
    defaults: () => ({
      dmgBoost: true,
      spdStacks: 0,
      dotEffect: false
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.SPD_P] += r.spdStacks * sValuesSpd[s];
      x.ELEMENTAL_DMG += r.dmgBoost ? sValuesDmg[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c19 = PatienceIsAllYouNeed;
function MomentOfVictory(s) {
  const sValues = [0.24, 0.28, 0.32, 0.36, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "selfAttackedDefBuff",
        text: "Self attacked def buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 565,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 564,
      columnNumber: 7
    }, this),
    defaults: () => ({
      selfAttackedDefBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.DEF_P] += r.selfAttackedDefBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c20 = MomentOfVictory;
function InTheNameOfTheWorld(s) {
  let sValuesDmg = [0.24, 0.28, 0.32, 0.36, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyDebuffedDmgBoost",
        text: "Enemy debuffed dmg boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 587,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "skillAtkBoost",
        text: "Skill atk boost (not implemented)",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 588,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 586,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyDebuffedDmgBoost: true,
      skillAtkBoost: false
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.enemyDebuffedDmgBoost ? sValuesDmg[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c21 = InTheNameOfTheWorld;
function ButTheBattleIsntOver(s) {
  let sValuesErr = [0.10, 0.12, 0.14, 0.16, 0.18];
  let sValuesDmg = [0.30, 0.35, 0.40, 0.45, 0.50];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "postSkillDmgBuff",
        text: "Post skill dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 612,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 611,
      columnNumber: 7
    }, this),
    defaults: () => ({
      postSkillDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ERR] += sValuesErr[s];
      x.ELEMENTAL_DMG += r.postSkillDmgBuff ? sValuesDmg[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c22 = ButTheBattleIsntOver;
function SomethingIrreplaceable(s) {
  const sValues = [0.24, 0.28, 0.32, 0.36, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "dmgBuff",
        text: "Enemy defeated or self hit dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 635,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 634,
      columnNumber: 7
    }, this),
    defaults: () => ({
      dmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.dmgBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c23 = SomethingIrreplaceable;
function InTheNight(s) {
  let sValuesDmg = [0.06, 0.07, 0.08, 0.09, 0.10];
  let sValuesCd = [0.12, 0.14, 0.16, 0.18, 0.20];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "spdScalingBuffs",
        text: "Speed scaling buffs enabled",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 658,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 657,
      columnNumber: 7
    }, this),
    defaults: () => ({
      spdScalingBuffs: true
    }),
    precomputeEffects: ( /* x, request */
    ) => {
      // let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: (c, request) => {
      let r = request.lightConeConditionals;
      let x = c.x;
      let stacks = Math.max(0, Math.min(6, Math.floor((x[Stats.SPD] - 100) / 10)));
      x.BASIC_BOOST += r.spdScalingBuffs ? stacks * sValuesDmg[s] : 0;
      x.SKILL_BOOST += r.spdScalingBuffs ? stacks * sValuesDmg[s] : 0;
      x.ULT_CD_BOOST += r.spdScalingBuffs ? stacks * sValuesCd[s] : 0;
    }
  };
}
_c24 = InTheNight;
function NightOnTheMilkyWay(s) {
  let sValuesAtk = [0.09, 0.105, 0.12, 0.135, 0.15];
  let sValuesDmg = [0.30, 0.35, 0.40, 0.45, 0.50];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyCountAtkBuff",
        text: "Enemy count atk buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 688,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyWeaknessBreakDmgBuff",
        text: "Enemy weakness break dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 689,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 687,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyCountAtkBuff: true,
      enemyWeaknessBreakDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.enemyCountAtkBuff ? request.enemyCount * sValuesAtk[s] : 0;
      x.ELEMENTAL_DMG += r.enemyWeaknessBreakDmgBuff ? sValuesDmg[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c25 = NightOnTheMilkyWay;
function HeyOverHere(s) {
  const sValues = [0.16, 0.19, 0.22, 0.25, 0.28];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "postSkillHealBuff",
        text: "Post skill heal buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 713,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 712,
      columnNumber: 7
    }, this),
    defaults: () => ({
      postSkillHealBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.OHB] += r.postSkillHealBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c26 = HeyOverHere;
function BeforeTheTutorialMissionStarts( /* s */
) {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 734,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      // let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c27 = BeforeTheTutorialMissionStarts;
function TodayIsAnotherPeacefulDay(s) {
  const sValues = [0.002, 0.0025, 0.003, 0.0035, 0.004];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "maxEnergyStacks",
        text: "Max energy",
        min: 0,
        max: 160,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 753,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 752,
      columnNumber: 7
    }, this),
    defaults: () => ({
      maxEnergyStacks: 160
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.maxEnergyStacks * sValues[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c28 = TodayIsAnotherPeacefulDay;
function NowhereToRun( /* s */
) {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 774,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      // let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c29 = NowhereToRun;
function CarveTheMoonWeaveTheClouds(s) {
  let sValuesAtk = [0.10, 0.125, 0.15, 0.175, 0.20];
  let sValuesCd = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "atkBuffActive",
        text: "Atk buff active",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 794,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "cdBuffActive",
        text: "Cd buff active",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 795,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 793,
      columnNumber: 7
    }, this),
    defaults: () => ({
      atkBuffActive: true,
      cdBuffActive: false
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.atkBuffActive ? sValuesAtk[s] : 0;
      x[Stats.CD] += r.cdBuffActive ? sValuesCd[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c30 = CarveTheMoonWeaveTheClouds;
function ReturnToDarkness( /* s */
) {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 818,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c31 = ReturnToDarkness;
function ThisIsMe( /* s */
) {
  // const sValues = [0.60, 0.75, 0.90, 1.05, 1.20]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "defScalingUltDmg",
        text: "Def scaling ult dmg (not implemented)",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 837,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 836,
      columnNumber: 7
    }, this),
    defaults: () => ({
      defScalingUltDmg: false
    }),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: (c, request) => {
      console.warn('not implemented', c, request);
      // let r = request.lightConeConditionals
      // let x = c.x

      // x.ULT_DEF_SCALING += (r.defScalingUltDmg) ? sValues[s] : 0
    }
  };
}
_c32 = ThisIsMe;
function WeWillMeetAgain(s) {
  const sValues = [0.48, 0.60, 0.72, 0.84, 0.96];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "extraDmgProc",
        text: "Additional dmg proc",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 863,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 862,
      columnNumber: 7
    }, this),
    defaults: () => ({
      extraDmgProc: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.BASIC_SCALING += r.extraDmgProc ? sValues[s] : 0;
      x.SKILL_SCALING += r.extraDmgProc ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c33 = WeWillMeetAgain;
function WarmthShortensColdNights( /* s */
) {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 885,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c34 = WarmthShortensColdNights;
function TheSeriousnessOfBreakfast(s) {
  let sValuesDmgBoost = [0.12, 0.15, 0.18, 0.21, 0.24];
  let sValuesStacks = [0.04, 0.05, 0.06, 0.07, 0.08];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "dmgBoost",
        text: "Dmg boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 905,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "defeatedEnemyAtkStacks",
        text: "Defeated enemy atk stacks",
        min: 0,
        max: 3,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 906,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 904,
      columnNumber: 7
    }, this),
    defaults: () => ({
      dmgBoost: true,
      defeatedEnemyAtkStacks: 3
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.defeatedEnemyAtkStacks * sValuesStacks[s];
      x.ELEMENTAL_DMG += r.dmgBoost ? sValuesDmgBoost[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c35 = TheSeriousnessOfBreakfast;
function WoofWalkTime(s) {
  const sValues = [0.16, 0.20, 0.24, 0.28, 0.32];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyBurnedBleeding",
        text: "Enemy burned / bleeding",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 930,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 929,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyBurnedBleeding: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.enemyBurnedBleeding ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c36 = WoofWalkTime;
function PastAndFuture( /* s */
) {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 951,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c37 = PastAndFuture;
function RiverFlowsInSpring(s) {
  let sValuesSpd = [0.08, 0.09, 0.10, 0.11, 0.12];
  let sValuesDmg = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "spdDmgBuff",
        text: "Spd / dmg buff active",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 971,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 970,
      columnNumber: 7
    }, this),
    defaults: () => ({
      spdDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.SPD_P] += r.spdDmgBuff ? sValuesSpd[s] : 0;
      x.ELEMENTAL_DMG += r.spdDmgBuff ? sValuesDmg[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c38 = RiverFlowsInSpring;
function WeAreWildfire(s) {
  const sValues = [0.08, 0.10, 0.12, 0.14, 0.16];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "initialDmgReductionBuff",
        text: "Initial dmg reduction buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 994,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 993,
      columnNumber: 7
    }, this),
    defaults: () => ({
      initialDmgReductionBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.DMG_RED_MULTI += r.initialDmgReductionBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c39 = WeAreWildfire;
function Fermata(s) {
  const sValues = [0.16, 0.20, 0.24, 0.28, 0.32];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyShockWindShear",
        text: "Enemy shocked / wind sheared",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1016,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1015,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyShockWindShear: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.enemyShockWindShear ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c40 = Fermata;
function QuidProQuo( /* s */
) {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1037,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c41 = QuidProQuo;
function GeniusesRepose(s) {
  const sValues = [0.24, 0.30, 0.36, 0.42, 0.48];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "defeatedEnemyCdBuff",
        text: "Defeated enemy cd buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1056,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1055,
      columnNumber: 7
    }, this),
    defaults: () => ({
      defeatedEnemyCdBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CD] += r.defeatedEnemyCdBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c42 = GeniusesRepose;
function UnderTheBlueSky(s) {
  const sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "defeatedEnemyCrBuff",
        text: "Defeated enemy cr buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1078,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1077,
      columnNumber: 7
    }, this),
    defaults: () => ({
      defeatedEnemyCrBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CR] += r.defeatedEnemyCrBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c43 = UnderTheBlueSky;
function DanceDanceDance( /* s */
) {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1099,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c44 = DanceDanceDance;
function SubscribeForMore(s) {
  const sValues = [0.24, 0.30, 0.36, 0.42, 0.48];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "maxEnergyDmgBoost",
        text: "Max energy dmg boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1118,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1117,
      columnNumber: 7
    }, this),
    defaults: () => ({
      maxEnergyDmgBoost: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.BASIC_BOOST += sValues[s];
      x.SKILL_BOOST += sValues[s];
      x.BASIC_BOOST += r.maxEnergyDmgBoost ? sValues[s] : 0;
      x.SKILL_BOOST += r.maxEnergyDmgBoost ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c45 = SubscribeForMore;
function TrendOfTheUniversalMarket( /* s */
) {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1142,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c46 = TrendOfTheUniversalMarket;
function ResolutionShinesAsPearlsOfSweat(s) {
  const sValues = [0.12, 0.13, 0.14, 0.15, 0.16];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "targetEnsnared",
        text: "Target ensnared",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1161,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1160,
      columnNumber: 7
    }, this),
    defaults: () => ({
      targetEnsnared: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.DEF_SHRED += r.targetEnsnared ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c47 = ResolutionShinesAsPearlsOfSweat;
function PerfectTiming(s) {
  const sValues = [0.33, 0.36, 0.39, 0.42, 0.45];
  let sMaxValues = [0.15, 0.18, 0.21, 0.24, 0.27];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "resToHealingBoost",
        text: "Res to healing boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1184,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1183,
      columnNumber: 7
    }, this),
    defaults: () => ({
      resToHealingBoost: true
    }),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: (c, request) => {
      let r = request.lightConeConditionals;
      let x = c.x;
      let boost = Math.min(sMaxValues[s], sValues[s] * x[Stats.RES]);
      x[Stats.OHB] += r.resToHealingBoost ? boost : 0;
    }
  };
}
_c48 = PerfectTiming;
function MakeTheWorldClamor(s) {
  const sValues = [0.32, 0.40, 0.48, 0.56, 0.64];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultDmgBuff",
        text: "Ult dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1210,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1209,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ULT_BOOST += r.ultDmgBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c49 = MakeTheWorldClamor;
function ASecretVow(s) {
  const sValues = [0.20, 0.25, 0.30, 0.35, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyHpHigherDmgBoost",
        text: "Enemy HP % higher dmg boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1232,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1231,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyHpHigherDmgBoost: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += sValues[s];
      x.ELEMENTAL_DMG += r.enemyHpHigherDmgBoost ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c50 = ASecretVow;
function PlanetaryRendezvous(s) {
  const sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "alliesSameElement",
        text: "Allies same element dmg boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1255,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1254,
      columnNumber: 7
    }, this),
    defaults: () => ({
      alliesSameElement: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.alliesSameElement ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c51 = PlanetaryRendezvous;
function Swordplay(s) {
  const sValues = [0.08, 0.10, 0.12, 0.14, 0.16];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "sameTargetHitStacks",
        text: "Same target hit stacks",
        min: 0,
        max: 5,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1277,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1276,
      columnNumber: 7
    }, this),
    defaults: () => ({
      sameTargetHitStacks: 5
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.sameTargetHitStacks * sValues[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c52 = Swordplay;
function LandausChoice(s) {
  const sValues = [0.16, 0.18, 0.20, 0.22, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1298,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: (x /* request */) => {
      // let r = request.lightConeConditionals

      x.DMG_RED_MULTI += sValues[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c53 = LandausChoice;
function EyesOfThePrey(s) {
  const sValues = [0.24, 0.30, 0.36, 0.42, 0.48];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1318,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: (x /* request */) => {
      // let r = request.lightConeConditionals

      x.DOT_BOOST += sValues[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c54 = EyesOfThePrey;
function SharedFeeling(s) {
  const sValues = [0.10, 0.125, 0.15, 0.175, 0.20];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1338,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: (x /* request */) => {
      // let r = request.lightConeConditionals

      x[Stats.OHB] += sValues[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c55 = SharedFeeling;
function TheBirthOfTheSelf(s) {
  const sValues = [0.24, 0.30, 0.36, 0.42, 0.48];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyHp50FuaBuff",
        text: "Enemy HP < 50% fua buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1359,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1358,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyHp50FuaBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.xxxxxxxxxxxxxxxxxxxxx] += r.name ? sValues[s] : 0;
      x.FUA_BOOST += sValues[s];
      x.FUA_BOOST += r.enemyHp50FuaBuff && request.enemyHpPercent < 0.50 ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c56 = TheBirthOfTheSelf;
function TheMolesWelcomeYou(s) {
  const sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "atkBuffStacks",
        text: "Atk buff stacks",
        min: 0,
        max: 3,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1383,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1382,
      columnNumber: 7
    }, this),
    defaults: () => ({
      atkBuffStacks: 3
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.atkBuffStacks * sValues[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c57 = TheMolesWelcomeYou;
function MemoriesOfThePast() {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1404,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c58 = MemoriesOfThePast;
function OnlySilenceRemains(s) {
  let sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemies2CrBuff",
        text: "<= 2 enemies cr buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1423,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1422,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemies2CrBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CR] += r.enemies2CrBuff && request.enemyCount <= 2 ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c59 = OnlySilenceRemains;
function DayOneOfMyNewLife(s) {
  const sValues = [0.16, 0.18, 0.20, 0.22, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "dmgResBuff",
        text: "Dmg RES buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1445,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1444,
      columnNumber: 7
    }, this),
    defaults: () => ({
      dmgResBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.DMG_RED_MULTI += r.dmgResBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c60 = DayOneOfMyNewLife;
function GoodNightAndSleepWell(s) {
  const sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "debuffStacksDmgIncrease",
        text: "Debuff stacks dmg increase",
        min: 0,
        max: 3,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1467,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1466,
      columnNumber: 7
    }, this),
    defaults: () => ({
      debuffStacksDmgIncrease: 3
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.debuffStacksDmgIncrease * sValues[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c61 = GoodNightAndSleepWell;
function PostOpConversation(s) {
  const sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "postUltHealingBoost",
        text: "Post ult healing boost",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1489,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1488,
      columnNumber: 7
    }, this),
    defaults: () => ({
      postUltHealingBoost: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.OHB] += r.postUltHealingBoost ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c62 = PostOpConversation;
function Sagacity(s) {
  const sValues = [0.24, 0.30, 0.36, 0.42, 0.48];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "postUltAtkBuff",
        text: "Post ult atk buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1511,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1510,
      columnNumber: 7
    }, this),
    defaults: () => ({
      postUltAtkBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.postUltAtkBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c63 = Sagacity;
function Mediation(s) {
  const sValues = [12, 14, 16, 18, 20];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "initialSpdBuff",
        text: "Initial spd buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1533,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1532,
      columnNumber: 7
    }, this),
    defaults: () => ({
      initialSpdBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.SPD] += r.initialSpdBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c64 = Mediation;
function HiddenShadow(s) {
  const sValues = [0.60, 0.75, 0.90, 1.05, 1.20];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "basicAtkBuff",
        text: "Basic atk buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1555,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1554,
      columnNumber: 7
    }, this),
    defaults: () => ({
      basicAtkBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.BASIC_BOOST += r.basicAtkBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c65 = HiddenShadow;
function Pioneering() {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1576,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c66 = Pioneering;
function MutualDemise(s) {
  const sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "selfHp80CrBuff",
        text: "Self HP <80% cr buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1595,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1594,
      columnNumber: 7
    }, this),
    defaults: () => ({
      selfHp80CrBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CR] += r.selfHp80CrBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c67 = MutualDemise;
function Multiplication() {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1616,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c68 = Multiplication;
function Adversarial(s) {
  const sValues = [0.10, 0.12, 0.14, 0.16, 0.18];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "defeatedEnemySpdBuff",
        text: "Defeated enemy spd buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1635,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1634,
      columnNumber: 7
    }, this),
    defaults: () => ({
      defeatedEnemySpdBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.SPD_P] += r.defeatedEnemySpdBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c69 = Adversarial;
function Passkey() {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1656,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c70 = Passkey;
function MeshingCogs() {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1674,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      //  let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c71 = MeshingCogs;
function Loop(s) {
  const sValues = [0.24, 0.30, 0.36, 0.42, 0.48];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemySlowedDmgBuff",
        text: "Enemy slowed dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1693,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1692,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemySlowedDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.enemySlowedDmgBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c72 = Loop;
function Defense() {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1714,
      columnNumber: 7
    }, this),
    defaults: () => ({}),
    precomputeEffects: ( /* x, request */
    ) => {
      // let r = request.lightConeConditionals
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c73 = Defense;
function ShatteredHome(s) {
  const sValues = [0.20, 0.25, 0.30, 0.35, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "enemyHp50Buff",
        text: "Enemy HP >50% dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1733,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1732,
      columnNumber: 7
    }, this),
    defaults: () => ({
      enemyHp50Buff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ELEMENTAL_DMG += r.enemyHp50Buff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c74 = ShatteredHome;
function FineFruit() {
  // const sValues = [0, 0, 0, 0, 0]

  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1754,
      columnNumber: 7
    }, this),
    defaults: () => ({
      name: true
    }),
    precomputeEffects: (x, request) => {
      console.warn('not implemented', x, request);
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c75 = FineFruit;
function DartingArrow(s) {
  const sValues = [0.24, 0.30, 0.36, 0.42, 0.48];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "defeatedEnemyAtkBuff",
        text: "Atk buff on kill",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1772,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1771,
      columnNumber: 7
    }, this),
    defaults: () => ({
      defeatedEnemyAtkBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.defeatedEnemyAtkBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c76 = DartingArrow;
function DataBank(s) {
  const sValues = [0.28, 0.35, 0.42, 0.49, 0.56];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "ultDmgBuff",
        text: "Ult dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1794,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1793,
      columnNumber: 7
    }, this),
    defaults: () => ({
      ultDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.ULT_BOOST += r.ultDmgBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c77 = DataBank;
function Chorus(s) {
  const sValues = [0.08, 0.09, 0.10, 0.11, 0.12];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "inBattleAtkBuff",
        text: "In battle atk buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1816,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1815,
      columnNumber: 7
    }, this),
    defaults: () => ({
      inBattleAtkBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.inBattleAtkBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c78 = Chorus;
function Void(s) {
  const sValues = [0.20, 0.25, 0, 30, 0.35, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "initialEhrBuff",
        text: "Initial EHR buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1838,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1837,
      columnNumber: 7
    }, this),
    defaults: () => ({
      initialEhrBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.EHR] += r.initialEhrBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c79 = Void;
function Amber(s) {
  const sValues = [0.16, 0.20, 0.24, 0.28, 0.32];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "hp50DefBuff",
        text: "HP <50% def buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1861,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1860,
      columnNumber: 7
    }, this),
    defaults: () => ({
      hp50DefBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.DEF_P] += r.hp50DefBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c80 = Amber;
function CollapsingSky(s) {
  const sValues = [0.20, 0.25, 0.30, 0.35, 0.40];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "basicSkillDmgBuff",
        text: "Basic/Skill dmg buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1883,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1882,
      columnNumber: 7
    }, this),
    defaults: () => ({
      basicSkillDmgBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x.BASIC_BOOST += r.basicSkillDmgBuff ? sValues[s] : 0;
      x.SKILL_BOOST += r.basicSkillDmgBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c81 = CollapsingSky;
function Cornucopia(s) {
  const sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "healingBuff",
        text: "Healing buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1906,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1905,
      columnNumber: 7
    }, this),
    defaults: () => ({
      healingBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.OHB] += r.healingBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c82 = Cornucopia;
function Arrows(s) {
  const sValues = [0.12, 0.15, 0.18, 0.21, 0.24];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "critBuff",
        text: "Initial crit buff",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1928,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1927,
      columnNumber: 7
    }, this),
    defaults: () => ({
      critBuff: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CR] += r.critBuff ? sValues[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c83 = Arrows;
function ReforgedRemembrance(s) {
  let sValuesAtk = [0.05, 0.06, 0.07, 0.08, 0.09];
  let sValuesDotPen = [0.072, 0.079, 0.086, 0.093, 0.10];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSlider, {
        name: "prophetStacks",
        text: "Prophet stacks",
        min: 0,
        max: 4,
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1951,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1950,
      columnNumber: 7
    }, this),
    defaults: () => ({
      prophetStacks: 4
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.ATK_P] += r.prophetStacks * sValuesAtk[s];
      x.DOT_DEF_PEN += r.prophetStacks * sValuesDotPen[s];
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c84 = ReforgedRemembrance;
function EarthlyEscapade(s) {
  const sValuesCr = [0.10, 0.11, 0.12, 0.13, 0.14];
  const sValuesCd = [0.28, 0.35, 0.42, 0.49, 0.56];
  return {
    display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: defaultGap,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_optimizerTab_FormConditionalInputs__WEBPACK_IMPORTED_MODULE_3__.FormSwitch, {
        name: "maskActive",
        text: "Mask active",
        lc: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 1975,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 1974,
      columnNumber: 7
    }, this),
    defaults: () => ({
      maskActive: true
    }),
    precomputeEffects: (x, request) => {
      let r = request.lightConeConditionals;
      x[Stats.CR] += r.maskActive ? sValuesCr[s] : 0;
      x[Stats.CD] += r.maskActive ? sValuesCd[s] : 0;
    },
    calculatePassives: ( /*c, request */) => {},
    calculateBaseMultis: ( /* c, request */) => {}
  };
}
_c85 = EarthlyEscapade;
const LightConeConditionals = {
  get: request => {
    let lcFn = lightConeOptionMapping[request.lightCone];
    if (!lcFn) {
      return {
        display: () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
          vertical: true,
          gap: 5,
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_HeaderText__WEBPACK_IMPORTED_MODULE_1__.HeaderText, {
            children: "Light cone passives"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1999,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 1998,
          columnNumber: 11
        }, undefined),
        defaults: () => ({})
      };
    }
    return lcFn(request.lightConeSuperimposition - 1);
  },
  getDisplayForLightCone: (id, superimposition) => {
    if (!id || !lightConeOptionMapping[id]) {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
        vertical: true,
        gap: 5,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
          justify: "space-between",
          align: "center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_HeaderText__WEBPACK_IMPORTED_MODULE_1__.HeaderText, {
            children: "Light cone passives"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 2012,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_TooltipImage__WEBPACK_IMPORTED_MODULE_4__.TooltipImage, {
            type: _hint__WEBPACK_IMPORTED_MODULE_5__.Hint.lightConePassives()
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 2013,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 2011,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_8__["default"].Text, {
          italic: true,
          children: "Select a Light cone to view passives"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 2015,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 2010,
        columnNumber: 9
      }, undefined);
    }
    let lcFn = lightConeOptionMapping[id];
    let display = lcFn(superimposition - 1).display();
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
      vertical: true,
      gap: 5,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(antd__WEBPACK_IMPORTED_MODULE_7__["default"], {
        justify: "space-between",
        align: "center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_HeaderText__WEBPACK_IMPORTED_MODULE_1__.HeaderText, {
          children: "Light cone passives"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 2026,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_components_TooltipImage__WEBPACK_IMPORTED_MODULE_4__.TooltipImage, {
          type: _hint__WEBPACK_IMPORTED_MODULE_5__.Hint.lightConePassives()
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 2027,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 2025,
        columnNumber: 9
      }, undefined), display]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 2024,
      columnNumber: 7
    }, undefined);
  }
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27, _c28, _c29, _c30, _c31, _c32, _c33, _c34, _c35, _c36, _c37, _c38, _c39, _c40, _c41, _c42, _c43, _c44, _c45, _c46, _c47, _c48, _c49, _c50, _c51, _c52, _c53, _c54, _c55, _c56, _c57, _c58, _c59, _c60, _c61, _c62, _c63, _c64, _c65, _c66, _c67, _c68, _c69, _c70, _c71, _c72, _c73, _c74, _c75, _c76, _c77, _c78, _c79, _c80, _c81, _c82, _c83, _c84, _c85;
__webpack_require__.$Refresh$.register(_c, "BaptismOfPureThought");
__webpack_require__.$Refresh$.register(_c2, "PastSelfInMirror");
__webpack_require__.$Refresh$.register(_c3, "SolitaryHealing");
__webpack_require__.$Refresh$.register(_c4, "TextureOfMemories");
__webpack_require__.$Refresh$.register(_c5, "CruisingInTheStellarSea");
__webpack_require__.$Refresh$.register(_c6, "OnTheFallOfAnAeon");
__webpack_require__.$Refresh$.register(_c7, "AnInstantBeforeAGaze");
__webpack_require__.$Refresh$.register(_c8, "NightOfFright");
__webpack_require__.$Refresh$.register(_c9, "WorrisomeBlissful");
__webpack_require__.$Refresh$.register(_c10, "BrighterThanTheSun");
__webpack_require__.$Refresh$.register(_c11, "IShallBeMyOwnSword");
__webpack_require__.$Refresh$.register(_c12, "TimeWaitsForNoOne");
__webpack_require__.$Refresh$.register(_c13, "SleepLikeTheDead");
__webpack_require__.$Refresh$.register(_c14, "SheAlreadyShutHerEyes");
__webpack_require__.$Refresh$.register(_c15, "BeforeDawn");
__webpack_require__.$Refresh$.register(_c16, "TheUnreachableSide");
__webpack_require__.$Refresh$.register(_c17, "EchoesOfTheCoffin");
__webpack_require__.$Refresh$.register(_c18, "IncessantRain");
__webpack_require__.$Refresh$.register(_c19, "PatienceIsAllYouNeed");
__webpack_require__.$Refresh$.register(_c20, "MomentOfVictory");
__webpack_require__.$Refresh$.register(_c21, "InTheNameOfTheWorld");
__webpack_require__.$Refresh$.register(_c22, "ButTheBattleIsntOver");
__webpack_require__.$Refresh$.register(_c23, "SomethingIrreplaceable");
__webpack_require__.$Refresh$.register(_c24, "InTheNight");
__webpack_require__.$Refresh$.register(_c25, "NightOnTheMilkyWay");
__webpack_require__.$Refresh$.register(_c26, "HeyOverHere");
__webpack_require__.$Refresh$.register(_c27, "BeforeTheTutorialMissionStarts");
__webpack_require__.$Refresh$.register(_c28, "TodayIsAnotherPeacefulDay");
__webpack_require__.$Refresh$.register(_c29, "NowhereToRun");
__webpack_require__.$Refresh$.register(_c30, "CarveTheMoonWeaveTheClouds");
__webpack_require__.$Refresh$.register(_c31, "ReturnToDarkness");
__webpack_require__.$Refresh$.register(_c32, "ThisIsMe");
__webpack_require__.$Refresh$.register(_c33, "WeWillMeetAgain");
__webpack_require__.$Refresh$.register(_c34, "WarmthShortensColdNights");
__webpack_require__.$Refresh$.register(_c35, "TheSeriousnessOfBreakfast");
__webpack_require__.$Refresh$.register(_c36, "WoofWalkTime");
__webpack_require__.$Refresh$.register(_c37, "PastAndFuture");
__webpack_require__.$Refresh$.register(_c38, "RiverFlowsInSpring");
__webpack_require__.$Refresh$.register(_c39, "WeAreWildfire");
__webpack_require__.$Refresh$.register(_c40, "Fermata");
__webpack_require__.$Refresh$.register(_c41, "QuidProQuo");
__webpack_require__.$Refresh$.register(_c42, "GeniusesRepose");
__webpack_require__.$Refresh$.register(_c43, "UnderTheBlueSky");
__webpack_require__.$Refresh$.register(_c44, "DanceDanceDance");
__webpack_require__.$Refresh$.register(_c45, "SubscribeForMore");
__webpack_require__.$Refresh$.register(_c46, "TrendOfTheUniversalMarket");
__webpack_require__.$Refresh$.register(_c47, "ResolutionShinesAsPearlsOfSweat");
__webpack_require__.$Refresh$.register(_c48, "PerfectTiming");
__webpack_require__.$Refresh$.register(_c49, "MakeTheWorldClamor");
__webpack_require__.$Refresh$.register(_c50, "ASecretVow");
__webpack_require__.$Refresh$.register(_c51, "PlanetaryRendezvous");
__webpack_require__.$Refresh$.register(_c52, "Swordplay");
__webpack_require__.$Refresh$.register(_c53, "LandausChoice");
__webpack_require__.$Refresh$.register(_c54, "EyesOfThePrey");
__webpack_require__.$Refresh$.register(_c55, "SharedFeeling");
__webpack_require__.$Refresh$.register(_c56, "TheBirthOfTheSelf");
__webpack_require__.$Refresh$.register(_c57, "TheMolesWelcomeYou");
__webpack_require__.$Refresh$.register(_c58, "MemoriesOfThePast");
__webpack_require__.$Refresh$.register(_c59, "OnlySilenceRemains");
__webpack_require__.$Refresh$.register(_c60, "DayOneOfMyNewLife");
__webpack_require__.$Refresh$.register(_c61, "GoodNightAndSleepWell");
__webpack_require__.$Refresh$.register(_c62, "PostOpConversation");
__webpack_require__.$Refresh$.register(_c63, "Sagacity");
__webpack_require__.$Refresh$.register(_c64, "Mediation");
__webpack_require__.$Refresh$.register(_c65, "HiddenShadow");
__webpack_require__.$Refresh$.register(_c66, "Pioneering");
__webpack_require__.$Refresh$.register(_c67, "MutualDemise");
__webpack_require__.$Refresh$.register(_c68, "Multiplication");
__webpack_require__.$Refresh$.register(_c69, "Adversarial");
__webpack_require__.$Refresh$.register(_c70, "Passkey");
__webpack_require__.$Refresh$.register(_c71, "MeshingCogs");
__webpack_require__.$Refresh$.register(_c72, "Loop");
__webpack_require__.$Refresh$.register(_c73, "Defense");
__webpack_require__.$Refresh$.register(_c74, "ShatteredHome");
__webpack_require__.$Refresh$.register(_c75, "FineFruit");
__webpack_require__.$Refresh$.register(_c76, "DartingArrow");
__webpack_require__.$Refresh$.register(_c77, "DataBank");
__webpack_require__.$Refresh$.register(_c78, "Chorus");
__webpack_require__.$Refresh$.register(_c79, "Void");
__webpack_require__.$Refresh$.register(_c80, "Amber");
__webpack_require__.$Refresh$.register(_c81, "CollapsingSky");
__webpack_require__.$Refresh$.register(_c82, "Cornucopia");
__webpack_require__.$Refresh$.register(_c83, "Arrows");
__webpack_require__.$Refresh$.register(_c84, "ReforgedRemembrance");
__webpack_require__.$Refresh$.register(_c85, "EarthlyEscapade");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/lib/worker/optimizerWorker.js":
/*!*******************************************!*\
  !*** ./src/lib/worker/optimizerWorker.js ***!
  \*******************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _constants_ts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants.ts */ "./src/lib/constants.ts");
/* harmony import */ var _bufferPacker_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../bufferPacker.js */ "./src/lib/bufferPacker.js");
/* harmony import */ var _characterConditionals_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../characterConditionals.js */ "./src/lib/characterConditionals.js");
/* harmony import */ var _lightConeConditionals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lightConeConditionals */ "./src/lib/lightConeConditionals.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");





function sumRelicStats(headRelics, handsRelics, bodyRelics, feetRelics, planarSphereRelics, linkRopeRelics, h, g, b, f, p, l, statValues) {
  let summedStats = {};
  for (let stat of statValues) {
    summedStats[stat] = headRelics[h].augmentedStats[stat] + handsRelics[g].augmentedStats[stat] + bodyRelics[b].augmentedStats[stat] + feetRelics[f].augmentedStats[stat] + planarSphereRelics[p].augmentedStats[stat] + linkRopeRelics[l].augmentedStats[stat];
  }
  summedStats.WEIGHT = headRelics[h].weightScore + handsRelics[g].weightScore + bodyRelics[b].weightScore + feetRelics[f].weightScore + planarSphereRelics[p].weightScore + linkRopeRelics[l].weightScore;
  return summedStats;
}
function calculateFlatStat(stat, statP, baseValue, lc, trace, relicSum, setEffects) {
  return baseValue * (1 + setEffects + relicSum[statP] + trace[statP] + lc[statP]) + relicSum[stat] + trace[stat];
}
function calculateBaseStat(stat, base, lc) {
  return base[stat] + lc[stat];
}
function calculatePercentStat(stat, base, lc, trace, relicSum, setEffects) {
  return base[stat] + lc[stat] + relicSum[stat] + trace[stat] + setEffects;
}
self.onmessage = function (e) {
  console.warn("Message received from main script", e.data);
  // console.warn("Request received from main script", JSON.stringify(e.data.request.characterConditionals, null, 4));

  let data = e.data;
  let relics = data.relics;
  let character = data.character;
  let Stats = _constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Stats;
  let statValues = Object.values(Stats);
  let arr = new Float64Array(data.buffer);
  let headRelics = relics.Head;
  let handsRelics = relics.Hands;
  let bodyRelics = relics.Body;
  let feetRelics = relics.Feet;
  let planarSphereRelics = relics.PlanarSphere;
  let linkRopeRelics = relics.LinkRope;
  let topRow = data.topRow;
  let lSize = topRow ? 1 : data.consts.lSize;
  let pSize = topRow ? 1 : data.consts.pSize;
  let fSize = topRow ? 1 : data.consts.fSize;
  let bSize = topRow ? 1 : data.consts.bSize;
  let gSize = topRow ? 1 : data.consts.gSize;
  let hSize = topRow ? 1 : data.consts.hSize;
  let relicSetSolutions = data.consts.relicSetSolutions;
  let ornamentSetSolutions = data.consts.ornamentSetSolutions;
  let relicSetToIndex = data.relicSetToIndex;
  let ornamentSetToIndex = data.ornamentSetToIndex;
  let elementalMultipliers = data.elementalMultipliers;
  let trace = character.traces;
  let lc = character.lightCone;
  let base = character.base;
  let request = data.request;
  let setConditionals = request.setConditionals;
  let characterConditionals = _characterConditionals_js__WEBPACK_IMPORTED_MODULE_2__.CharacterConditionals.get(request);
  let lightConeConditionals = _lightConeConditionals__WEBPACK_IMPORTED_MODULE_3__.LightConeConditionals.get(request);
  let enabledHunterOfGlacialForest = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.HunterOfGlacialForest][1] == true ? 1 : 0;
  let enabledFiresmithOfLavaForging = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.FiresmithOfLavaForging][1] == true ? 1 : 0;
  let enabledGeniusOfBrilliantStars = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.GeniusOfBrilliantStars][1] == true ? 1 : 0;
  let enabledBandOfSizzlingThunder = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.BandOfSizzlingThunder][1] == true ? 1 : 0;
  let enabledMessengerTraversingHackerspace = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.MessengerTraversingHackerspace][1] == true ? 1 : 0;
  let enabledCelestialDifferentiator = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.CelestialDifferentiator][1] == true ? 1 : 0;
  let valueChampionOfStreetwiseBoxing = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.ChampionOfStreetwiseBoxing][1];
  let valueWastelanderOfBanditryDesert = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.WastelanderOfBanditryDesert][1];
  let valueLongevousDisciple = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.LongevousDisciple][1];
  let valueTheAshblazingGrandDuke = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.TheAshblazingGrandDuke][1];
  let valuePrisonerInDeepConfinement = setConditionals[_constants_ts__WEBPACK_IMPORTED_MODULE_0__.Constants.Sets.PrisonerInDeepConfinement][1];

  // console.warn('!!!', request)
  // console.warn('!!!', setConditionals)
  // console.warn('!!!', enabledHunterOfGlacialForest)
  // console.warn('!!!', valueChampionOfStreetwiseBoxing)

  let brokenMultiplier = request.enemyWeaknessBroken ? 1 : 0.9;
  let resistance = request.enemyElementalWeak ? 0 : request.enemyResistance;
  let precomputedX = characterConditionals.precomputeEffects(request);
  lightConeConditionals.precomputeEffects(precomputedX, request);
  let combatDisplay = request.statDisplay == 'combat';
  for (let row = 0; row < data.HEIGHT; row++) {
    for (let col = 0; col < data.WIDTH; col++) {
      let index = data.skip + row * data.HEIGHT + col;
      if (index >= data.permutations) {
        continue;
      }
      let l = index % lSize;
      let p = (index - l) / lSize % pSize;
      let f = (index - p * lSize - l) / (lSize * pSize) % fSize;
      let b = (index - f * pSize * lSize - p * lSize - l) / (lSize * pSize * fSize) % bSize;
      let g = (index - b * fSize * pSize * lSize - f * pSize * lSize - p * lSize - l) / (lSize * pSize * fSize * bSize) % gSize;
      let h = (index - g * bSize * fSize * pSize * lSize - b * fSize * pSize * lSize - f * pSize * lSize - p * lSize - l) / (lSize * pSize * fSize * bSize * gSize) % hSize;
      let c = sumRelicStats(headRelics, handsRelics, bodyRelics, feetRelics, planarSphereRelics, linkRopeRelics, h, g, b, f, p, l, statValues);
      let setH = relicSetToIndex[relics.Head[h].set];
      let setG = relicSetToIndex[relics.Hands[g].set];
      let setB = relicSetToIndex[relics.Body[b].set];
      let setF = relicSetToIndex[relics.Feet[f].set];
      let setP = ornamentSetToIndex[relics.PlanarSphere[p].set];
      let setL = ornamentSetToIndex[relics.LinkRope[l].set];
      let relicSetCount = data.consts.relicSetCount;
      let ornamentSetCount = data.consts.ornamentSetCount;
      let relicSetIndex = setH + setB * relicSetCount + setG * relicSetCount * relicSetCount + setF * relicSetCount * relicSetCount * relicSetCount;
      let ornamentSetIndex = setP + setL * ornamentSetCount;
      c.relicSetIndex = relicSetIndex;
      c.ornamentSetIndex = ornamentSetIndex;
      c.sets = {};
      let sets = c.sets;
      sets.PasserbyOfWanderingCloud = (1 >> (setH ^ 0)) + (1 >> (setG ^ 0)) + (1 >> (setB ^ 0)) + (1 >> (setF ^ 0)); // * 4p -
      sets.MusketeerOfWildWheat = (1 >> (setH ^ 1)) + (1 >> (setG ^ 1)) + (1 >> (setB ^ 1)) + (1 >> (setF ^ 1)); // * 4p SPD 6% + basic 10%
      sets.KnightOfPurityPalace = (1 >> (setH ^ 2)) + (1 >> (setG ^ 2)) + (1 >> (setB ^ 2)) + (1 >> (setF ^ 2)); // * 4p SHIELD
      sets.HunterOfGlacialForest = (1 >> (setH ^ 3)) + (1 >> (setG ^ 3)) + (1 >> (setB ^ 3)) + (1 >> (setF ^ 3)); // * 4p (25% CD)
      sets.ChampionOfStreetwiseBoxing = (1 >> (setH ^ 4)) + (1 >> (setG ^ 4)) + (1 >> (setB ^ 4)) + (1 >> (setF ^ 4)); // * 4p (5x5% ATK)
      sets.GuardOfWutheringSnow = (1 >> (setH ^ 5)) + (1 >> (setG ^ 5)) + (1 >> (setB ^ 5)) + (1 >> (setF ^ 5)); // * 4p -
      sets.FiresmithOfLavaForging = (1 >> (setH ^ 6)) + (1 >> (setG ^ 6)) + (1 >> (setB ^ 6)) + (1 >> (setF ^ 6)); // * 4p 12% skill + (12% Fire)
      sets.GeniusOfBrilliantStars = (1 >> (setH ^ 7)) + (1 >> (setG ^ 7)) + (1 >> (setB ^ 7)) + (1 >> (setF ^ 7)); //   4p done
      sets.BandOfSizzlingThunder = (1 >> (setH ^ 8)) + (1 >> (setG ^ 8)) + (1 >> (setB ^ 8)) + (1 >> (setF ^ 8)); //   4p (20% ATK)
      sets.EagleOfTwilightLine = (1 >> (setH ^ 9)) + (1 >> (setG ^ 9)) + (1 >> (setB ^ 9)) + (1 >> (setF ^ 9)); //   4p -
      sets.ThiefOfShootingMeteor = (1 >> (setH ^ 10)) + (1 >> (setG ^ 10)) + (1 >> (setB ^ 10)) + (1 >> (setF ^ 10)); //  4p 16% BE
      sets.WastelanderOfBanditryDesert = (1 >> (setH ^ 11)) + (1 >> (setG ^ 11)) + (1 >> (setB ^ 11)) + (1 >> (setF ^ 11)); //  4p (10% CD) + (20% CR)
      sets.LongevousDisciple = (1 >> (setH ^ 12)) + (1 >> (setG ^ 12)) + (1 >> (setB ^ 12)) + (1 >> (setF ^ 12)); //  4p (2x8% CR)
      sets.MessengerTraversingHackerspace = (1 >> (setH ^ 13)) + (1 >> (setG ^ 13)) + (1 >> (setB ^ 13)) + (1 >> (setF ^ 13)); //  4p (12% SPD)
      sets.TheAshblazingGrandDuke = (1 >> (setH ^ 14)) + (1 >> (setG ^ 14)) + (1 >> (setB ^ 14)) + (1 >> (setF ^ 14)); //  4p (8*6% ATK) todo
      sets.PrisonerInDeepConfinement = (1 >> (setH ^ 15)) + (1 >> (setG ^ 15)) + (1 >> (setB ^ 15)) + (1 >> (setF ^ 15)); //  4p done

      sets.SpaceSealingStation = (1 >> (setP ^ 0)) + (1 >> (setL ^ 0)); // (12% ATK)
      sets.FleetOfTheAgeless = (1 >> (setP ^ 1)) + (1 >> (setL ^ 1)); // (8% ATK)
      sets.PanCosmicCommercialEnterprise = (1 >> (setP ^ 2)) + (1 >> (setL ^ 2)); // (25% ATK)
      sets.BelobogOfTheArchitects = (1 >> (setP ^ 3)) + (1 >> (setL ^ 3)); // (15% DEF)
      sets.CelestialDifferentiator = (1 >> (setP ^ 4)) + (1 >> (setL ^ 4)); // (60% CR)
      sets.InertSalsotto = (1 >> (setP ^ 5)) + (1 >> (setL ^ 5)); // (15% ULT/FUA)
      sets.TaliaKingdomOfBanditry = (1 >> (setP ^ 6)) + (1 >> (setL ^ 6)); // (20% BE)
      sets.SprightlyVonwacq = (1 >> (setP ^ 7)) + (1 >> (setL ^ 7)); // -
      sets.RutilantArena = (1 >> (setP ^ 8)) + (1 >> (setL ^ 8)); // (20% BASIC/SKILL)
      sets.BrokenKeel = (1 >> (setP ^ 9)) + (1 >> (setL ^ 9)); // (10% CD)
      sets.FirmamentFrontlineGlamoth = (1 >> (setP ^ 10)) + (1 >> (setL ^ 10)); // (12%/18% DMG)
      sets.PenaconyLandOfTheDreams = (1 >> (setP ^ 11)) + (1 >> (setL ^ 11)); // -

      // ************************************************************
      // Old elemental dmg logic
      // ************************************************************

      c.ELEMENTAL_DMG = 0;
      if (elementalMultipliers[0]) c.ELEMENTAL_DMG = calculatePercentStat(Stats.Physical_DMG, base, lc, trace, c, 0.10 * p2(sets.ChampionOfStreetwiseBoxing));
      if (elementalMultipliers[1]) c.ELEMENTAL_DMG = calculatePercentStat(Stats.Fire_DMG, base, lc, trace, c, 0.10 * p2(sets.FiresmithOfLavaForging) + 0.10 * enabledFiresmithOfLavaForging * p4(sets.FiresmithOfLavaForging));
      if (elementalMultipliers[2]) c.ELEMENTAL_DMG = calculatePercentStat(Stats.Ice_DMG, base, lc, trace, c, 0.10 * p2(sets.HunterOfGlacialForest));
      if (elementalMultipliers[3]) c.ELEMENTAL_DMG = calculatePercentStat(Stats.Lightning_DMG, base, lc, trace, c, 0.10 * p2(sets.BandOfSizzlingThunder));
      if (elementalMultipliers[4]) c.ELEMENTAL_DMG = calculatePercentStat(Stats.Wind_DMG, base, lc, trace, c, 0.10 * p2(sets.EagleOfTwilightLine));
      if (elementalMultipliers[5]) c.ELEMENTAL_DMG = calculatePercentStat(Stats.Quantum_DMG, base, lc, trace, c, 0.10 * p2(sets.GeniusOfBrilliantStars));
      if (elementalMultipliers[6]) c.ELEMENTAL_DMG = calculatePercentStat(Stats.Imaginary_DMG, base, lc, trace, c, 0.10 * p2(sets.WastelanderOfBanditryDesert));
      let crSum = c[Stats.CR];
      let cdSum = c[Stats.CD];

      // ************************************************************
      // Calculate base stats
      // ************************************************************

      let baseHp = calculateBaseStat(Stats.HP, base, lc);
      let baseAtk = calculateBaseStat(Stats.ATK, base, lc);
      let baseDef = calculateBaseStat(Stats.DEF, base, lc);
      let baseSpd = calculateBaseStat(Stats.SPD, base, lc);
      c.baseAtk = baseAtk;

      // ************************************************************
      // Calculate display stats with unconditional sets
      // ************************************************************

      c[Stats.HP] = calculateFlatStat(Stats.HP, Stats.HP_P, baseHp, lc, trace, c, 0.12 * p2(sets.FleetOfTheAgeless) + 0.12 * p2(sets.LongevousDisciple));
      c[Stats.ATK] = calculateFlatStat(Stats.ATK, Stats.ATK_P, baseAtk, lc, trace, c, 0.12 * p2(sets.SpaceSealingStation) + 0.12 * p2(sets.FirmamentFrontlineGlamoth) + 0.12 * p2(sets.MusketeerOfWildWheat) + 0.12 * p2(sets.PrisonerInDeepConfinement));
      c[Stats.DEF] = calculateFlatStat(Stats.DEF, Stats.DEF_P, baseDef, lc, trace, c, 0.15 * p2(sets.BelobogOfTheArchitects) + 0.15 * p2(sets.KnightOfPurityPalace));
      c[Stats.SPD] = calculateFlatStat(Stats.SPD, Stats.SPD_P, baseSpd, lc, trace, c, 0.06 * p2(sets.MessengerTraversingHackerspace) + 0.06 * p4(sets.MusketeerOfWildWheat));
      c[Stats.CR] = calculatePercentStat(Stats.CR, base, lc, trace, c, 0.08 * p2(sets.InertSalsotto) + 0.08 * p2(sets.RutilantArena));
      c[Stats.CD] = calculatePercentStat(Stats.CD, base, lc, trace, c, 0.16 * p2(sets.CelestialDifferentiator));
      c[Stats.EHR] = calculatePercentStat(Stats.EHR, base, lc, trace, c, 0.10 * p2(sets.PanCosmicCommercialEnterprise));
      c[Stats.RES] = calculatePercentStat(Stats.RES, base, lc, trace, c, 0.10 * p2(sets.BrokenKeel));
      c[Stats.BE] = calculatePercentStat(Stats.BE, base, lc, trace, c, 0.16 * p2(sets.TaliaKingdomOfBanditry) + 0.16 * p2(sets.ThiefOfShootingMeteor) + 0.16 * p4(sets.ThiefOfShootingMeteor));
      c[Stats.ERR] = calculatePercentStat(Stats.ERR, base, lc, trace, c, 0.05 * p2(sets.SprightlyVonwacq) + 0.05 * p2(sets.PenaconyLandOfTheDreams));
      c[Stats.OHB] = calculatePercentStat(Stats.OHB, base, lc, trace, c, 0.10 * p2(sets.PasserbyOfWanderingCloud));
      c.id = index;

      // ************************************************************
      // Set up calculated stats storage x
      // ************************************************************

      let x = Object.assign({}, precomputedX);
      c.x = x;
      x[Stats.ATK] += c[Stats.ATK];
      x[Stats.DEF] += c[Stats.DEF];
      x[Stats.HP] += c[Stats.HP];
      x[Stats.SPD] += c[Stats.SPD];
      x[Stats.CD] += c[Stats.CD];
      x[Stats.CR] += c[Stats.CR];
      x[Stats.EHR] += c[Stats.EHR];
      x[Stats.RES] += c[Stats.RES];
      x[Stats.BE] += c[Stats.BE];
      x[Stats.ERR] += c[Stats.ERR];
      x[Stats.OHB] += c[Stats.OHB];
      x.ELEMENTAL_DMG += c.ELEMENTAL_DMG;
      x[Stats.ATK] += request.buffAtk;
      x[Stats.ATK] += request.buffAtkP * baseAtk;
      x[Stats.CD] += request.buffCd;
      x[Stats.CR] += request.buffCr;
      x[Stats.SPD] += request.buffSpdP * baseSpd + request.buffSpd;
      x[Stats.BE] += request.buffBe;
      x.ELEMENTAL_DMG += request.buffDmgBoost;

      // ************************************************************
      // Calculate passive effects & buffs. x stores the internally calculated character stats
      // ************************************************************

      // No longer needed
      // characterConditionals.calculatePassives(c, request)
      // lightConeConditionals.calculatePassives(c, request)

      // ************************************************************
      // Calculate conditional set effects
      // ************************************************************

      x[Stats.SPD_P] += 0.12 * enabledMessengerTraversingHackerspace * p4(sets.MessengerTraversingHackerspace);
      x[Stats.SPD] += x[Stats.SPD_P] * baseSpd;
      x[Stats.ATK_P] += 0.05 * valueChampionOfStreetwiseBoxing * p4(sets.ChampionOfStreetwiseBoxing) + 0.20 * enabledBandOfSizzlingThunder * p4(sets.BandOfSizzlingThunder) + 0.06 * valueTheAshblazingGrandDuke * p4(sets.TheAshblazingGrandDuke) + 0.12 * (x[Stats.SPD] >= 120 ? 1 : 0) * p2(sets.SpaceSealingStation) + 0.08 * (x[Stats.SPD] >= 120 ? 1 : 0) * p2(sets.FleetOfTheAgeless) + Math.min(0.25, 0.25 * c[Stats.EHR]) * p2(sets.PanCosmicCommercialEnterprise);
      x[Stats.ATK] += x[Stats.ATK_P] * baseAtk;
      x[Stats.DEF_P] += 0.15 * (c[Stats.EHR] >= 0.50 ? 1 : 0) * p2(sets.BelobogOfTheArchitects);
      x[Stats.DEF] += x[Stats.DEF_P] * baseDef;
      x[Stats.HP] += x[Stats.HP_P] * baseHp;
      x[Stats.CR] += 0.10 * (valueWastelanderOfBanditryDesert > 0 ? 1 : 0) * p4(sets.WastelanderOfBanditryDesert) + 0.08 * valueLongevousDisciple * p4(sets.LongevousDisciple) + 0.60 * enabledCelestialDifferentiator * (c[Stats.CD] >= 1.20 ? 1 : 0) * p2(sets.CelestialDifferentiator);
      x[Stats.CD] += 0.25 * enabledHunterOfGlacialForest * p4(sets.HunterOfGlacialForest) + 0.10 * (valueWastelanderOfBanditryDesert == 2 ? 1 : 0) * p4(sets.WastelanderOfBanditryDesert) + 0.10 * (c[Stats.RES] >= 0.30 ? 1 : 0) * p2(sets.BrokenKeel);
      x[Stats.BE] += 0.20 * (c[Stats.SPD] >= 145 ? 1 : 0) * p2(sets.TaliaKingdomOfBanditry);
      x.BASIC_BOOST += 0.10 * p4(sets.MusketeerOfWildWheat) + 0.20 * (x[Stats.CR] >= 0.70 ? 1 : 0) * p2(sets.RutilantArena);
      x.SKILL_BOOST += 0.12 * p4(sets.FiresmithOfLavaForging) + 0.20 * (x[Stats.CR] >= 0.70 ? 1 : 0) * p2(sets.RutilantArena);
      x.ULT_BOOST += 0.15 * (x[Stats.CR] >= 0.50 ? 1 : 0) * p2(c.sets.InertSalsotto);
      x.FUA_BOOST += 0.15 * (x[Stats.CR] >= 0.50 ? 1 : 0) * p2(c.sets.InertSalsotto);
      x.FUA_BOOST += 0.20 * p2(c.sets.TheAshblazingGrandDuke);
      x.DEF_SHRED += p4(c.sets.GeniusOfBrilliantStars) ? enabledGeniusOfBrilliantStars ? 0.20 : 0.10 : 0;
      x.DEF_SHRED += 0.06 * valuePrisonerInDeepConfinement * p4(c.sets.PrisonerInDeepConfinement);
      x.ELEMENTAL_DMG += 0.12 * (x[Stats.SPD] >= 135 ? 1 : 0) * p2(sets.FirmamentFrontlineGlamoth) + 0.06 * (x[Stats.SPD] >= 160 ? 1 : 0) * p2(sets.FirmamentFrontlineGlamoth);

      // These stats have no conditional set effects yet
      // x[Stats.HP_P] += 0
      // x[Stats.EHR]  += 0
      // x[Stats.RES]  += 0
      // x[Stats.ERR]  += 0
      // x[Stats.OHB]  += 0

      // ************************************************************
      // Calculate ratings
      // ************************************************************

      let cv = 100 * (crSum * 2 + cdSum);
      c.CV = cv;

      // ************************************************************
      // Calculate skill base damage
      // ************************************************************

      characterConditionals.calculateBaseMultis(c, request);
      lightConeConditionals.calculateBaseMultis(c, request);

      // ************************************************************
      // Calculate overall multipliers
      // ************************************************************

      let cLevel = request.characterLevel;
      let eLevel = request.enemyLevel;
      let defReduction = x.DEF_SHRED + request.buffDefShred;
      let defIgnore = 0;
      let dmgBoostMultiplier = 1 + x.ALL_DMG_MULTI + x.ELEMENTAL_DMG;
      let dmgReductionMultiplier = 1;
      let ehp = x[Stats.HP] / (1 - x[Stats.DEF] / (x[Stats.DEF] + 200 + 10 * request.enemyLevel));
      ehp *= 1 / ((1 - 0.08 * p2(sets.GuardOfWutheringSnow)) * x.DMG_RED_MULTI);
      c.EHP = ehp;
      let universalMulti = dmgReductionMultiplier * brokenMultiplier;
      x.BASIC_DMG *= universalMulti * (dmgBoostMultiplier + x.BASIC_BOOST) * calculateDefMultiplier(cLevel, eLevel, defReduction, defIgnore, x.BASIC_DEF_PEN) * (Math.min(1, x[Stats.CR] + x.BASIC_CR_BOOST) * (1 + x[Stats.CD] + x.BASIC_CD_BOOST) + (1 - Math.min(1, x[Stats.CR] + x.BASIC_CR_BOOST))) * (1 + x.DMG_TAKEN_MULTI + x.BASIC_VULNERABILITY) * (1 - (resistance - x.RES_PEN - request.buffResPen - x.BASIC_RES_PEN));
      x.SKILL_DMG *= universalMulti * (dmgBoostMultiplier + x.SKILL_BOOST) * calculateDefMultiplier(cLevel, eLevel, defReduction, defIgnore, x.SKILL_DEF_PEN) * (Math.min(1, x[Stats.CR] + x.SKILL_CR_BOOST) * (1 + x[Stats.CD] + x.SKILL_CD_BOOST) + (1 - Math.min(1, x[Stats.CR] + x.SKILL_CR_BOOST))) * (1 + x.DMG_TAKEN_MULTI + x.SKILL_VULNERABILITY) * (1 - (resistance - x.RES_PEN - request.buffResPen - x.SKILL_RES_PEN));
      x.ULT_DMG *= universalMulti * (dmgBoostMultiplier + x.ULT_BOOST) * calculateDefMultiplier(cLevel, eLevel, defReduction, defIgnore, x.ULT_DEF_PEN) * (Math.min(1, x[Stats.CR] + x.ULT_CR_BOOST) * (1 + x[Stats.CD] + x.ULT_CD_BOOST) + (1 - Math.min(1, x[Stats.CR] + x.ULT_CR_BOOST))) * (1 + x.DMG_TAKEN_MULTI + x.ULT_VULNERABILITY) * (1 - (resistance - x.RES_PEN - request.buffResPen - x.ULT_RES_PEN));
      x.FUA_DMG *= universalMulti * (dmgBoostMultiplier + x.FUA_BOOST) * calculateDefMultiplier(cLevel, eLevel, defReduction, defIgnore, x.FUA_DEF_PEN) * (Math.min(1, x[Stats.CR] + x.FUA_CR_BOOST) * (1 + x[Stats.CD] + x.FUA_CD_BOOST) + (1 - Math.min(1, x[Stats.CR] + x.FUA_CR_BOOST))) * (1 + x.DMG_TAKEN_MULTI + x.FUA_VULNERABILITY) * (1 - (resistance - x.RES_PEN - request.buffResPen - x.FUA_RES_PEN));
      x.DOT_DMG *= universalMulti * (dmgBoostMultiplier + x.DOT_BOOST) * calculateDefMultiplier(cLevel, eLevel, defReduction, defIgnore, x.DOT_DEF_PEN) * (1 + x.DMG_TAKEN_MULTI + x.DOT_VULNERABILITY) * (1 - (resistance - x.RES_PEN - request.buffResPen - x.DOT_RES_PEN));

      // ************************************************************
      // Filter results
      // ************************************************************

      let statCompare = combatDisplay ? x : c;
      let result = statCompare[Stats.HP] >= request.minHp && statCompare[Stats.HP] <= request.maxHp && statCompare[Stats.ATK] >= request.minAtk && statCompare[Stats.ATK] <= request.maxAtk && statCompare[Stats.DEF] >= request.minDef && statCompare[Stats.DEF] <= request.maxDef && statCompare[Stats.SPD] >= request.minSpd && statCompare[Stats.SPD] <= request.maxSpd && statCompare[Stats.CR] >= request.minCr && statCompare[Stats.CR] <= request.maxCr && statCompare[Stats.CD] >= request.minCd && statCompare[Stats.CD] <= request.maxCd && statCompare[Stats.EHR] >= request.minEhr && statCompare[Stats.EHR] <= request.maxEhr && statCompare[Stats.RES] >= request.minRes && statCompare[Stats.RES] <= request.maxRes && statCompare[Stats.BE] >= request.minBe && statCompare[Stats.BE] <= request.maxBe && cv >= request.minCv && cv <= request.maxCv && ehp >= request.minEhp && ehp <= request.maxEhp && c.WEIGHT >= request.minWeight && c.WEIGHT <= request.maxWeight && x.BASIC_DMG >= request.minBasic && x.BASIC_DMG <= request.maxBasic && x.SKILL_DMG >= request.minSkill && x.SKILL_DMG <= request.maxSkill && x.ULT_DMG >= request.minUlt && x.ULT_DMG <= request.maxUlt && x.FUA_DMG >= request.minFua && x.FUA_DMG <= request.maxFua && x.DOT_DMG >= request.minDot && x.DOT_DMG <= request.maxDot;

      // ************************************************************
      // Pack the passing results into the ArrayBuffer to return
      // ************************************************************

      if (topRow || result && relicSetSolutions[relicSetIndex] == 1 && ornamentSetSolutions[ornamentSetIndex] == 1) {
        _bufferPacker_js__WEBPACK_IMPORTED_MODULE_1__.BufferPacker.packCharacter(arr, row * data.HEIGHT + col, c);
      }
    }
  }
  self.postMessage({
    rows: [],
    buffer: data.buffer
  }, [data.buffer]);
};
function calculateDefMultiplier(cLevel, eLevel, defReduction, defIgnore, additionalPen) {
  return (cLevel + 20) / ((eLevel + 20) * Math.max(0, 1 - defReduction - defIgnore - additionalPen) + cLevel + 20);
}
function p4(set) {
  return set >> 2;
}
function p2(set) {
  return Math.min(1, set >> 1);
}

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			if (cachedModule.error !== undefined) throw cachedModule.error;
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		try {
/******/ 			var execOptions = { id: moduleId, module: module, factory: __webpack_modules__[moduleId], require: __webpack_require__ };
/******/ 			__webpack_require__.i.forEach(function(handler) { handler(execOptions); });
/******/ 			module = execOptions.module;
/******/ 			execOptions.factory.call(module.exports, module, module.exports, execOptions.require);
/******/ 		} catch(e) {
/******/ 			module.error = e;
/******/ 			throw e;
/******/ 		}
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = __webpack_module_cache__;
/******/ 	
/******/ 	// expose the module execution interceptor
/******/ 	__webpack_require__.i = [];
/******/ 	
/******/ 	// the startup function
/******/ 	__webpack_require__.x = () => {
/******/ 		// Load entry module and return exports
/******/ 		var __webpack_exports__ = __webpack_require__.O(undefined, ["vendors-node_modules_ant-design_icons_es_icons_CloseOutlined_js-node_modules_pmmmwh_react-ref-1d700e"], () => (__webpack_require__("./src/lib/worker/optimizerWorker.js")))
/******/ 		__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 		return __webpack_exports__;
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks and sibling chunks for the entrypoint
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "static/js/" + chunkId + ".chunk.js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript update chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference all chunks
/******/ 		__webpack_require__.hu = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + "." + __webpack_require__.h() + ".hot-update.js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get update manifest filename */
/******/ 	(() => {
/******/ 		__webpack_require__.hmrF = () => ("68319f8456535f4d2c19." + __webpack_require__.h() + ".hot-update.json");
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/getFullHash */
/******/ 	(() => {
/******/ 		__webpack_require__.h = () => ("72d679e3796be94349a2")
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/harmony module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.hmd = (module) => {
/******/ 			module = Object.create(module);
/******/ 			if (!module.children) module.children = [];
/******/ 			Object.defineProperty(module, 'exports', {
/******/ 				enumerable: true,
/******/ 				set: () => {
/******/ 					throw new Error('ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: ' + module.id);
/******/ 				}
/******/ 			});
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hot module replacement */
/******/ 	(() => {
/******/ 		var currentModuleData = {};
/******/ 		var installedModules = __webpack_require__.c;
/******/ 		
/******/ 		// module and require creation
/******/ 		var currentChildModule;
/******/ 		var currentParents = [];
/******/ 		
/******/ 		// status
/******/ 		var registeredStatusHandlers = [];
/******/ 		var currentStatus = "idle";
/******/ 		
/******/ 		// while downloading
/******/ 		var blockingPromises = 0;
/******/ 		var blockingPromisesWaiting = [];
/******/ 		
/******/ 		// The update info
/******/ 		var currentUpdateApplyHandlers;
/******/ 		var queuedInvalidatedModules;
/******/ 		
/******/ 		// eslint-disable-next-line no-unused-vars
/******/ 		__webpack_require__.hmrD = currentModuleData;
/******/ 		
/******/ 		__webpack_require__.i.push(function (options) {
/******/ 			var module = options.module;
/******/ 			var require = createRequire(options.require, options.id);
/******/ 			module.hot = createModuleHotObject(options.id, module);
/******/ 			module.parents = currentParents;
/******/ 			module.children = [];
/******/ 			currentParents = [];
/******/ 			options.require = require;
/******/ 		});
/******/ 		
/******/ 		__webpack_require__.hmrC = {};
/******/ 		__webpack_require__.hmrI = {};
/******/ 		
/******/ 		function createRequire(require, moduleId) {
/******/ 			var me = installedModules[moduleId];
/******/ 			if (!me) return require;
/******/ 			var fn = function (request) {
/******/ 				if (me.hot.active) {
/******/ 					if (installedModules[request]) {
/******/ 						var parents = installedModules[request].parents;
/******/ 						if (parents.indexOf(moduleId) === -1) {
/******/ 							parents.push(moduleId);
/******/ 						}
/******/ 					} else {
/******/ 						currentParents = [moduleId];
/******/ 						currentChildModule = request;
/******/ 					}
/******/ 					if (me.children.indexOf(request) === -1) {
/******/ 						me.children.push(request);
/******/ 					}
/******/ 				} else {
/******/ 					console.warn(
/******/ 						"[HMR] unexpected require(" +
/******/ 							request +
/******/ 							") from disposed module " +
/******/ 							moduleId
/******/ 					);
/******/ 					currentParents = [];
/******/ 				}
/******/ 				return require(request);
/******/ 			};
/******/ 			var createPropertyDescriptor = function (name) {
/******/ 				return {
/******/ 					configurable: true,
/******/ 					enumerable: true,
/******/ 					get: function () {
/******/ 						return require[name];
/******/ 					},
/******/ 					set: function (value) {
/******/ 						require[name] = value;
/******/ 					}
/******/ 				};
/******/ 			};
/******/ 			for (var name in require) {
/******/ 				if (Object.prototype.hasOwnProperty.call(require, name) && name !== "e") {
/******/ 					Object.defineProperty(fn, name, createPropertyDescriptor(name));
/******/ 				}
/******/ 			}
/******/ 			fn.e = function (chunkId) {
/******/ 				return trackBlockingPromise(require.e(chunkId));
/******/ 			};
/******/ 			return fn;
/******/ 		}
/******/ 		
/******/ 		function createModuleHotObject(moduleId, me) {
/******/ 			var _main = currentChildModule !== moduleId;
/******/ 			var hot = {
/******/ 				// private stuff
/******/ 				_acceptedDependencies: {},
/******/ 				_acceptedErrorHandlers: {},
/******/ 				_declinedDependencies: {},
/******/ 				_selfAccepted: false,
/******/ 				_selfDeclined: false,
/******/ 				_selfInvalidated: false,
/******/ 				_disposeHandlers: [],
/******/ 				_main: _main,
/******/ 				_requireSelf: function () {
/******/ 					currentParents = me.parents.slice();
/******/ 					currentChildModule = _main ? undefined : moduleId;
/******/ 					__webpack_require__(moduleId);
/******/ 				},
/******/ 		
/******/ 				// Module API
/******/ 				active: true,
/******/ 				accept: function (dep, callback, errorHandler) {
/******/ 					if (dep === undefined) hot._selfAccepted = true;
/******/ 					else if (typeof dep === "function") hot._selfAccepted = dep;
/******/ 					else if (typeof dep === "object" && dep !== null) {
/******/ 						for (var i = 0; i < dep.length; i++) {
/******/ 							hot._acceptedDependencies[dep[i]] = callback || function () {};
/******/ 							hot._acceptedErrorHandlers[dep[i]] = errorHandler;
/******/ 						}
/******/ 					} else {
/******/ 						hot._acceptedDependencies[dep] = callback || function () {};
/******/ 						hot._acceptedErrorHandlers[dep] = errorHandler;
/******/ 					}
/******/ 				},
/******/ 				decline: function (dep) {
/******/ 					if (dep === undefined) hot._selfDeclined = true;
/******/ 					else if (typeof dep === "object" && dep !== null)
/******/ 						for (var i = 0; i < dep.length; i++)
/******/ 							hot._declinedDependencies[dep[i]] = true;
/******/ 					else hot._declinedDependencies[dep] = true;
/******/ 				},
/******/ 				dispose: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				addDisposeHandler: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				removeDisposeHandler: function (callback) {
/******/ 					var idx = hot._disposeHandlers.indexOf(callback);
/******/ 					if (idx >= 0) hot._disposeHandlers.splice(idx, 1);
/******/ 				},
/******/ 				invalidate: function () {
/******/ 					this._selfInvalidated = true;
/******/ 					switch (currentStatus) {
/******/ 						case "idle":
/******/ 							currentUpdateApplyHandlers = [];
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							setStatus("ready");
/******/ 							break;
/******/ 						case "ready":
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							break;
/******/ 						case "prepare":
/******/ 						case "check":
/******/ 						case "dispose":
/******/ 						case "apply":
/******/ 							(queuedInvalidatedModules = queuedInvalidatedModules || []).push(
/******/ 								moduleId
/******/ 							);
/******/ 							break;
/******/ 						default:
/******/ 							// ignore requests in error states
/******/ 							break;
/******/ 					}
/******/ 				},
/******/ 		
/******/ 				// Management API
/******/ 				check: hotCheck,
/******/ 				apply: hotApply,
/******/ 				status: function (l) {
/******/ 					if (!l) return currentStatus;
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				addStatusHandler: function (l) {
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				removeStatusHandler: function (l) {
/******/ 					var idx = registeredStatusHandlers.indexOf(l);
/******/ 					if (idx >= 0) registeredStatusHandlers.splice(idx, 1);
/******/ 				},
/******/ 		
/******/ 				//inherit from previous dispose call
/******/ 				data: currentModuleData[moduleId]
/******/ 			};
/******/ 			currentChildModule = undefined;
/******/ 			return hot;
/******/ 		}
/******/ 		
/******/ 		function setStatus(newStatus) {
/******/ 			currentStatus = newStatus;
/******/ 			var results = [];
/******/ 		
/******/ 			for (var i = 0; i < registeredStatusHandlers.length; i++)
/******/ 				results[i] = registeredStatusHandlers[i].call(null, newStatus);
/******/ 		
/******/ 			return Promise.all(results);
/******/ 		}
/******/ 		
/******/ 		function unblock() {
/******/ 			if (--blockingPromises === 0) {
/******/ 				setStatus("ready").then(function () {
/******/ 					if (blockingPromises === 0) {
/******/ 						var list = blockingPromisesWaiting;
/******/ 						blockingPromisesWaiting = [];
/******/ 						for (var i = 0; i < list.length; i++) {
/******/ 							list[i]();
/******/ 						}
/******/ 					}
/******/ 				});
/******/ 			}
/******/ 		}
/******/ 		
/******/ 		function trackBlockingPromise(promise) {
/******/ 			switch (currentStatus) {
/******/ 				case "ready":
/******/ 					setStatus("prepare");
/******/ 				/* fallthrough */
/******/ 				case "prepare":
/******/ 					blockingPromises++;
/******/ 					promise.then(unblock, unblock);
/******/ 					return promise;
/******/ 				default:
/******/ 					return promise;
/******/ 			}
/******/ 		}
/******/ 		
/******/ 		function waitForBlockingPromises(fn) {
/******/ 			if (blockingPromises === 0) return fn();
/******/ 			return new Promise(function (resolve) {
/******/ 				blockingPromisesWaiting.push(function () {
/******/ 					resolve(fn());
/******/ 				});
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function hotCheck(applyOnUpdate) {
/******/ 			if (currentStatus !== "idle") {
/******/ 				throw new Error("check() is only allowed in idle status");
/******/ 			}
/******/ 			return setStatus("check")
/******/ 				.then(__webpack_require__.hmrM)
/******/ 				.then(function (update) {
/******/ 					if (!update) {
/******/ 						return setStatus(applyInvalidatedModules() ? "ready" : "idle").then(
/******/ 							function () {
/******/ 								return null;
/******/ 							}
/******/ 						);
/******/ 					}
/******/ 		
/******/ 					return setStatus("prepare").then(function () {
/******/ 						var updatedModules = [];
/******/ 						currentUpdateApplyHandlers = [];
/******/ 		
/******/ 						return Promise.all(
/******/ 							Object.keys(__webpack_require__.hmrC).reduce(function (
/******/ 								promises,
/******/ 								key
/******/ 							) {
/******/ 								__webpack_require__.hmrC[key](
/******/ 									update.c,
/******/ 									update.r,
/******/ 									update.m,
/******/ 									promises,
/******/ 									currentUpdateApplyHandlers,
/******/ 									updatedModules
/******/ 								);
/******/ 								return promises;
/******/ 							},
/******/ 							[])
/******/ 						).then(function () {
/******/ 							return waitForBlockingPromises(function () {
/******/ 								if (applyOnUpdate) {
/******/ 									return internalApply(applyOnUpdate);
/******/ 								} else {
/******/ 									return setStatus("ready").then(function () {
/******/ 										return updatedModules;
/******/ 									});
/******/ 								}
/******/ 							});
/******/ 						});
/******/ 					});
/******/ 				});
/******/ 		}
/******/ 		
/******/ 		function hotApply(options) {
/******/ 			if (currentStatus !== "ready") {
/******/ 				return Promise.resolve().then(function () {
/******/ 					throw new Error(
/******/ 						"apply() is only allowed in ready status (state: " +
/******/ 							currentStatus +
/******/ 							")"
/******/ 					);
/******/ 				});
/******/ 			}
/******/ 			return internalApply(options);
/******/ 		}
/******/ 		
/******/ 		function internalApply(options) {
/******/ 			options = options || {};
/******/ 		
/******/ 			applyInvalidatedModules();
/******/ 		
/******/ 			var results = currentUpdateApplyHandlers.map(function (handler) {
/******/ 				return handler(options);
/******/ 			});
/******/ 			currentUpdateApplyHandlers = undefined;
/******/ 		
/******/ 			var errors = results
/******/ 				.map(function (r) {
/******/ 					return r.error;
/******/ 				})
/******/ 				.filter(Boolean);
/******/ 		
/******/ 			if (errors.length > 0) {
/******/ 				return setStatus("abort").then(function () {
/******/ 					throw errors[0];
/******/ 				});
/******/ 			}
/******/ 		
/******/ 			// Now in "dispose" phase
/******/ 			var disposePromise = setStatus("dispose");
/******/ 		
/******/ 			results.forEach(function (result) {
/******/ 				if (result.dispose) result.dispose();
/******/ 			});
/******/ 		
/******/ 			// Now in "apply" phase
/******/ 			var applyPromise = setStatus("apply");
/******/ 		
/******/ 			var error;
/******/ 			var reportError = function (err) {
/******/ 				if (!error) error = err;
/******/ 			};
/******/ 		
/******/ 			var outdatedModules = [];
/******/ 			results.forEach(function (result) {
/******/ 				if (result.apply) {
/******/ 					var modules = result.apply(reportError);
/******/ 					if (modules) {
/******/ 						for (var i = 0; i < modules.length; i++) {
/******/ 							outdatedModules.push(modules[i]);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 			});
/******/ 		
/******/ 			return Promise.all([disposePromise, applyPromise]).then(function () {
/******/ 				// handle errors in accept handlers and self accepted module load
/******/ 				if (error) {
/******/ 					return setStatus("fail").then(function () {
/******/ 						throw error;
/******/ 					});
/******/ 				}
/******/ 		
/******/ 				if (queuedInvalidatedModules) {
/******/ 					return internalApply(options).then(function (list) {
/******/ 						outdatedModules.forEach(function (moduleId) {
/******/ 							if (list.indexOf(moduleId) < 0) list.push(moduleId);
/******/ 						});
/******/ 						return list;
/******/ 					});
/******/ 				}
/******/ 		
/******/ 				return setStatus("idle").then(function () {
/******/ 					return outdatedModules;
/******/ 				});
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function applyInvalidatedModules() {
/******/ 			if (queuedInvalidatedModules) {
/******/ 				if (!currentUpdateApplyHandlers) currentUpdateApplyHandlers = [];
/******/ 				Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 					queuedInvalidatedModules.forEach(function (moduleId) {
/******/ 						__webpack_require__.hmrI[key](
/******/ 							moduleId,
/******/ 							currentUpdateApplyHandlers
/******/ 						);
/******/ 					});
/******/ 				});
/******/ 				queuedInvalidatedModules = undefined;
/******/ 				return true;
/******/ 			}
/******/ 		}
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "/hsr-optimizer/";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/react refresh */
/******/ 	(() => {
/******/ 		__webpack_require__.i.push((options) => {
/******/ 			const originalFactory = options.factory;
/******/ 			options.factory = function (moduleObject, moduleExports, webpackRequire) {
/******/ 				__webpack_require__.$Refresh$.setup(options.id);
/******/ 				try {
/******/ 					originalFactory.call(this, moduleObject, moduleExports, webpackRequire);
/******/ 				} finally {
/******/ 					if (typeof Promise !== 'undefined' && moduleObject.exports instanceof Promise) {
/******/ 						options.module.exports = options.module.exports.then(
/******/ 							(result) => {
/******/ 								__webpack_require__.$Refresh$.cleanup(options.id);
/******/ 								return result;
/******/ 							},
/******/ 							(reason) => {
/******/ 								__webpack_require__.$Refresh$.cleanup(options.id);
/******/ 								return Promise.reject(reason);
/******/ 							}
/******/ 						);
/******/ 					} else {
/******/ 						__webpack_require__.$Refresh$.cleanup(options.id)
/******/ 					}
/******/ 				}
/******/ 			};
/******/ 		})
/******/ 		
/******/ 		__webpack_require__.$Refresh$ = {
/******/ 			register: () => (undefined),
/******/ 			signature: () => ((type) => (type)),
/******/ 			runtime: {
/******/ 				createSignatureFunctionForTransform: () => ((type) => (type)),
/******/ 				register: () => (undefined)
/******/ 			},
/******/ 			setup: (currentModuleId) => {
/******/ 				const prevModuleId = __webpack_require__.$Refresh$.moduleId;
/******/ 				const prevRegister = __webpack_require__.$Refresh$.register;
/******/ 				const prevSignature = __webpack_require__.$Refresh$.signature;
/******/ 				const prevCleanup = __webpack_require__.$Refresh$.cleanup;
/******/ 		
/******/ 				__webpack_require__.$Refresh$.moduleId = currentModuleId;
/******/ 		
/******/ 				__webpack_require__.$Refresh$.register = (type, id) => {
/******/ 					const typeId = currentModuleId + " " + id;
/******/ 					__webpack_require__.$Refresh$.runtime.register(type, typeId);
/******/ 				}
/******/ 		
/******/ 				__webpack_require__.$Refresh$.signature = () => (__webpack_require__.$Refresh$.runtime.createSignatureFunctionForTransform());
/******/ 		
/******/ 				__webpack_require__.$Refresh$.cleanup = (cleanupModuleId) => {
/******/ 					if (currentModuleId === cleanupModuleId) {
/******/ 						__webpack_require__.$Refresh$.moduleId = prevModuleId;
/******/ 						__webpack_require__.$Refresh$.register = prevRegister;
/******/ 						__webpack_require__.$Refresh$.signature = prevSignature;
/******/ 						__webpack_require__.$Refresh$.cleanup = prevCleanup;
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/importScripts chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded chunks
/******/ 		// "1" means "already loaded"
/******/ 		var installedChunks = __webpack_require__.hmrS_importScripts = __webpack_require__.hmrS_importScripts || {
/******/ 			"src_lib_worker_optimizerWorker_js": 1
/******/ 		};
/******/ 		
/******/ 		// importScripts chunk loading
/******/ 		var installChunk = (data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			for(var moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) runtime(__webpack_require__);
/******/ 			while(chunkIds.length)
/******/ 				installedChunks[chunkIds.pop()] = 1;
/******/ 			parentChunkLoadingFunction(data);
/******/ 		};
/******/ 		__webpack_require__.f.i = (chunkId, promises) => {
/******/ 			// "1" is the signal for "already loaded"
/******/ 			if(!installedChunks[chunkId]) {
/******/ 				if(true) { // all chunks have JS
/******/ 					importScripts(__webpack_require__.p + __webpack_require__.u(chunkId));
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		var chunkLoadingGlobal = globalThis["webpackChunkhsr_optimizer"] = globalThis["webpackChunkhsr_optimizer"] || [];
/******/ 		var parentChunkLoadingFunction = chunkLoadingGlobal.push.bind(chunkLoadingGlobal);
/******/ 		chunkLoadingGlobal.push = installChunk;
/******/ 		
/******/ 		function loadUpdateChunk(chunkId, updatedModulesList) {
/******/ 			var success = false;
/******/ 			globalThis["webpackHotUpdatehsr_optimizer"] = (_, moreModules, runtime) => {
/******/ 				for(var moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						currentUpdate[moduleId] = moreModules[moduleId];
/******/ 						if(updatedModulesList) updatedModulesList.push(moduleId);
/******/ 					}
/******/ 				}
/******/ 				if(runtime) currentUpdateRuntime.push(runtime);
/******/ 				success = true;
/******/ 			};
/******/ 			// start update chunk loading
/******/ 			importScripts(__webpack_require__.p + __webpack_require__.hu(chunkId));
/******/ 			if(!success) throw new Error("Loading update chunk failed for unknown reason");
/******/ 		}
/******/ 		
/******/ 		var currentUpdateChunks;
/******/ 		var currentUpdate;
/******/ 		var currentUpdateRemovedChunks;
/******/ 		var currentUpdateRuntime;
/******/ 		function applyHandler(options) {
/******/ 			if (__webpack_require__.f) delete __webpack_require__.f.importScripsHmr;
/******/ 			currentUpdateChunks = undefined;
/******/ 			function getAffectedModuleEffects(updateModuleId) {
/******/ 				var outdatedModules = [updateModuleId];
/******/ 				var outdatedDependencies = {};
/******/ 		
/******/ 				var queue = outdatedModules.map(function (id) {
/******/ 					return {
/******/ 						chain: [id],
/******/ 						id: id
/******/ 					};
/******/ 				});
/******/ 				while (queue.length > 0) {
/******/ 					var queueItem = queue.pop();
/******/ 					var moduleId = queueItem.id;
/******/ 					var chain = queueItem.chain;
/******/ 					var module = __webpack_require__.c[moduleId];
/******/ 					if (
/******/ 						!module ||
/******/ 						(module.hot._selfAccepted && !module.hot._selfInvalidated)
/******/ 					)
/******/ 						continue;
/******/ 					if (module.hot._selfDeclined) {
/******/ 						return {
/******/ 							type: "self-declined",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					if (module.hot._main) {
/******/ 						return {
/******/ 							type: "unaccepted",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					for (var i = 0; i < module.parents.length; i++) {
/******/ 						var parentId = module.parents[i];
/******/ 						var parent = __webpack_require__.c[parentId];
/******/ 						if (!parent) continue;
/******/ 						if (parent.hot._declinedDependencies[moduleId]) {
/******/ 							return {
/******/ 								type: "declined",
/******/ 								chain: chain.concat([parentId]),
/******/ 								moduleId: moduleId,
/******/ 								parentId: parentId
/******/ 							};
/******/ 						}
/******/ 						if (outdatedModules.indexOf(parentId) !== -1) continue;
/******/ 						if (parent.hot._acceptedDependencies[moduleId]) {
/******/ 							if (!outdatedDependencies[parentId])
/******/ 								outdatedDependencies[parentId] = [];
/******/ 							addAllToSet(outdatedDependencies[parentId], [moduleId]);
/******/ 							continue;
/******/ 						}
/******/ 						delete outdatedDependencies[parentId];
/******/ 						outdatedModules.push(parentId);
/******/ 						queue.push({
/******/ 							chain: chain.concat([parentId]),
/******/ 							id: parentId
/******/ 						});
/******/ 					}
/******/ 				}
/******/ 		
/******/ 				return {
/******/ 					type: "accepted",
/******/ 					moduleId: updateModuleId,
/******/ 					outdatedModules: outdatedModules,
/******/ 					outdatedDependencies: outdatedDependencies
/******/ 				};
/******/ 			}
/******/ 		
/******/ 			function addAllToSet(a, b) {
/******/ 				for (var i = 0; i < b.length; i++) {
/******/ 					var item = b[i];
/******/ 					if (a.indexOf(item) === -1) a.push(item);
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			// at begin all updates modules are outdated
/******/ 			// the "outdated" status can propagate to parents if they don't accept the children
/******/ 			var outdatedDependencies = {};
/******/ 			var outdatedModules = [];
/******/ 			var appliedUpdate = {};
/******/ 		
/******/ 			var warnUnexpectedRequire = function warnUnexpectedRequire(module) {
/******/ 				console.warn(
/******/ 					"[HMR] unexpected require(" + module.id + ") to disposed module"
/******/ 				);
/******/ 			};
/******/ 		
/******/ 			for (var moduleId in currentUpdate) {
/******/ 				if (__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 					var newModuleFactory = currentUpdate[moduleId];
/******/ 					/** @type {TODO} */
/******/ 					var result;
/******/ 					if (newModuleFactory) {
/******/ 						result = getAffectedModuleEffects(moduleId);
/******/ 					} else {
/******/ 						result = {
/******/ 							type: "disposed",
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					/** @type {Error|false} */
/******/ 					var abortError = false;
/******/ 					var doApply = false;
/******/ 					var doDispose = false;
/******/ 					var chainInfo = "";
/******/ 					if (result.chain) {
/******/ 						chainInfo = "\nUpdate propagation: " + result.chain.join(" -> ");
/******/ 					}
/******/ 					switch (result.type) {
/******/ 						case "self-declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of self decline: " +
/******/ 										result.moduleId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of declined dependency: " +
/******/ 										result.moduleId +
/******/ 										" in " +
/******/ 										result.parentId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "unaccepted":
/******/ 							if (options.onUnaccepted) options.onUnaccepted(result);
/******/ 							if (!options.ignoreUnaccepted)
/******/ 								abortError = new Error(
/******/ 									"Aborted because " + moduleId + " is not accepted" + chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "accepted":
/******/ 							if (options.onAccepted) options.onAccepted(result);
/******/ 							doApply = true;
/******/ 							break;
/******/ 						case "disposed":
/******/ 							if (options.onDisposed) options.onDisposed(result);
/******/ 							doDispose = true;
/******/ 							break;
/******/ 						default:
/******/ 							throw new Error("Unexception type " + result.type);
/******/ 					}
/******/ 					if (abortError) {
/******/ 						return {
/******/ 							error: abortError
/******/ 						};
/******/ 					}
/******/ 					if (doApply) {
/******/ 						appliedUpdate[moduleId] = newModuleFactory;
/******/ 						addAllToSet(outdatedModules, result.outdatedModules);
/******/ 						for (moduleId in result.outdatedDependencies) {
/******/ 							if (__webpack_require__.o(result.outdatedDependencies, moduleId)) {
/******/ 								if (!outdatedDependencies[moduleId])
/******/ 									outdatedDependencies[moduleId] = [];
/******/ 								addAllToSet(
/******/ 									outdatedDependencies[moduleId],
/******/ 									result.outdatedDependencies[moduleId]
/******/ 								);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 					if (doDispose) {
/******/ 						addAllToSet(outdatedModules, [result.moduleId]);
/******/ 						appliedUpdate[moduleId] = warnUnexpectedRequire;
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 			currentUpdate = undefined;
/******/ 		
/******/ 			// Store self accepted outdated modules to require them later by the module system
/******/ 			var outdatedSelfAcceptedModules = [];
/******/ 			for (var j = 0; j < outdatedModules.length; j++) {
/******/ 				var outdatedModuleId = outdatedModules[j];
/******/ 				var module = __webpack_require__.c[outdatedModuleId];
/******/ 				if (
/******/ 					module &&
/******/ 					(module.hot._selfAccepted || module.hot._main) &&
/******/ 					// removed self-accepted modules should not be required
/******/ 					appliedUpdate[outdatedModuleId] !== warnUnexpectedRequire &&
/******/ 					// when called invalidate self-accepting is not possible
/******/ 					!module.hot._selfInvalidated
/******/ 				) {
/******/ 					outdatedSelfAcceptedModules.push({
/******/ 						module: outdatedModuleId,
/******/ 						require: module.hot._requireSelf,
/******/ 						errorHandler: module.hot._selfAccepted
/******/ 					});
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			var moduleOutdatedDependencies;
/******/ 		
/******/ 			return {
/******/ 				dispose: function () {
/******/ 					currentUpdateRemovedChunks.forEach(function (chunkId) {
/******/ 						delete installedChunks[chunkId];
/******/ 					});
/******/ 					currentUpdateRemovedChunks = undefined;
/******/ 		
/******/ 					var idx;
/******/ 					var queue = outdatedModules.slice();
/******/ 					while (queue.length > 0) {
/******/ 						var moduleId = queue.pop();
/******/ 						var module = __webpack_require__.c[moduleId];
/******/ 						if (!module) continue;
/******/ 		
/******/ 						var data = {};
/******/ 		
/******/ 						// Call dispose handlers
/******/ 						var disposeHandlers = module.hot._disposeHandlers;
/******/ 						for (j = 0; j < disposeHandlers.length; j++) {
/******/ 							disposeHandlers[j].call(null, data);
/******/ 						}
/******/ 						__webpack_require__.hmrD[moduleId] = data;
/******/ 		
/******/ 						// disable module (this disables requires from this module)
/******/ 						module.hot.active = false;
/******/ 		
/******/ 						// remove module from cache
/******/ 						delete __webpack_require__.c[moduleId];
/******/ 		
/******/ 						// when disposing there is no need to call dispose handler
/******/ 						delete outdatedDependencies[moduleId];
/******/ 		
/******/ 						// remove "parents" references from all children
/******/ 						for (j = 0; j < module.children.length; j++) {
/******/ 							var child = __webpack_require__.c[module.children[j]];
/******/ 							if (!child) continue;
/******/ 							idx = child.parents.indexOf(moduleId);
/******/ 							if (idx >= 0) {
/******/ 								child.parents.splice(idx, 1);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// remove outdated dependency from module children
/******/ 					var dependency;
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								for (j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									dependency = moduleOutdatedDependencies[j];
/******/ 									idx = module.children.indexOf(dependency);
/******/ 									if (idx >= 0) module.children.splice(idx, 1);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 				},
/******/ 				apply: function (reportError) {
/******/ 					// insert new code
/******/ 					for (var updateModuleId in appliedUpdate) {
/******/ 						if (__webpack_require__.o(appliedUpdate, updateModuleId)) {
/******/ 							__webpack_require__.m[updateModuleId] = appliedUpdate[updateModuleId];
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// run new runtime modules
/******/ 					for (var i = 0; i < currentUpdateRuntime.length; i++) {
/******/ 						currentUpdateRuntime[i](__webpack_require__);
/******/ 					}
/******/ 		
/******/ 					// call accept handlers
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							var module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								var callbacks = [];
/******/ 								var errorHandlers = [];
/******/ 								var dependenciesForCallbacks = [];
/******/ 								for (var j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									var dependency = moduleOutdatedDependencies[j];
/******/ 									var acceptCallback =
/******/ 										module.hot._acceptedDependencies[dependency];
/******/ 									var errorHandler =
/******/ 										module.hot._acceptedErrorHandlers[dependency];
/******/ 									if (acceptCallback) {
/******/ 										if (callbacks.indexOf(acceptCallback) !== -1) continue;
/******/ 										callbacks.push(acceptCallback);
/******/ 										errorHandlers.push(errorHandler);
/******/ 										dependenciesForCallbacks.push(dependency);
/******/ 									}
/******/ 								}
/******/ 								for (var k = 0; k < callbacks.length; k++) {
/******/ 									try {
/******/ 										callbacks[k].call(null, moduleOutdatedDependencies);
/******/ 									} catch (err) {
/******/ 										if (typeof errorHandlers[k] === "function") {
/******/ 											try {
/******/ 												errorHandlers[k](err, {
/******/ 													moduleId: outdatedModuleId,
/******/ 													dependencyId: dependenciesForCallbacks[k]
/******/ 												});
/******/ 											} catch (err2) {
/******/ 												if (options.onErrored) {
/******/ 													options.onErrored({
/******/ 														type: "accept-error-handler-errored",
/******/ 														moduleId: outdatedModuleId,
/******/ 														dependencyId: dependenciesForCallbacks[k],
/******/ 														error: err2,
/******/ 														originalError: err
/******/ 													});
/******/ 												}
/******/ 												if (!options.ignoreErrored) {
/******/ 													reportError(err2);
/******/ 													reportError(err);
/******/ 												}
/******/ 											}
/******/ 										} else {
/******/ 											if (options.onErrored) {
/******/ 												options.onErrored({
/******/ 													type: "accept-errored",
/******/ 													moduleId: outdatedModuleId,
/******/ 													dependencyId: dependenciesForCallbacks[k],
/******/ 													error: err
/******/ 												});
/******/ 											}
/******/ 											if (!options.ignoreErrored) {
/******/ 												reportError(err);
/******/ 											}
/******/ 										}
/******/ 									}
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// Load self accepted modules
/******/ 					for (var o = 0; o < outdatedSelfAcceptedModules.length; o++) {
/******/ 						var item = outdatedSelfAcceptedModules[o];
/******/ 						var moduleId = item.module;
/******/ 						try {
/******/ 							item.require(moduleId);
/******/ 						} catch (err) {
/******/ 							if (typeof item.errorHandler === "function") {
/******/ 								try {
/******/ 									item.errorHandler(err, {
/******/ 										moduleId: moduleId,
/******/ 										module: __webpack_require__.c[moduleId]
/******/ 									});
/******/ 								} catch (err2) {
/******/ 									if (options.onErrored) {
/******/ 										options.onErrored({
/******/ 											type: "self-accept-error-handler-errored",
/******/ 											moduleId: moduleId,
/******/ 											error: err2,
/******/ 											originalError: err
/******/ 										});
/******/ 									}
/******/ 									if (!options.ignoreErrored) {
/******/ 										reportError(err2);
/******/ 										reportError(err);
/******/ 									}
/******/ 								}
/******/ 							} else {
/******/ 								if (options.onErrored) {
/******/ 									options.onErrored({
/******/ 										type: "self-accept-errored",
/******/ 										moduleId: moduleId,
/******/ 										error: err
/******/ 									});
/******/ 								}
/******/ 								if (!options.ignoreErrored) {
/******/ 									reportError(err);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					return outdatedModules;
/******/ 				}
/******/ 			};
/******/ 		}
/******/ 		__webpack_require__.hmrI.importScrips = function (moduleId, applyHandlers) {
/******/ 			if (!currentUpdate) {
/******/ 				currentUpdate = {};
/******/ 				currentUpdateRuntime = [];
/******/ 				currentUpdateRemovedChunks = [];
/******/ 				applyHandlers.push(applyHandler);
/******/ 			}
/******/ 			if (!__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 				currentUpdate[moduleId] = __webpack_require__.m[moduleId];
/******/ 			}
/******/ 		};
/******/ 		__webpack_require__.hmrC.importScrips = function (
/******/ 			chunkIds,
/******/ 			removedChunks,
/******/ 			removedModules,
/******/ 			promises,
/******/ 			applyHandlers,
/******/ 			updatedModulesList
/******/ 		) {
/******/ 			applyHandlers.push(applyHandler);
/******/ 			currentUpdateChunks = {};
/******/ 			currentUpdateRemovedChunks = removedChunks;
/******/ 			currentUpdate = removedModules.reduce(function (obj, key) {
/******/ 				obj[key] = false;
/******/ 				return obj;
/******/ 			}, {});
/******/ 			currentUpdateRuntime = [];
/******/ 			chunkIds.forEach(function (chunkId) {
/******/ 				if (
/******/ 					__webpack_require__.o(installedChunks, chunkId) &&
/******/ 					installedChunks[chunkId] !== undefined
/******/ 				) {
/******/ 					promises.push(loadUpdateChunk(chunkId, updatedModulesList));
/******/ 					currentUpdateChunks[chunkId] = true;
/******/ 				} else {
/******/ 					currentUpdateChunks[chunkId] = false;
/******/ 				}
/******/ 			});
/******/ 			if (__webpack_require__.f) {
/******/ 				__webpack_require__.f.importScripsHmr = function (chunkId, promises) {
/******/ 					if (
/******/ 						currentUpdateChunks &&
/******/ 						__webpack_require__.o(currentUpdateChunks, chunkId) &&
/******/ 						!currentUpdateChunks[chunkId]
/******/ 					) {
/******/ 						promises.push(loadUpdateChunk(chunkId));
/******/ 						currentUpdateChunks[chunkId] = true;
/******/ 					}
/******/ 				};
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.hmrM = () => {
/******/ 			if (typeof fetch === "undefined") throw new Error("No browser support: need fetch API");
/******/ 			return fetch(__webpack_require__.p + __webpack_require__.hmrF()).then((response) => {
/******/ 				if(response.status === 404) return; // no update available
/******/ 				if(!response.ok) throw new Error("Failed to fetch update manifest " + response.statusText);
/******/ 				return response.json();
/******/ 			});
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/startup chunk dependencies */
/******/ 	(() => {
/******/ 		var next = __webpack_require__.x;
/******/ 		__webpack_require__.x = () => {
/******/ 			return __webpack_require__.e("vendors-node_modules_ant-design_icons_es_icons_CloseOutlined_js-node_modules_pmmmwh_react-ref-1d700e").then(next);
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// module cache are used so entry inlining is disabled
/******/ 	// run startup
/******/ 	var __webpack_exports__ = __webpack_require__.x();
/******/ 	
/******/ })()
;
//# sourceMappingURL=src_lib_worker_optimizerWorker_js.chunk.js.map